package gm;

import android.content.Context;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textservice.SentenceSuggestionsInfo;
import android.view.textservice.SpellCheckerSession;
import android.view.textservice.SuggestionsInfo;
import android.view.textservice.TextInfo;
import android.view.textservice.TextServicesManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONObject;

// Полоса подсказок над клавиатурой: свои слова (учится на твоём вводе), встроенный список
// и системная проверка орфографии телефона. Ничего не исправляет сама, только предлагает.
public class Dict {
    private static final String[] BASE = (
        "привет здравствуйте пожалуйста спасибо сейчас попробую помочь помощь помогите администрация администратор игрок игрока игроку "
        + "наказание наказан наказать нарушение нарушил правила правилами сервер сервере сервера жалоба жалобу жалобы репорт репорте вопрос ответ "
        + "ответить проверим проверка проверю проверьте доказательства доказательство видео скриншот скриншоты уточните уточнить пишите напишите "
        + "написать форум форуме раздел разделе возможно невозможно можете можно нельзя должны должен будет будете будут если когда потому почему "
        + "который которая которое этого этому этот этой всего всем всех теперь после перед между через около сегодня завтра вчера хорошо отлично "
        + "понятно приятной игры удачи извините извиняемся передам передали рассмотрим рассмотрено телепорт телепортируем транспорт машина "
        + "автомобиль фракция фракции организация банда деньги имущество аккаунт аккаунта пароль восстановление блокировка разблокировка "
        + "hello please thanks thank player server admin report support question answer sorry"
    ).split(" ");

    private static LinearLayout strip;
    private static final TextView[] cells = new TextView[3];
    private static InputMethodService svc;
    private static SpellCheckerSession ru, en;
    private static final Map<String, Integer> learned = new HashMap<String, Integer>();
    private static String curWord = "";
    private static String lastKey = "";
    private static List<String> spell = new ArrayList<String>();
    private static final Handler ui = new Handler(Looper.getMainLooper());

    public static void install(View root, InputMethodService s) {
        try {
            svc = s;
            load(s);
            LinearLayout host = findHost(root);
            if (host == null) return;
            strip = new LinearLayout(s);
            strip.setOrientation(LinearLayout.HORIZONTAL);
            strip.setBackgroundColor(0xFF10142A);
            strip.setVisibility(View.GONE);
            for (int i = 0; i < 3; i++) {
                final TextView t = new TextView(s);
                t.setTextColor(-1);
                t.setTextSize(16);
                t.setGravity(Gravity.CENTER);
                t.setSingleLine();
                t.setPadding(8, 14, 8, 14);
                t.setOnClickListener(v -> pick(t.getText().toString()));
                cells[i] = t;
                strip.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            }
            host.addView(strip, 0, new LinearLayout.LayoutParams(-1, -2));
            TextServicesManager tm = (TextServicesManager) s.getSystemService(Context.TEXT_SERVICES_MANAGER_SERVICE);
            SpellCheckerSession.SpellCheckerSessionListener l = new SpellCheckerSession.SpellCheckerSessionListener() {
                @Override
                public void onGetSuggestions(SuggestionsInfo[] r) {
                    final List<String> out = new ArrayList<String>();
                    if (r != null) {
                        for (SuggestionsInfo i : r) {
                            for (int k = 0; k < i.getSuggestionsCount(); k++) out.add(i.getSuggestionAt(k));
                        }
                    }
                    ui.post(() -> {
                        spell = out;
                        show();
                    });
                }

                @Override
                public void onGetSentenceSuggestions(SentenceSuggestionsInfo[] r) {
                }
            };
            ru = tm.newSpellCheckerSession(null, new Locale("ru"), l, false);
            en = tm.newSpellCheckerSession(null, new Locale("en"), l, false);
        } catch (Throwable e) {
        }
    }

    private static LinearLayout findHost(View v) {
        if (v instanceof LinearLayout && ((LinearLayout) v).getOrientation() == LinearLayout.VERTICAL) return (LinearLayout) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                LinearLayout r = findHost(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    public static void update(InputMethodService s) {
        try {
            if (strip == null) return;
            InputConnection ic = s.getCurrentInputConnection();
            EditorInfo ei = s.getCurrentInputEditorInfo();
            if (ic == null || secret(ei)) {
                hide();
                return;
            }
            CharSequence b = ic.getTextBeforeCursor(40, 0);
            String t = b == null ? "" : b.toString();
            String line = t.substring(t.lastIndexOf('\n') + 1);
            if (line.startsWith("/")) {
                hide();
                return;
            }
            if (t.endsWith(" ") && !t.equals(lastKey)) learn(tail(t.trim()));
            lastKey = t;
            curWord = tail(t);
            if (curWord.length() < 2) {
                hide();
                return;
            }
            spell = new ArrayList<String>();
            show();
            SpellCheckerSession ss = isCyr(curWord) ? ru : en;
            if (ss != null) ss.getSuggestions(new TextInfo(curWord), 4);
        } catch (Throwable e) {
        }
    }

    private static boolean secret(EditorInfo ei) {
        if (ei == null) return false;
        int v = ei.inputType & InputType.TYPE_MASK_VARIATION;
        int c = ei.inputType & InputType.TYPE_MASK_CLASS;
        return (c == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))
                || (c == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    }

    private static boolean isCyr(String w) {
        return w.length() > 0 && Character.UnicodeBlock.of(w.charAt(0)) == Character.UnicodeBlock.CYRILLIC;
    }

    private static String tail(String s) {
        int i = s.length();
        while (i > 0 && Character.isLetter(s.charAt(i - 1))) i--;
        return s.substring(i);
    }

    private static void hide() {
        if (strip != null) strip.setVisibility(View.GONE);
    }

    private static void show() {
        if (strip == null) return;
        String lw = curWord.toLowerCase();
        List<String> c = new ArrayList<String>();
        List<Map.Entry<String, Integer>> own = new ArrayList<Map.Entry<String, Integer>>();
        for (Map.Entry<String, Integer> e : learned.entrySet()) if (e.getKey().startsWith(lw) && !e.getKey().equals(lw)) own.add(e);
        java.util.Collections.sort(own, (a, b) -> b.getValue() - a.getValue());
        for (Map.Entry<String, Integer> e : own) add(c, e.getKey());
        for (String w : BASE) if (w.startsWith(lw) && !w.equals(lw)) add(c, w);
        for (String w : spell) if (!w.equalsIgnoreCase(curWord)) add(c, w);
        boolean up = curWord.length() > 0 && Character.isUpperCase(curWord.charAt(0));
        for (int i = 0; i < 3; i++) {
            String w = i < c.size() ? c.get(i) : "";
            if (up && w.length() > 0) w = Character.toUpperCase(w.charAt(0)) + w.substring(1);
            cells[i].setText(w);
        }
        strip.setVisibility(c.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private static void add(List<String> c, String w) {
        if (c.size() < 3 && !c.contains(w)) c.add(w);
    }

    private static void pick(String w) {
        try {
            if (w.length() == 0 || svc == null) return;
            InputConnection ic = svc.getCurrentInputConnection();
            if (ic == null) return;
            ic.deleteSurroundingText(curWord.length(), 0);
            ic.commitText(w + " ", 1);
            learn(w);
        } catch (Throwable e) {
        }
    }

    private static void learn(String w) {
        if (svc == null || w.length() < 3) return;
        String lw = w.toLowerCase();
        if (learned.size() > 4000 && !learned.containsKey(lw)) return;
        Integer n = learned.get(lw);
        learned.put(lw, n == null ? 1 : n + 1);
        try {
            svc.getSharedPreferences("gm_dict", 0).edit().putString("w", new JSONObject(learned).toString()).apply();
        } catch (Throwable e) {
        }
    }

    private static void load(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences("gm_dict", 0);
            String s = p.getString("w", null);
            if (s == null) return;
            JSONObject o = new JSONObject(s);
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                learned.put(k, o.getInt(k));
            }
        } catch (Throwable e) {
        }
    }
}
