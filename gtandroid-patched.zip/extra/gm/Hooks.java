package gm;

import android.content.Context;
import android.content.SharedPreferences;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Hooks {
    static final String CLS = "gtandroid.universal.KeyboardService$TileSpec";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("gm_quick", 0);
    }

    // Вызывается из showQuickCommandMenu: при первом запуске сохраняет стандартный список,
    // потом подменяет его списком из редактора.
    public static void apply(ArrayList list, Context ctx) {
        try {
            SharedPreferences p = sp(ctx);
            String s = p.getString("tiles", null);
            Class<?> k = Class.forName(CLS);
            if (s == null) {
                p.edit().putString("tiles", dump(list, k).toString()).apply();
                return;
            }
            JSONArray a = new JSONArray(s);
            Constructor<?> ct = k.getDeclaredConstructor(String.class, int.class, int.class, int.class, int.class, int.class, String.class);
            ct.setAccessible(true);
            ArrayList out = new ArrayList();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String t = o.isNull("t") ? null : o.getString("t");
                out.add(ct.newInstance(o.getString("n"), o.getInt("g"), o.getInt("c"), o.getInt("a"), o.getInt("r"), o.getInt("s"), t));
            }
            list.clear();
            list.addAll(out);
        } catch (Throwable e) {
            // при любой ошибке остаётся стандартный список
        }
    }

    static JSONArray dump(ArrayList list, Class<?> k) throws Exception {
        JSONArray a = new JSONArray();
        for (Object t : list) {
            JSONObject o = new JSONObject();
            o.put("n", fld(k, t, "name"));
            o.put("g", fld(k, t, "glyph"));
            o.put("c", fld(k, t, "color"));
            o.put("a", fld(k, t, "action"));
            o.put("r", fld(k, t, "req"));
            o.put("s", fld(k, t, "style"));
            Object tp = fld(k, t, "tpl");
            o.put("t", tp == null ? JSONObject.NULL : tp);
            a.put(o);
        }
        return a;
    }

    static Object fld(Class<?> k, Object t, String n) throws Exception {
        Field f = k.getDeclaredField(n);
        f.setAccessible(true);
        return f.get(t);
    }
}
