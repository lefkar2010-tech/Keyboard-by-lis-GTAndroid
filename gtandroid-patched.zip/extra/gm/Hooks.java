package gm;

import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.DragEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Hooks {
    static final String CLS = "gtandroid.universal.KeyboardService$TileSpec";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("gm_quick", 0);
    }

    // Вызывается из showQuickCommandMenu: при первом запуске сохраняет стандартный список,
    // потом подменяет его списком из редактора.
    public static void apply(ArrayList list, Context ctx) {
        try {
            SharedPreferences p = sp(ctx);
            String s = p.getString("tiles", null);
            Class<?> k = Class.forName(CLS);
            if (s == null) {
                p.edit().putString("tiles", dump(list, k).toString()).apply();
                return;
            }
            JSONArray a = new JSONArray(s);
            Constructor<?> ct = k.getDeclaredConstructor(String.class, int.class, int.class, int.class, int.class, int.class, String.class);
            ct.setAccessible(true);
            ArrayList out = new ArrayList();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String t = o.isNull("t") ? null : o.getString("t");
                out.add(ct.newInstance(o.getString("n"), o.getInt("g"), o.getInt("c"), o.getInt("a"), o.getInt("r"), o.getInt("s"), t));
            }
            list.clear();
            list.addAll(out);
        } catch (Throwable e) {
            // при любой ошибке остаётся стандартный список
        }
    }

    static JSONArray dump(ArrayList list, Class<?> k) throws Exception {
        JSONArray a = new JSONArray();
        for (Object t : list) {
            JSONObject o = new JSONObject();
            o.put("n", fld(k, t, "name"));
            o.put("g", fld(k, t, "glyph"));
            o.put("c", fld(k, t, "color"));
            o.put("a", fld(k, t, "action"));
            o.put("r", fld(k, t, "req"));
            o.put("s", fld(k, t, "style"));
            Object tp = fld(k, t, "tpl");
            o.put("t", tp == null ? JSONObject.NULL : tp);
            a.put(o);
        }
        return a;
    }

    static Object fld(Class<?> k, Object t, String n) throws Exception {
        Field f = k.getDeclaredField(n);
        f.setAccessible(true);
        return f.get(t);
    }

    // Конец showQuickCommandMenu: делает кнопки перетаскиваемыми (зажать и перетащить).
    public static void afterQuick(LinearLayout menu, Context ctx) {
        try {
            String s = sp(ctx).getString("tiles", null);
            if (s == null) return;
            JSONArray a = new JSONArray(s);
            List<String> names = new ArrayList<String>();
            for (int i = 0; i < a.length(); i++) names.add(a.getJSONObject(i).getString("n"));
            walk(menu, ctx, names);
        } catch (Throwable e) {
        }
    }

    static void walk(View v, final Context ctx, final List<String> names) {
        if (v instanceof Button) {
            final int idx = names.indexOf(((Button) v).getText().toString().trim());
            if (idx >= 0) {
                v.setOnLongClickListener(x -> {
                    x.startDragAndDrop(ClipData.newPlainText("i", String.valueOf(idx)), new View.DragShadowBuilder(x), null, 0);
                    return true;
                });
                v.setOnDragListener((x, e) -> {
                    if (e.getAction() == DragEvent.ACTION_DROP) {
                        reorder(ctx, Integer.parseInt(e.getClipData().getItemAt(0).getText().toString()), idx);
                    }
                    return true;
                });
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), ctx, names);
        }
    }

    static void reorder(final Context ctx, int from, int to) {
        try {
            JSONArray a = new JSONArray(sp(ctx).getString("tiles", "[]"));
            List<JSONObject> l = new ArrayList<JSONObject>();
            for (int i = 0; i < a.length(); i++) l.add(a.getJSONObject(i));
            if (from == to || from < 0 || to < 0 || from >= l.size() || to >= l.size()) return;
            JSONObject o = l.remove(from);
            l.add(to, o);
            JSONArray out = new JSONArray();
            for (JSONObject x : l) out.put(x);
            sp(ctx).edit().putString("tiles", out.toString()).apply();
            new Handler(Looper.getMainLooper()).post(() -> call(ctx, "showQuickCommandMenu"));
        } catch (Throwable e) {
        }
    }

    // Конец showPunishmentIdInput: кнопка FamWar внутри «Наказать игрока».
    public static void afterPunish(LinearLayout menu, final Context ctx) {
        try {
            Button b = new Button(ctx);
            b.setText("FamWar");
            b.setAllCaps(false);
            b.setTextColor(-1);
            b.setBackgroundColor(0xFF1F7A55);
            b.setOnClickListener(v -> call(ctx, "showFamWarMenu"));
            menu.addView(b, new LinearLayout.LayoutParams(-1, -2));
        } catch (Throwable e) {
        }
    }

    static void call(Context ctx, String name) {
        try {
            Method m = ctx.getClass().getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(ctx);
        } catch (Throwable e) {
        }
    }
}
