package gm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.os.Bundle;
import android.text.InputType;
import android.view.DragEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class EditorActivity extends Activity {
    private LinearLayout box;
    private final List<JSONObject> items = new ArrayList<JSONObject>();

    private int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density);
    }

    private void toast(String t) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show();
    }

    private TextView tv(String t, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        if (bold) v.setTypeface(null, 1);
        v.setPadding(0, dp(4), 0, dp(4));
        return v;
    }

    private Button small(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setMinWidth(dp(44));
        b.setMinimumWidth(dp(44));
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(box);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
        render();
    }

    private void load() {
        items.clear();
        String s = Hooks.sp(this).getString("tiles", null);
        if (s == null) return;
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) items.add(a.getJSONObject(i));
        } catch (Exception e) {
            items.clear();
        }
    }

    private void save() {
        JSONArray a = new JSONArray();
        for (JSONObject o : items) a.put(o);
        Hooks.sp(this).edit().putString("tiles", a.toString()).apply();
    }

    private void move(int from, int to) {
        if (from == to || from < 0 || from >= items.size() || to < 0 || to >= items.size()) return;
        JSONObject o = items.remove(from);
        items.add(to, o);
        save();
        render();
    }

    private void render() {
        box.removeAllViews();
        box.addView(tv("Быстрые команды", 22, true));
        box.addView(tv("Зажми строку и перетащи, чтобы поменять порядок. Изменения видны в клавиатуре, когда откроешь панель «Быстрые команды» заново.", 13, false));
        CheckBox hn = new CheckBox(this);
        hn.setText("Подсказки слов над клавиатурой (применится после переключения клавиатуры)");
        hn.setChecked(getSharedPreferences("gm_dict", 0).getBoolean("hints", true));
        hn.setOnCheckedChangeListener((cb, on) -> getSharedPreferences("gm_dict", 0).edit().putBoolean("hints", on).apply());
        box.addView(hn);
        CheckBox ac = new CheckBox(this);
        ac.setText("Автоисправление опечаток (по умолчанию выключено)");
        ac.setChecked(getSharedPreferences("gm_dict", 0).getBoolean("auto", false));
        ac.setOnCheckedChangeListener((cb, on) -> getSharedPreferences("gm_dict", 0).edit().putBoolean("auto", on).apply());
        box.addView(ac);
        if (items.isEmpty()) {
            box.addView(tv("Список ещё не загружен: открой клавиатуру в игре, нажми «Быстрые команды» один раз и вернись сюда.", 15, false));
            return;
        }
        for (int i = 0; i < items.size(); i++) {
            final int idx = i;
            final JSONObject o = items.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(6), dp(6), dp(6), dp(6));
            row.setBackgroundColor(0x22888888);
            String cmd = o.isNull("t") ? "" : o.optString("t");
            String label = o.optString("n") + "\n" + cmd + (o.optInt("a") == 2 ? "  [ID]" : "") + "  · ур." + o.optInt("r");
            row.addView(tv(label, 14, false), new LinearLayout.LayoutParams(0, -2, 1f));
            Button up = small("↑");
            up.setOnClickListener(v -> move(idx, idx - 1));
            Button ed = small("✎");
            ed.setOnClickListener(v -> edit(o));
            Button del = small("✕");
            del.setOnClickListener(v -> {
                items.remove(idx);
                save();
                render();
            });
            row.addView(up);
            row.addView(ed);
            row.addView(del);
            row.setOnLongClickListener(v -> {
                v.startDragAndDrop(ClipData.newPlainText("i", String.valueOf(idx)), new View.DragShadowBuilder(v), null, 0);
                return true;
            });
            row.setOnDragListener((v, e) -> {
                if (e.getAction() == DragEvent.ACTION_DROP) {
                    final int from = Integer.parseInt(e.getClipData().getItemAt(0).getText().toString());
                    box.post(() -> move(from, idx));
                }
                return true;
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.setMargins(0, dp(4), 0, dp(4));
            box.addView(row, p);
        }
        Button add = new Button(this);
        add.setText("+ Добавить команду");
        add.setOnClickListener(v -> edit(null));
        box.addView(add);
        Button reset = new Button(this);
        reset.setText("Вернуть стандартный список");
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("Вернуть стандартный список команд?")
                .setPositiveButton("Да", (d, w) -> {
                    Hooks.sp(this).edit().remove("tiles").apply();
                    items.clear();
                    render();
                })
                .setNegativeButton("Нет", null)
                .show());
        box.addView(reset);
    }

    private JSONObject newTile() throws Exception {
        JSONObject r = items.isEmpty() ? null : items.get(0);
        JSONObject x = new JSONObject();
        x.put("g", r == null ? 0 : r.optInt("g"));
        x.put("c", r == null ? -8410881 : r.optInt("c"));
        x.put("s", r == null ? 0 : r.optInt("s"));
        x.put("a", 0);
        x.put("r", 1);
        return x;
    }

    private void edit(final JSONObject o) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(16), dp(8), dp(16), 0);
        final EditText n = new EditText(this);
        n.setHint("Название кнопки");
        n.setSingleLine();
        final EditText c = new EditText(this);
        c.setHint("Команда, например /slap");
        c.setSingleLine();
        final EditText lv = new EditText(this);
        lv.setHint("Уровень админа 1-4");
        lv.setInputType(InputType.TYPE_CLASS_NUMBER);
        lv.setSingleLine();
        final CheckBox id = new CheckBox(this);
        id.setText("Нужен ID игрока");
        int a = o == null ? 0 : o.optInt("a");
        final boolean simple = a == 0 || a == 2;
        if (o != null) {
            n.setText(o.optString("n"));
            c.setText(o.isNull("t") ? "" : o.optString("t"));
            lv.setText(String.valueOf(o.optInt("r", 1)));
            id.setChecked(a == 2);
        } else {
            lv.setText("1");
        }
        f.addView(n);
        f.addView(c);
        f.addView(lv);
        if (simple) f.addView(id);
        else f.addView(tv("Особое действие: тип не меняется", 12, false));
        new AlertDialog.Builder(this)
                .setTitle(o == null ? "Новая команда" : "Изменить команду")
                .setView(f)
                .setPositiveButton("Сохранить", (d, w) -> {
                    String name = n.getText().toString().trim();
                    String cmd = c.getText().toString().trim();
                    if (name.isEmpty() || cmd.isEmpty()) {
                        toast("Нужны название и команда");
                        return;
                    }
                    int level = 1;
                    try {
                        level = Integer.parseInt(lv.getText().toString().trim());
                    } catch (Exception e) {
                    }
                    level = Math.max(1, Math.min(4, level));
                    try {
                        JSONObject x = o != null ? o : newTile();
                        x.put("n", name);
                        x.put("t", cmd);
                        x.put("r", level);
                        if (simple) x.put("a", id.isChecked() ? 2 : 0);
                        if (o == null) items.add(x);
                        save();
                        render();
                    } catch (Exception e) {
                        toast("Ошибка: " + e.getMessage());
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}
