.class Lgtandroid/universal/MainActivity$100000023;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000023"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$dlg:Landroid/app/AlertDialog;

.field private final val$etFrom:Landroid/widget/EditText;

.field private final val$etKeyword:Landroid/widget/EditText;

.field private final val$etTo:Landroid/widget/EditText;

.field private final val$index:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;ILandroid/app/AlertDialog;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    move-object/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000023;->val$etFrom:Landroid/widget/EditText;

    move-object v8, v0

    move-object v9, v3

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000023;->val$etTo:Landroid/widget/EditText;

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000023;->val$etKeyword:Landroid/widget/EditText;

    move-object v8, v0

    move v9, v5

    iput v9, v8, Lgtandroid/universal/MainActivity$100000023;->val$index:I

    move-object v8, v0

    move-object v9, v6

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000023;->val$dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000023;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1207
    move-object v0, p0

    move-object v1, p1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000023;->val$etFrom:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/MainActivity;->access$1000066(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v3, v9

    .line 1208
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000023;->val$etTo:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/MainActivity;->access$1000066(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 1209
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->val$etKeyword:Landroid/widget/EditText;

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-interface {v9}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    move-object v5, v9

    .line 1210
    move-object v9, v3

    if-eqz v9, :cond_0

    move-object v9, v4

    if-nez v9, :cond_1

    .line 1211
    :cond_0
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    const-string v10, "\u0412\u0440\u0435\u043c\u044f \u0432\u0432\u043e\u0434\u0438\u0442\u0441\u044f \u0442\u0430\u043a: 11:00 \u0434\u043e 11:15"

    const/4 v11, 0x0

    invoke-static {v9, v10, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/Toast;->show()V

    .line 1236
    :goto_0
    return-void

    .line 1214
    :cond_1
    move-object v9, v5

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_2

    .line 1215
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    const-string v10, "\u0423\u043a\u0430\u0436\u0438, \u043a\u0430\u043a\u043e\u0439 \u0440\u0435\u043f\u043e\u0440\u0442 \u043f\u0440\u0438\u043d\u0438\u043c\u0430\u0442\u044c (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440 +)"

    const/4 v11, 0x0

    invoke-static {v9, v10, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/Toast;->show()V

    .line 1216
    goto :goto_0

    .line 1219
    :cond_2
    move-object v9, v0

    :try_start_0
    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v9}, Lgtandroid/universal/MainActivity;->access$1000064(Lgtandroid/universal/MainActivity;)Lorg/json/JSONArray;

    move-result-object v9

    move-object v6, v9

    .line 1220
    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/MainActivity$100000023;->val$index:I

    const/4 v10, 0x0

    if-lt v9, v10, :cond_3

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/MainActivity$100000023;->val$index:I

    move-object v10, v6

    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v9, v10, :cond_3

    .line 1222
    move-object v9, v6

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/MainActivity$100000023;->val$index:I

    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    move-object v7, v9

    .line 1228
    :goto_1
    move-object v9, v7

    const-string v10, "from"

    move-object v11, v3

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 1229
    move-object v9, v7

    const-string v10, "to"

    move-object v11, v4

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 1230
    move-object v9, v7

    const-string v10, "keyword"

    move-object v11, v5

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 1231
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    move-object v10, v6

    invoke-static {v9, v10}, Lgtandroid/universal/MainActivity;->access$1000065(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1235
    :goto_2
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->val$dlg:Landroid/app/AlertDialog;

    invoke-virtual {v9}, Landroid/app/Dialog;->dismiss()V

    .line 1236
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000023;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v9}, Lgtandroid/universal/MainActivity;->access$1000077(Lgtandroid/universal/MainActivity;)V

    goto :goto_0

    .line 1224
    :cond_3
    :try_start_1
    new-instance v9, Lorg/json/JSONObject;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    move-object v7, v9

    .line 1225
    move-object v9, v7

    const-string v10, "enabled"

    const/4 v11, 0x0

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v9

    .line 1226
    move-object v9, v6

    move-object v10, v7

    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v9

    goto :goto_1

    .line 1231
    :catch_0
    move-exception v9

    move-object v6, v9

    .line 1233
    move-object v9, v6

    invoke-virtual {v9}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method
