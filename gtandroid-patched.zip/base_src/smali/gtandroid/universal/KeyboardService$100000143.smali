.class Lgtandroid/universal/KeyboardService$100000143;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000143"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$carIdInput:Landroid/widget/EditText;

.field private final val$command:Ljava/lang/String;

.field private final val$isViolator:Z

.field private final val$targetId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Landroid/widget/EditText;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000143;->val$carIdInput:Landroid/widget/EditText;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000143;->val$command:Ljava/lang/String;

    move-object v7, v0

    move v8, v4

    iput-boolean v8, v7, Lgtandroid/universal/KeyboardService$100000143;->val$isViolator:Z

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000143;->val$targetId:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000143;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 5033
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000143;->val$carIdInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-interface {v5}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 5034
    move-object v5, v3

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 5043
    :goto_0
    return-void

    .line 5038
    :cond_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v9}, Lgtandroid/universal/KeyboardService;->access$1000301(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000143;->val$command:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 5040
    move-object v5, v0

    iget-boolean v5, v5, Lgtandroid/universal/KeyboardService$100000143;->val$isViolator:Z

    if-eqz v5, :cond_1

    .line 5041
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000039(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000040(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000397(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V

    .line 5043
    :goto_1
    goto :goto_0

    :cond_1
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000143;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000143;->val$targetId:Ljava/lang/String;

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000285(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    goto :goto_1
.end method
