.class public final Lgtandroid/universal/NavData;
.super Ljava/lang/Object;
.source "NavData.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/NavData$Item;,
        Lgtandroid/universal/NavData$Cat;
    }
.end annotation


# static fields
.field private static final CAT_RE:Ljava/util/regex/Pattern;

.field private static final DEFAULT_CFG:Ljava/lang/String; = "1. \u0424\u0438\u043b\u0438\u0430\u043b ROSTIC\'S\n\n2. \u041e\u0431\u0449\u0435\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043c\u0435\u0441\u0442\u0430\n2.1. \u0410\u0432\u0442\u043e\u0448\u043a\u043e\u043b\u0430\n2.2. \u0412\u043e\u0435\u043d\u043a\u043e\u043c\u0430\u0442\n2.3. \u0411\u0430\u043d\u043a \u0433. \u042e\u0436\u043d\u044b\u0439\n2.4. \u0411\u0430\u043d\u043a \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n2.5. \u0411\u0430\u043d\u043a \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n2.6. \u0426\u0435\u0440\u043a\u043e\u0432\u044c\n2.7. \u0410\u0432\u0442\u043e\u0440\u044b\u043d\u043e\u043a\n2.8. \u041f\u043e\u0447\u0442\u043e\u0432\u043e\u0435 \u043e\u0442\u0434\u0435\u043b\u0435\u043d\u0438\u0435\n\n3. \u0412\u043e\u043a\u0437\u0430\u043b\u044b\n3.1. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n3.2. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u042e\u0436\u043d\u044b\u0439\n3.3. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n3.4. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u042d\u0434\u043e\u0432\u043e\n3.5. \u041c\u043e\u0440\u0441\u043a\u043e\u0439 \u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n\n4. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d\u044b / \u0441\u0442\u043e\u044f\u043d\u043a\u0438\n4.1. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u042d\u043a\u043e\u043d\u043e\u043c\n4.2. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041a\u043e\u043c\u0444\u043e\u0440\u0442\n4.3. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041f\u0440\u0435\u043c\u0438\u0443\u043c\n4.4. \u041c\u043e\u0442\u043e\u0441\u0430\u043b\u043e\u043d\n4.5. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n4.6. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n4.7. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u042e\u0436\u043d\u044b\u0439\n4.8. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u042d\u0434\u043e\u0432\u043e\n4.9. \u0421\u0422\u041e \'\u0420\u0435\u0430\u043a\u0442\u043e\u0440\'\n\n5. \u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438\n5.1. \u041f\u0440\u0430\u0432\u0438\u0442\u0435\u043b\u044c\u0441\u0442\u0432\u043e\n5.2. \u0412\u043e\u0438\u043d\u0441\u043a\u0430\u044f \u0447\u0430\u0441\u0442\u044c\n5.3. \u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n5.4. \u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u042e\u0436\u043d\u044b\u0439\n5.5. \u041d\u043e\u0432\u043e\u0441\u0442\u043d\u0430\u044f \u0441\u0435\u0442\u044c\n5.6. \u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n5.7. \u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u042e\u0436\u043d\u044b\u0439\n5.8. \u0424\u0421\u0411\n\n6. \u041a\u0440\u0438\u043c\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438\n6.1. \u0422\u0430\u043c\u0431\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.2. \u041a\u0443\u0440\u0433\u0430\u043d\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.3. \u041e\u0440\u0435\u0445\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.4. \u041a\u0430\u0432\u043a\u0430\u0437\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.5. \u0427\u0451\u0440\u043d\u044b\u0439 \u0440\u044b\u043d\u043e\u043a\n\n7. \u041d\u0430\u0447\u0430\u043b\u044c\u043d\u044b\u0435 \u0440\u0430\u0431\u043e\u0442\u044b\n7.1. \u0417\u0430\u0432\u043e\u0434 Tesla\n7.2. \u0417\u0430\u0432\u043e\u0434 \u0421\u0422\u0415\u041f\n7.3. \u0428\u0430\u0445\u0442\u0430\n7.4. \u0424\u0435\u0440\u043c\u0430\n7.5. \u0421\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u043e\u0447\u043d\u044b\u0439 \u0446\u0435\u043d\u0442\u0440\n7.6. \u0420\u0435\u0441\u0442\u043e\u0440\u0430\u043d ROSTIC\'S\n\n8. \u0420\u0430\u0431\u043e\u0442\u044b\n8.1. \u0422\u0430\u043a\u0441\u0438\u0441\u0442\n8.2. \u0412\u043e\u0434\u0438\u0442\u0435\u043b\u044c \u0430\u0432\u0442\u043e\u0431\u0443\u0441\u0430\n8.3. \u041f\u043e\u0447\u0442\u0430\u043b\u044c\u043e\u043d\n8.4. \u041c\u0435\u0445\u0430\u043d\u0438\u043a\n8.5. \u0414\u0430\u043b\u044c\u043d\u043e\u0431\u043e\u0439\u0449\u0438\u043a\n8.6. \u0418\u043d\u043a\u0430\u0441\u0441\u0430\u0442\u043e\u0440\n8.7. \u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u042e\u0436\u043d\u043e\u0433\u043e\n8.8. \u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u0410\u0440\u0437\u0430\u043c\u0430\u0441\u0430\n8.9. \u041c\u0443\u0441\u043e\u0440\u0449\u0438\u043a\n8.10. \u0420\u044b\u0431\u0430\u043b\u043a\u0430\n\n9. \u0420\u0430\u0437\u0432\u043b\u0435\u0447\u0435\u043d\u0438\u044f\n9.1. Grand Casino\n9.2. \u0410\u0443\u043a\u0446\u0438\u043e\u043d \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u043e\u0432\n9.3. \u0414\u0440\u0438\u0444\u0442 \u0437\u043e\u043d\u0430\n9.4. \u041f\u0430\u0440\u043a \u043e\u0442\u0434\u044b\u0445\u0430\n\n10. \u041d\u043e\u0442\u0430\u0440\u0438\u0430\u043b\u044c\u043d\u043e\u0435 \u0410\u0433\u0435\u043d\u0442\u0441\u0442\u0432\u043e\n\n11. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0435 \u0438 \u043c\u043e\u0440\u0441\u043a\u0438\u0435 \u043a\u043b\u0443\u0431\u044b\n11.1. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0439 \u043a\u043b\u0443\u0431 \u0433. \u042e\u0436\u043d\u044b\u0439\n11.2. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0439 \u043a\u043b\u0443\u0431 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n11.3. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21161\n11.4. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21162\n11.5. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21163\n\n12. \u0421\u043a\u0443\u043f\u0449\u0438\u043a\u0438\n12.1. \u0421\u043a\u0443\u043f\u0449\u0438\u043a \u0433. \u042e\u0436\u043d\u044b\u0439\n12.2. \u0421\u043a\u0443\u043f\u0449\u0438\u043a \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n\n13. \u0411\u0438\u0437\u043d\u0435\u0441\u044b\n\n14. \u041c\u043e\u044f \u043d\u0435\u0434\u0432\u0438\u0436\u0438\u043c\u043e\u0441\u0442\u044c\n14.1. \u0414\u043e\u043c\n14.2. \u041a\u0432\u0430\u0440\u0442\u0438\u0440\u0430\n14.3. \u0411\u0438\u0437\u043d\u0435\u0441\n14.4. \u0414\u043e\u043c \u0441\u0435\u043c\u044c\u0438\n\n15. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0435 \u043c\u0435\u0441\u0442\u0430\n15.1. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u0431\u0430\u043d\u043a\u043e\u043c\u0430\u0442\n15.2. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0430\u044f Grand \u0448\u0430\u0443\u0440\u043c\u0430\n15.3. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0430\u044f \u0437\u0430\u043f\u0440\u0430\u0432\u043a\u0430\n15.4. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u043c\u0430\u0433\u0430\u0437\u0438\u043d 24/7\n15.5. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u0440\u0435\u0441\u0442\u043e\u0440\u0430\u043d\n"

.field public static final FILE_NAME:Ljava/lang/String; = "navigator.cfg"

.field private static final ITEM_RE:Ljava/util/regex/Pattern;

.field public static final PREF_KEY:Ljava/lang/String; = "navigator_cfg"

.field private static final TELEPORT:[[Ljava/lang/String;


# direct methods
.method static final constructor <clinit>()V
    .locals 10

    const/16 v2, 0x9

    new-array v2, v2, [[Ljava/lang/String;

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x0

    const/16 v5, 0x9

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u041e\u0431\u0449\u0435\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043c\u0435\u0441\u0442\u0430"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0410\u0432\u0442\u043e\u0448\u043a\u043e\u043b\u0430|486 2276 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0412\u043e\u0435\u043d\u043a\u043e\u043c\u0430\u0442|1915 2302 15"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0411\u0430\u043d\u043a \u0433. \u042e\u0436\u043d\u044b\u0439|2372 -2142 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0411\u0430\u043d\u043a \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441|-143 593 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0411\u0430\u043d\u043a \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e|1855 2042 16"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x6

    const-string v8, "\u0426\u0435\u0440\u043a\u043e\u0432\u044c|1877 1166 30"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x7

    const-string v8, "\u0410\u0432\u0442\u043e\u0440\u044b\u043d\u043e\u043a|805 2300 18"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/16 v7, 0x8

    const-string v8, "\u041f\u043e\u0447\u0442\u043e\u0432\u043e\u0435 \u043e\u0442\u0434\u0435\u043b\u0435\u043d\u0438\u0435|801 1349 15"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u0412\u043e\u043a\u0437\u0430\u043b\u044b"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u0410\u0440\u0437\u0430\u043c\u0430\u0441|-560 931 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u042e\u0436\u043d\u044b\u0439|2734 -2447 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e|1813 2513 15"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u042d\u0434\u043e\u0432\u043e|-2478 2840 37"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0416\u0414 \u0412\u043e\u043a\u0437\u0430\u043b \u042e\u0436\u043d\u044b\u0439|2499 -2145 22"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x2

    const/16 v5, 0x8

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d\u044b / \u0421\u0442\u043e\u044f\u043d\u043a\u0438"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u042d\u043a\u043e\u043d\u043e\u043c|2323 -1800 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041a\u043e\u043c\u0444\u043e\u0440\u0442|2217 2891 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041f\u0440\u0435\u043c\u0438\u0443\u043c|602 998 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0410\u0440\u0437\u0430\u043c\u0430\u0441|420 584 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e|1748 2464 15"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x6

    const-string v8, "\u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u042e\u0436\u043d\u044b\u0439|2441 -1734 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x7

    const-string v8, "\u0421\u0422\u041e \"\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440\"|711 525 12"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x3

    const/16 v5, 0x9

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u041f\u0440\u0430\u0432\u0438\u0442\u0435\u043b\u044c\u0441\u0442\u0432\u043e|-78 839 17"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0412\u043e\u0438\u043d\u0441\u043a\u0430\u044f \u0447\u0430\u0441\u0442\u044c|1901 1718 16"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441|361 1332 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u042e\u0436\u043d\u044b\u0439|2118 -2386 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u041d\u043e\u0432\u043e\u0441\u0442\u043d\u0430\u044f \u0441\u0435\u0442\u044c|2130 -1945 20"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x6

    const-string v8, "\u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441|153 1265 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x7

    const-string v8, "\u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u042e\u0436\u043d\u044b\u0439|2582 -2421 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/16 v7, 0x8

    const-string v8, "\u0424\u0421\u0411|1896 -1995 31"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u041a\u0440\u0438\u043c\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0422\u0430\u043c\u0431\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413|2429 -1932 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u041a\u0443\u0440\u0433\u0430\u043d\u0441\u043a\u0430\u044f \u041e\u041f\u0413|2285 1369 11"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u041e\u0440\u0435\u0445\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413|488 747 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u041a\u0430\u0432\u043a\u0430\u0437\u0441\u043a\u0430\u044f \u041e\u041f\u0413|-2340 27 21"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0427\u0435\u0440\u043d\u044b\u0439 \u0440\u044b\u043d\u043e\u043a|-2246 241 24"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u044b\u0435 \u0440\u0430\u0431\u043e\u0442\u044b"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0417\u0430\u0432\u043e\u0434 Twix|2262 2149 16"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0417\u0430\u0432\u043e\u0434 Tesla|-2547 534 9"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0428\u0430\u0445\u0442\u0430|-1102 1365 31"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0424\u0435\u0440\u043c\u0430|950 -910 39"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x6

    const/16 v5, 0x8

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u0420\u0430\u0431\u043e\u0442\u044b"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0422\u0430\u043a\u0441\u0438|757 757 11"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0412\u043e\u0434\u0438\u0442\u0435\u043b\u044c \u0430\u0432\u0442\u043e\u0431\u0443\u0441\u0430|786 750 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u041f\u043e\u0447\u0442\u0430\u043b\u044c\u043e\u043d|804 1349 14"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u041c\u0435\u0445\u0430\u043d\u0438\u043a|2132 -1847 19"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0418\u043d\u043a\u0430\u0441\u0441\u0430\u0442\u043e\u0440|1775 -2285 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x6

    const-string v8, "\u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u042e\u0436\u043d\u044b\u0439|2648 -1902 22"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x7

    const-string v8, "\u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u0410\u0440\u0437\u0430\u043c\u0430\u0441|636 897 12"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u0414\u0430\u043b\u044c\u043d\u043e\u0431\u043e\u0439"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0433\u0440\u0443\u0437\u0430|164 -464 10"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u043d\u0430\u044f \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u044f \u0413\u0440\u0443\u0437-\u041a\u043e\u043d\u043d\u0435\u043a\u0442|1786 489 16"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u043d\u0430\u044f \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u044f \u0412\u0435\u043a\u0442\u043e\u0440 \u0433\u0440\u0443\u0437|-1523 2481 42"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x4

    const-string v8, "\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u043d\u0430\u044f \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u044f \u0422\u0440\u0430\u043d\u0441-\u0413\u0440\u0443\u0437-\u041b\u0438\u0437|1847 2918 12"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x5

    const-string v8, "\u0422\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u043d\u0430\u044f \u043a\u043e\u043c\u043f\u0430\u043d\u0438\u044f \u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u0430\u044f \u21161|2200 -862 15"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    move-object v9, v2

    move-object v2, v9

    move-object v3, v9

    const/16 v4, 0x8

    const/4 v5, 0x4

    new-array v5, v5, [Ljava/lang/String;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x0

    const-string v8, "\u041e\u0441\u043d\u043e\u0432\u043d\u044b\u0435 \u043c\u0435\u0441\u0442\u0430"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x1

    const-string v8, "\u0424\u0432, \u0424\u0443\u0440\u0430|1567.848 -130.373 25.595"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x2

    const-string v8, "\u041b\u0435\u0441\u043e\u043f\u0438\u043b\u043a\u0430|-1044 -2478 28"

    aput-object v8, v6, v7

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const/4 v7, 0x3

    const-string v8, "\u0413\u043b\u0430\u0432\u043d\u044b\u0439 \u0441\u043a\u043b\u0430\u0434|2489 340 30"

    aput-object v8, v6, v7

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/NavData;->TELEPORT:[[Ljava/lang/String;

    const-string v2, "^(\\d+)\\.\\s+(.+)$"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/NavData;->CAT_RE:Ljava/util/regex/Pattern;

    const-string v2, "^(\\d+)\\.(\\d+)\\.?\\s+(.+)$"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/NavData;->ITEM_RE:Ljava/util/regex/Pattern;

    return-void
.end method

.method constructor <init>()V
    .locals 3

    .prologue
    .line 12
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static cleanName(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    .prologue
    .line 224
    move-object v0, p0

    move-object v4, v0

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v2, v4

    .line 225
    :goto_0
    move-object v4, v2

    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_0

    .line 226
    move-object v4, v2

    move-object v0, v4

    return-object v0

    .line 225
    :cond_0
    move-object v4, v2

    const/4 v5, 0x0

    move-object v6, v2

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v7, 0x1

    add-int/lit8 v6, v6, -0x1

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v2, v4

    goto :goto_0
.end method

.method public static countItems(Ljava/util/List;)I
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;)I"
        }
    .end annotation

    .prologue
    .line 270
    move-object v0, p0

    const/4 v7, 0x0

    move v2, v7

    .line 271
    move-object v7, v0

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move-object v3, v7

    :goto_0
    move-object v7, v3

    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_0

    .line 272
    move v7, v2

    move v0, v7

    return v0

    .line 271
    :cond_0
    move-object v7, v3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lgtandroid/universal/NavData$Cat;

    move-object v5, v7

    move v7, v2

    move-object v8, v5

    iget-object v8, v8, Lgtandroid/universal/NavData$Cat;->items:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    add-int/2addr v7, v8

    move v2, v7

    goto :goto_0
.end method

.method public static defaultNavigator()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;"
        }
    .end annotation

    .prologue
    .line 217
    const-string v2, "1. \u0424\u0438\u043b\u0438\u0430\u043b ROSTIC\'S\n\n2. \u041e\u0431\u0449\u0435\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043c\u0435\u0441\u0442\u0430\n2.1. \u0410\u0432\u0442\u043e\u0448\u043a\u043e\u043b\u0430\n2.2. \u0412\u043e\u0435\u043d\u043a\u043e\u043c\u0430\u0442\n2.3. \u0411\u0430\u043d\u043a \u0433. \u042e\u0436\u043d\u044b\u0439\n2.4. \u0411\u0430\u043d\u043a \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n2.5. \u0411\u0430\u043d\u043a \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n2.6. \u0426\u0435\u0440\u043a\u043e\u0432\u044c\n2.7. \u0410\u0432\u0442\u043e\u0440\u044b\u043d\u043e\u043a\n2.8. \u041f\u043e\u0447\u0442\u043e\u0432\u043e\u0435 \u043e\u0442\u0434\u0435\u043b\u0435\u043d\u0438\u0435\n\n3. \u0412\u043e\u043a\u0437\u0430\u043b\u044b\n3.1. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n3.2. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u042e\u0436\u043d\u044b\u0439\n3.3. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n3.4. \u0410\u0432\u0442\u043e\u0432\u043e\u043a\u0437\u0430\u043b \u043f\u0433\u0442. \u042d\u0434\u043e\u0432\u043e\n3.5. \u041c\u043e\u0440\u0441\u043a\u043e\u0439 \u0432\u043e\u043a\u0437\u0430\u043b \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n\n4. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d\u044b / \u0441\u0442\u043e\u044f\u043d\u043a\u0438\n4.1. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u042d\u043a\u043e\u043d\u043e\u043c\n4.2. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041a\u043e\u043c\u0444\u043e\u0440\u0442\n4.3. \u0410\u0432\u0442\u043e\u0441\u0430\u043b\u043e\u043d \u041f\u0440\u0435\u043c\u0438\u0443\u043c\n4.4. \u041c\u043e\u0442\u043e\u0441\u0430\u043b\u043e\u043d\n4.5. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n4.6. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u043f\u0433\u0442. \u0411\u0430\u0442\u044b\u0440\u0435\u0432\u043e\n4.7. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u042e\u0436\u043d\u044b\u0439\n4.8. \u0421\u0442\u043e\u044f\u043d\u043a\u0430 \u0433. \u042d\u0434\u043e\u0432\u043e\n4.9. \u0421\u0422\u041e \'\u0420\u0435\u0430\u043a\u0442\u043e\u0440\'\n\n5. \u0413\u043e\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438\n5.1. \u041f\u0440\u0430\u0432\u0438\u0442\u0435\u043b\u044c\u0441\u0442\u0432\u043e\n5.2. \u0412\u043e\u0438\u043d\u0441\u043a\u0430\u044f \u0447\u0430\u0441\u0442\u044c\n5.3. \u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n5.4. \u0411\u043e\u043b\u044c\u043d\u0438\u0446\u0430 \u0433. \u042e\u0436\u043d\u044b\u0439\n5.5. \u041d\u043e\u0432\u043e\u0441\u0442\u043d\u0430\u044f \u0441\u0435\u0442\u044c\n5.6. \u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n5.7. \u041f\u043e\u043b\u0438\u0446\u0438\u044f \u0433. \u042e\u0436\u043d\u044b\u0439\n5.8. \u0424\u0421\u0411\n\n6. \u041a\u0440\u0438\u043c\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0435 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0446\u0438\u0438\n6.1. \u0422\u0430\u043c\u0431\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.2. \u041a\u0443\u0440\u0433\u0430\u043d\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.3. \u041e\u0440\u0435\u0445\u043e\u0432\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.4. \u041a\u0430\u0432\u043a\u0430\u0437\u0441\u043a\u0430\u044f \u041e\u041f\u0413\n6.5. \u0427\u0451\u0440\u043d\u044b\u0439 \u0440\u044b\u043d\u043e\u043a\n\n7. \u041d\u0430\u0447\u0430\u043b\u044c\u043d\u044b\u0435 \u0440\u0430\u0431\u043e\u0442\u044b\n7.1. \u0417\u0430\u0432\u043e\u0434 Tesla\n7.2. \u0417\u0430\u0432\u043e\u0434 \u0421\u0422\u0415\u041f\n7.3. \u0428\u0430\u0445\u0442\u0430\n7.4. \u0424\u0435\u0440\u043c\u0430\n7.5. \u0421\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u043e\u0447\u043d\u044b\u0439 \u0446\u0435\u043d\u0442\u0440\n7.6. \u0420\u0435\u0441\u0442\u043e\u0440\u0430\u043d ROSTIC\'S\n\n8. \u0420\u0430\u0431\u043e\u0442\u044b\n8.1. \u0422\u0430\u043a\u0441\u0438\u0441\u0442\n8.2. \u0412\u043e\u0434\u0438\u0442\u0435\u043b\u044c \u0430\u0432\u0442\u043e\u0431\u0443\u0441\u0430\n8.3. \u041f\u043e\u0447\u0442\u0430\u043b\u044c\u043e\u043d\n8.4. \u041c\u0435\u0445\u0430\u043d\u0438\u043a\n8.5. \u0414\u0430\u043b\u044c\u043d\u043e\u0431\u043e\u0439\u0449\u0438\u043a\n8.6. \u0418\u043d\u043a\u0430\u0441\u0441\u0430\u0442\u043e\u0440\n8.7. \u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u042e\u0436\u043d\u043e\u0433\u043e\n8.8. \u0414\u043e\u0440\u043e\u0436\u043d\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u0410\u0440\u0437\u0430\u043c\u0430\u0441\u0430\n8.9. \u041c\u0443\u0441\u043e\u0440\u0449\u0438\u043a\n8.10. \u0420\u044b\u0431\u0430\u043b\u043a\u0430\n\n9. \u0420\u0430\u0437\u0432\u043b\u0435\u0447\u0435\u043d\u0438\u044f\n9.1. Grand Casino\n9.2. \u0410\u0443\u043a\u0446\u0438\u043e\u043d \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440\u043e\u0432\n9.3. \u0414\u0440\u0438\u0444\u0442 \u0437\u043e\u043d\u0430\n9.4. \u041f\u0430\u0440\u043a \u043e\u0442\u0434\u044b\u0445\u0430\n\n10. \u041d\u043e\u0442\u0430\u0440\u0438\u0430\u043b\u044c\u043d\u043e\u0435 \u0410\u0433\u0435\u043d\u0442\u0441\u0442\u0432\u043e\n\n11. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0435 \u0438 \u043c\u043e\u0440\u0441\u043a\u0438\u0435 \u043a\u043b\u0443\u0431\u044b\n11.1. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0439 \u043a\u043b\u0443\u0431 \u0433. \u042e\u0436\u043d\u044b\u0439\n11.2. \u0412\u0435\u0440\u0442\u043e\u043b\u0451\u0442\u043d\u044b\u0439 \u043a\u043b\u0443\u0431 \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n11.3. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21161\n11.4. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21162\n11.5. \u042f\u0445\u0442-\u043a\u043b\u0443\u0431 \u21163\n\n12. \u0421\u043a\u0443\u043f\u0449\u0438\u043a\u0438\n12.1. \u0421\u043a\u0443\u043f\u0449\u0438\u043a \u0433. \u042e\u0436\u043d\u044b\u0439\n12.2. \u0421\u043a\u0443\u043f\u0449\u0438\u043a \u0433. \u0410\u0440\u0437\u0430\u043c\u0430\u0441\n\n13. \u0411\u0438\u0437\u043d\u0435\u0441\u044b\n\n14. \u041c\u043e\u044f \u043d\u0435\u0434\u0432\u0438\u0436\u0438\u043c\u043e\u0441\u0442\u044c\n14.1. \u0414\u043e\u043c\n14.2. \u041a\u0432\u0430\u0440\u0442\u0438\u0440\u0430\n14.3. \u0411\u0438\u0437\u043d\u0435\u0441\n14.4. \u0414\u043e\u043c \u0441\u0435\u043c\u044c\u0438\n\n15. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0435 \u043c\u0435\u0441\u0442\u0430\n15.1. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u0431\u0430\u043d\u043a\u043e\u043c\u0430\u0442\n15.2. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0430\u044f Grand \u0448\u0430\u0443\u0440\u043c\u0430\n15.3. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0430\u044f \u0437\u0430\u043f\u0440\u0430\u0432\u043a\u0430\n15.4. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u043c\u0430\u0433\u0430\u0437\u0438\u043d 24/7\n15.5. \u0411\u043b\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u0440\u0435\u0441\u0442\u043e\u0440\u0430\u043d\n"

    invoke-static {v2}, Lgtandroid/universal/NavData;->parse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    move-object v0, v2

    return-object v0
.end method

.method public static loadNavigator(Landroid/content/SharedPreferences;)Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            ")",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;"
        }
    .end annotation

    .prologue
    .line 276
    move-object v0, p0

    move-object v5, v0

    if-nez v5, :cond_0

    const/4 v5, 0x0

    check-cast v5, Ljava/lang/String;

    :goto_0
    move-object v2, v5

    .line 277
    move-object v5, v2

    if-eqz v5, :cond_1

    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    .line 278
    move-object v5, v2

    invoke-static {v5}, Lgtandroid/universal/NavData;->parse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v5

    move-object v3, v5

    .line 279
    move-object v5, v3

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    move-object v5, v3

    move-object v0, v5

    .line 281
    :goto_1
    return-object v0

    .line 276
    :cond_0
    move-object v5, v0

    const-string v6, "navigator_cfg"

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    .line 281
    :cond_1
    invoke-static {}, Lgtandroid/universal/NavData;->defaultNavigator()Ljava/util/List;

    move-result-object v5

    move-object v0, v5

    goto :goto_1
.end method

.method public static parse(Ljava/lang/String;)Ljava/util/List;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;"
        }
    .end annotation

    .prologue
    .line 230
    move-object/from16 v0, p0

    new-instance v12, Ljava/util/ArrayList;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v12

    .line 231
    move-object v12, v0

    if-nez v12, :cond_0

    move-object v12, v2

    move-object v0, v12

    .line 253
    :goto_0
    return-object v0

    .line 232
    :cond_0
    move-object v12, v0

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v13, 0x0

    if-le v12, v13, :cond_1

    move-object v12, v0

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Ljava/lang/String;->charAt(I)C

    move-result v12

    const v13, 0xfeff

    if-ne v12, v13, :cond_1

    move-object v12, v0

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    move-object v0, v12

    .line 234
    :cond_1
    move-object v12, v0

    const/16 v13, 0xa0

    const/16 v14, 0x20

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x2007

    const/16 v14, 0x20

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x202f

    const/16 v14, 0x20

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v12

    move-object v0, v12

    .line 235
    const/4 v12, 0x0

    check-cast v12, Lgtandroid/universal/NavData$Cat;

    move-object v3, v12

    .line 236
    move-object v12, v0

    const-string v13, "\\r?\\n"

    invoke-virtual {v12, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    move-object v4, v12

    const/4 v12, 0x0

    move v5, v12

    .line 250
    :goto_1
    move v12, v5

    move-object v13, v4

    array-length v13, v13

    if-lt v12, v13, :cond_2

    .line 253
    move-object v12, v2

    move-object v0, v12

    goto :goto_0

    .line 236
    :cond_2
    move-object v12, v4

    move v13, v5

    aget-object v12, v12, v13

    move-object v6, v12

    .line 237
    move-object v12, v6

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    move-object v7, v12

    .line 238
    move-object v12, v7

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_4

    .line 250
    :cond_3
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 239
    :cond_4
    sget-object v12, Lgtandroid/universal/NavData;->ITEM_RE:Ljava/util/regex/Pattern;

    move-object v13, v7

    invoke-virtual {v12, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v12

    move-object v8, v12

    .line 240
    move-object v12, v8

    invoke-virtual {v12}, Ljava/util/regex/Matcher;->find()Z

    move-result v12

    if-eqz v12, :cond_6

    .line 241
    move-object v12, v8

    const/4 v13, 0x3

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Lgtandroid/universal/NavData;->cleanName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v9, v12

    .line 242
    move-object v12, v3

    if-eqz v12, :cond_5

    move-object v12, v9

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_5

    move-object v12, v3

    iget-object v12, v12, Lgtandroid/universal/NavData$Cat;->items:Ljava/util/List;

    new-instance v13, Lgtandroid/universal/NavData$Item;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    move-object v15, v9

    const-string v16, ""

    invoke-direct/range {v14 .. v16}, Lgtandroid/universal/NavData$Item;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v12

    .line 243
    :cond_5
    goto :goto_2

    .line 245
    :cond_6
    sget-object v12, Lgtandroid/universal/NavData;->CAT_RE:Ljava/util/regex/Pattern;

    move-object v13, v7

    invoke-virtual {v12, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v12

    move-object v9, v12

    .line 246
    move-object v12, v9

    invoke-virtual {v12}, Ljava/util/regex/Matcher;->find()Z

    move-result v12

    if-eqz v12, :cond_3

    .line 247
    move-object v12, v9

    const/4 v13, 0x2

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Lgtandroid/universal/NavData;->cleanName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v10, v12

    .line 248
    move-object v12, v10

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_7

    goto :goto_2

    .line 249
    :cond_7
    new-instance v12, Lgtandroid/universal/NavData$Cat;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    move-object v14, v10

    invoke-direct {v13, v14}, Lgtandroid/universal/NavData$Cat;-><init>(Ljava/lang/String;)V

    move-object v3, v12

    .line 250
    move-object v12, v2

    move-object v13, v3

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v12

    goto :goto_2
.end method

.method public static resetNavigator(Landroid/content/SharedPreferences;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            ")V"
        }
    .end annotation

    .prologue
    .line 289
    move-object v0, p0

    move-object v3, v0

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "navigator_cfg"

    invoke-interface {v3, v4}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static saveNavigator(Landroid/content/SharedPreferences;Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 285
    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "navigator_cfg"

    move-object v6, v1

    invoke-static {v6}, Lgtandroid/universal/NavData;->toCfg(Ljava/util/List;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static teleport()Ljava/util/List;
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;"
        }
    .end annotation

    .prologue
    .line 102
    new-instance v9, Ljava/util/ArrayList;

    move-object/from16 v16, v9

    move-object/from16 v9, v16

    move-object/from16 v10, v16

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v9

    .line 103
    sget-object v9, Lgtandroid/universal/NavData;->TELEPORT:[[Ljava/lang/String;

    move-object v2, v9

    const/4 v9, 0x0

    move v3, v9

    .line 109
    :goto_0
    move v9, v3

    move-object v10, v2

    array-length v10, v10

    if-lt v9, v10, :cond_0

    .line 111
    move-object v9, v1

    move-object v0, v9

    return-object v0

    .line 103
    :cond_0
    move-object v9, v2

    move v10, v3

    aget-object v9, v9, v10

    move-object v4, v9

    .line 104
    new-instance v9, Lgtandroid/universal/NavData$Cat;

    move-object/from16 v16, v9

    move-object/from16 v9, v16

    move-object/from16 v10, v16

    move-object v11, v4

    const/4 v12, 0x0

    aget-object v11, v11, v12

    invoke-direct {v10, v11}, Lgtandroid/universal/NavData$Cat;-><init>(Ljava/lang/String;)V

    move-object v5, v9

    .line 105
    const/4 v9, 0x1

    move v6, v9

    :goto_1
    move v9, v6

    move-object v10, v4

    array-length v10, v10

    if-lt v9, v10, :cond_1

    .line 109
    move-object v9, v1

    move-object v10, v5

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v9

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 106
    :cond_1
    move-object v9, v4

    move v10, v6

    aget-object v9, v9, v10

    const/16 v10, 0x7c

    invoke-virtual {v9, v10}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v9

    move v7, v9

    .line 107
    move-object v9, v5

    iget-object v9, v9, Lgtandroid/universal/NavData$Cat;->items:Ljava/util/List;

    new-instance v10, Lgtandroid/universal/NavData$Item;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v4

    move v13, v6

    aget-object v12, v12, v13

    const/4 v13, 0x0

    move v14, v7

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v12

    move-object v13, v4

    move v14, v6

    aget-object v13, v13, v14

    move v14, v7

    const/4 v15, 0x1

    add-int/lit8 v14, v14, 0x1

    invoke-virtual {v13, v14}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v13

    invoke-direct {v11, v12, v13}, Lgtandroid/universal/NavData$Item;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v9

    .line 105
    add-int/lit8 v6, v6, 0x1

    goto :goto_1
.end method

.method public static toCfg(Ljava/util/List;)Ljava/lang/String;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/NavData$Cat;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .prologue
    .line 257
    move-object v0, p0

    new-instance v7, Ljava/lang/StringBuilder;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v7

    .line 258
    const/4 v7, 0x0

    move v3, v7

    :goto_0
    move v7, v3

    move-object v8, v0

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-lt v7, v8, :cond_0

    .line 266
    move-object v7, v2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v0, v7

    return-object v0

    .line 259
    :cond_0
    move-object v7, v0

    move v8, v3

    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lgtandroid/universal/NavData$Cat;

    move-object v4, v7

    .line 260
    move v7, v3

    const/4 v8, 0x0

    if-le v7, v8, :cond_1

    move-object v7, v2

    const-string v8, "\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 261
    :cond_1
    move-object v7, v2

    move v8, v3

    const/4 v9, 0x1

    add-int/lit8 v8, v8, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ". "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v4

    iget-object v8, v8, Lgtandroid/universal/NavData$Cat;->name:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 262
    const/4 v7, 0x0

    move v5, v7

    :goto_1
    move v7, v5

    move-object v8, v4

    iget-object v8, v8, Lgtandroid/universal/NavData$Cat;->items:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-lt v7, v8, :cond_2

    .line 258
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 263
    :cond_2
    move-object v7, v2

    move v8, v3

    const/4 v9, 0x1

    add-int/lit8 v8, v8, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "."

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move v8, v5

    const/4 v9, 0x1

    add-int/lit8 v8, v8, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ". "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v4

    iget-object v8, v8, Lgtandroid/universal/NavData$Cat;->items:Ljava/util/List;

    move v9, v5

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/NavData$Item;

    iget-object v8, v8, Lgtandroid/universal/NavData$Item;->name:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 262
    add-int/lit8 v5, v5, 0x1

    goto :goto_1
.end method
