.class Lgtandroid/universal/MainActivity$100000022;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000022"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$index:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000022;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/MainActivity$100000022;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000022;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000022;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1192
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000022;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v8}, Lgtandroid/universal/MainActivity;->access$1000064(Lgtandroid/universal/MainActivity;)Lorg/json/JSONArray;

    move-result-object v8

    move-object v4, v8

    .line 1193
    new-instance v8, Lorg/json/JSONArray;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    move-object v5, v8

    .line 1194
    const/4 v8, 0x0

    move v6, v8

    :goto_0
    move v8, v6

    move-object v9, v4

    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-lt v8, v9, :cond_0

    .line 1197
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000022;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v5

    invoke-static {v8, v9}, Lgtandroid/universal/MainActivity;->access$1000065(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V

    .line 1198
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000022;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v8}, Lgtandroid/universal/MainActivity;->access$1000077(Lgtandroid/universal/MainActivity;)V

    return-void

    .line 1195
    :cond_0
    move v8, v6

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/MainActivity$100000022;->val$index:I

    if-eq v8, v9, :cond_1

    move-object v8, v5

    move-object v9, v4

    move v10, v6

    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v8

    .line 1194
    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0
.end method
