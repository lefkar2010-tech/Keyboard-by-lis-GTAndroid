.class Lgtandroid/universal/MyAccessibilityService$100000001;
.super Ljava/lang/Object;
.source "MyAccessibilityService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MyAccessibilityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final val$svc:Lgtandroid/universal/MyAccessibilityService;


# direct methods
.method constructor <init>(Lgtandroid/universal/MyAccessibilityService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MyAccessibilityService$100000001;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 113
    move-object v0, p0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MyAccessibilityService$100000001;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    invoke-virtual {v6}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v2, v6

    .line 114
    move-object v6, v2

    if-nez v6, :cond_0

    .line 123
    :goto_0
    return-void

    .line 116
    :cond_0
    move-object v6, v2

    invoke-static {v6}, Lgtandroid/universal/MyAccessibilityService;->access$1000004(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v3, v6

    .line 118
    move-object v6, v3

    if-eqz v6, :cond_1

    .line 119
    new-instance v6, Landroid/os/Bundle;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    move-object v4, v6

    .line 120
    move-object v6, v4

    const-string v7, "ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE"

    const-string v8, "\n"

    invoke-virtual {v6, v7, v8}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 121
    move-object v6, v3

    const/high16 v7, 0x200000

    move-object v8, v4

    invoke-virtual {v6, v7, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z

    move-result v6

    .line 123
    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_1
    goto :goto_0
.end method
