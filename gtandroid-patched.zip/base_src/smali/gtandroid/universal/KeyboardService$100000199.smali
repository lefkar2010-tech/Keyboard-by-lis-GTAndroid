.class Lgtandroid/universal/KeyboardService$100000199;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000199"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000199;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000199;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000199;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 7112
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000199;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService;->access$L1000063(Lgtandroid/universal/KeyboardService;)Landroid/widget/HorizontalScrollView;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/widget/HorizontalScrollView;->scrollTo(II)V

    return-void
.end method
