.class Lgtandroid/universal/MainActivity$100000052$100000051;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity$100000052;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000051"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity$100000052;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity$100000052;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MainActivity$100000052$100000051;->this$0:Lgtandroid/universal/MainActivity$100000052;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000052$100000051;)Lgtandroid/universal/MainActivity$100000052;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000052$100000051;->this$0:Lgtandroid/universal/MainActivity$100000052;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1847
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000052$100000051;->this$0:Lgtandroid/universal/MainActivity$100000052;

    invoke-static {v4}, Lgtandroid/universal/MainActivity$100000052;->access$0(Lgtandroid/universal/MainActivity$100000052;)Lgtandroid/universal/MainActivity;

    move-result-object v4

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v4}, Lgtandroid/universal/NavData;->resetNavigator(Landroid/content/SharedPreferences;)V

    .line 1848
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000052$100000051;->this$0:Lgtandroid/universal/MainActivity$100000052;

    invoke-static {v4}, Lgtandroid/universal/MainActivity$100000052;->access$0(Lgtandroid/universal/MainActivity$100000052;)Lgtandroid/universal/MainActivity;

    move-result-object v4

    const-string v5, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 1849
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000052$100000051;->this$0:Lgtandroid/universal/MainActivity$100000052;

    invoke-static {v4}, Lgtandroid/universal/MainActivity$100000052;->access$0(Lgtandroid/universal/MainActivity$100000052;)Lgtandroid/universal/MainActivity;

    move-result-object v4

    invoke-static {v4}, Lgtandroid/universal/MainActivity;->access$1000130(Lgtandroid/universal/MainActivity;)V

    return-void
.end method
