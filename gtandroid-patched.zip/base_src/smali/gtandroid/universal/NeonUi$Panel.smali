.class public Lgtandroid/universal/NeonUi$Panel;
.super Landroid/graphics/drawable/GradientDrawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Panel"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 132
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    return-void
.end method
