.class Lgtandroid/universal/AreaSelectorService$100000004;
.super Ljava/lang/Object;
.source "AreaSelectorService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/AreaSelectorService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000004"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/AreaSelectorService;


# direct methods
.method constructor <init>(Lgtandroid/universal/AreaSelectorService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/AreaSelectorService$100000004;)Lgtandroid/universal/AreaSelectorService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 477
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v2}, Lgtandroid/universal/AreaSelectorService;->access$L1000002(Lgtandroid/universal/AreaSelectorService;)Landroid/widget/FrameLayout;

    move-result-object v2

    if-eqz v2, :cond_0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v2}, Lgtandroid/universal/AreaSelectorService;->access$L1000001(Lgtandroid/universal/AreaSelectorService;)Landroid/widget/FrameLayout;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 478
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v2}, Lgtandroid/universal/AreaSelectorService;->access$1000046(Lgtandroid/universal/AreaSelectorService;)V

    .line 480
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService$100000004;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v2}, Lgtandroid/universal/AreaSelectorService;->access$L1000032(Lgtandroid/universal/AreaSelectorService;)Landroid/os/Handler;

    move-result-object v2

    move-object v3, v0

    const/16 v4, 0x64

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method
