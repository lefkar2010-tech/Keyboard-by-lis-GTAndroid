.class Lgtandroid/universal/MainActivity$100000054;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000054"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$dlg:Landroid/app/AlertDialog;

.field private final val$etLines:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000054;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000054;->val$etLines:Landroid/widget/EditText;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000054;->val$dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000054;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000054;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1960
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000054;->val$etLines:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    move-object v3, v10

    .line 1961
    new-instance v10, Ljava/util/ArrayList;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    move-object v4, v10

    .line 1962
    move-object v10, v3

    const-string v11, "\n"

    invoke-virtual {v10, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    move-object v5, v10

    const/4 v10, 0x0

    move v6, v10

    .line 1964
    :goto_0
    move v10, v6

    move-object v11, v5

    array-length v11, v11

    if-lt v10, v11, :cond_0

    .line 1966
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000054;->this$0:Lgtandroid/universal/MainActivity;

    move-object v11, v4

    invoke-static {v10, v11}, Lgtandroid/universal/MainActivity;->access$1000108(Lgtandroid/universal/MainActivity;Ljava/util/List;)V

    .line 1967
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000054;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v14, v12

    move-object v12, v14

    move-object v13, v14

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v4

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, " \u043a\u043e\u043c\u0430\u043d\u0434"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x0

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    .line 1968
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000054;->val$dlg:Landroid/app/AlertDialog;

    invoke-virtual {v10}, Landroid/app/Dialog;->dismiss()V

    return-void

    .line 1962
    :cond_0
    move-object v10, v5

    move v11, v6

    aget-object v10, v10, v11

    move-object v7, v10

    .line 1963
    move-object v10, v7

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v8, v10

    .line 1964
    move-object v10, v8

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_1

    move-object v10, v4

    move-object v11, v8

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0
.end method
