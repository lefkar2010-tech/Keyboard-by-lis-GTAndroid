.class Lgtandroid/universal/NeonUi$100000001;
.super Ljava/lang/Object;
.source "NeonUi.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final val$haptic:Z

.field private final val$scale:F


# direct methods
.method constructor <init>(ZF)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move v5, v1

    iput-boolean v5, v4, Lgtandroid/universal/NeonUi$100000001;->val$haptic:Z

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/NeonUi$100000001;->val$scale:F

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 10
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 712
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v7, v3

    invoke-virtual {v7}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v7

    move v5, v7

    .line 713
    move v7, v5

    const/4 v8, 0x0

    if-ne v7, v8, :cond_2

    .line 714
    move-object v7, v1

    iget-boolean v7, v7, Lgtandroid/universal/NeonUi$100000001;->val$haptic:Z

    if-eqz v7, :cond_0

    move-object v7, v2

    const/4 v8, 0x3

    invoke-virtual {v7, v8}, Landroid/view/View;->performHapticFeedback(I)Z

    move-result v7

    .line 715
    :cond_0
    move-object v7, v2

    invoke-virtual {v7}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    move-object v8, v1

    iget v8, v8, Lgtandroid/universal/NeonUi$100000001;->val$scale:F

    invoke-virtual {v7, v8}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    move-object v8, v1

    iget v8, v8, Lgtandroid/universal/NeonUi$100000001;->val$scale:F

    invoke-virtual {v7, v8}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    const/16 v8, 0x46

    int-to-long v8, v8

    invoke-virtual {v7, v8, v9}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 719
    :cond_1
    :goto_0
    const/4 v7, 0x0

    move v1, v7

    return v1

    .line 716
    :cond_2
    move v7, v5

    const/4 v8, 0x1

    if-eq v7, v8, :cond_3

    move v7, v5

    const/4 v8, 0x3

    if-ne v7, v8, :cond_1

    .line 717
    :cond_3
    move-object v7, v2

    invoke-virtual {v7}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-virtual {v7, v8}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-virtual {v7, v8}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    const/16 v8, 0x6e

    int-to-long v8, v8

    invoke-virtual {v7, v8, v9}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/ViewPropertyAnimator;->start()V

    goto :goto_0
.end method
