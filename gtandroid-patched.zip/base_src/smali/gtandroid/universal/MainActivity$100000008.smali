.class Lgtandroid/universal/MainActivity$100000008;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000008"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000008;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 498
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v5}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v5

    if-nez v5, :cond_0

    .line 499
    new-instance v5, Landroid/content/Intent;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const-string v7, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "package:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    invoke-virtual {v9}, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v8

    invoke-direct {v6, v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    move-object v3, v5

    .line 501
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 502
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    const-string v6, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043d\u0430\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043f\u043e\u0432\u0435\u0440\u0445 \u043e\u043a\u043e\u043d"

    const/4 v7, 0x1

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    .line 505
    :goto_0
    return-void

    .line 504
    :cond_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v5}, Lgtandroid/universal/MainActivity;->access$1000035(Lgtandroid/universal/MainActivity;)V

    .line 505
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000008;->this$0:Lgtandroid/universal/MainActivity;

    const-string v6, "\ud83d\udd14 \u0417\u0430\u0439\u0434\u0438\u0442\u0435 \u0432 \u0438\u0433\u0440\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \"\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c\" \u0432 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u0438"

    const/4 v7, 0x1

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
