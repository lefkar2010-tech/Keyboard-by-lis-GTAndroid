.class Lgtandroid/universal/KeyboardService$100000174;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000174"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000174$100000173;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$armed:[Z

.field private final val$btnClear:Landroid/widget/Button;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;[ZLandroid/widget/Button;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174;->val$armed:[Z

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174;->val$btnClear:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000174;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000174;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6045
    move-object v1, p0

    move-object/from16 v2, p1

    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->val$armed:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    if-nez v8, :cond_0

    .line 6046
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->val$armed:[Z

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-boolean v10, v8, v9

    .line 6047
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->val$btnClear:Landroid/widget/Button;

    const-string v9, "\u0422\u043e\u0447\u043d\u043e?"

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6048
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->val$btnClear:Landroid/widget/Button;

    const/16 v9, -0x7576

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 6049
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->val$btnClear:Landroid/widget/Button;

    new-instance v9, Lgtandroid/universal/KeyboardService$100000174$100000173;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v1

    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/KeyboardService$100000174;->val$armed:[Z

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/KeyboardService$100000174;->val$btnClear:Landroid/widget/Button;

    invoke-direct {v10, v11, v12, v13}, Lgtandroid/universal/KeyboardService$100000174$100000173;-><init>(Lgtandroid/universal/KeyboardService$100000174;[ZLandroid/widget/Button;)V

    const/16 v10, 0xbb8

    int-to-long v10, v10

    invoke-virtual {v8, v9, v10, v11}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v8

    .line 6062
    :goto_0
    return-void

    .line 6059
    :cond_0
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v8}, Lgtandroid/universal/KeyboardService;->access$1000110(Lgtandroid/universal/KeyboardService;)Ljava/util/List;

    move-result-object v8

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v4, v8

    .line 6060
    :goto_1
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_1

    .line 6062
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v8}, Lgtandroid/universal/KeyboardService;->access$1000457(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 6059
    :cond_1
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/ReportData;

    move-object v6, v8

    .line 6060
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000174;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v9, v6

    invoke-static {v8, v9}, Lgtandroid/universal/KeyboardService;->access$1000474(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V

    goto :goto_1
.end method
