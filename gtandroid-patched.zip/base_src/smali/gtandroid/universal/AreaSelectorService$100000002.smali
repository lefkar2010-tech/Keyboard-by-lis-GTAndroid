.class Lgtandroid/universal/AreaSelectorService$100000002;
.super Ljava/lang/Object;
.source "AreaSelectorService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/AreaSelectorService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/AreaSelectorService;


# direct methods
.method constructor <init>(Lgtandroid/universal/AreaSelectorService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/AreaSelectorService$100000002;->this$0:Lgtandroid/universal/AreaSelectorService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/AreaSelectorService$100000002;)Lgtandroid/universal/AreaSelectorService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService$100000002;->this$0:Lgtandroid/universal/AreaSelectorService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 306
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService$100000002;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-virtual {v3}, Landroid/app/Service;->stopSelf()V

    return-void
.end method
