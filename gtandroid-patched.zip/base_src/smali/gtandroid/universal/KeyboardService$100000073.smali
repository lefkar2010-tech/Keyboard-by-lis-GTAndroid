.class Lgtandroid/universal/KeyboardService$100000073;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000073"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$attempt:I

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000073;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000073;->val$text:Ljava/lang/String;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/KeyboardService$100000073;->val$attempt:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000073;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000073;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3114
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000073;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000073;->val$text:Ljava/lang/String;

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/KeyboardService$100000073;->val$attempt:I

    const/4 v5, 0x1

    add-int/lit8 v4, v4, 0x1

    invoke-static {v2, v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000257(Lgtandroid/universal/KeyboardService;Ljava/lang/String;I)V

    return-void
.end method
