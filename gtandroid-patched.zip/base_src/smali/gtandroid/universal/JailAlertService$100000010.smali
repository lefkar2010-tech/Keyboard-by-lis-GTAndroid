.class Lgtandroid/universal/JailAlertService$100000010;
.super Ljava/lang/Object;
.source "JailAlertService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000010"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000010;->this$0:Lgtandroid/universal/JailAlertService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000010;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000010;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1350
    move-object v0, p0

    const-string v4, "AutoReport"

    const-string v5, "\u23f0 \u0410\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430 \u0438\u0441\u0447\u0435\u0437\u043b\u0430 \u043f\u043e \u0442\u0430\u0439\u043c\u0430\u0443\u0442\u0443 (30 \u0441\u0435\u043a)"

    invoke-static {v4, v5}, Lgtandroid/universal/JailAlertService;->access$1000017(Ljava/lang/String;Ljava/lang/String;)V

    .line 1351
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000010;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v4}, Lgtandroid/universal/JailAlertService;->access$1000124(Lgtandroid/universal/JailAlertService;)V

    .line 1352
    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "CLEAR_AUTO_FORM"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 1353
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000010;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v5, v2

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method
