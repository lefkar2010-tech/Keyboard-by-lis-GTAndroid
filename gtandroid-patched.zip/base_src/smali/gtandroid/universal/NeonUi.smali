.class public final Lgtandroid/universal/NeonUi;
.super Ljava/lang/Object;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/NeonUi$Panel;,
        Lgtandroid/universal/NeonUi$Btn;,
        Lgtandroid/universal/NeonUi$Shell;,
        Lgtandroid/universal/NeonUi$HeaderBg;,
        Lgtandroid/universal/NeonUi$Icon;,
        Lgtandroid/universal/NeonUi$Glyph;,
        Lgtandroid/universal/NeonUi$100000000;,
        Lgtandroid/universal/NeonUi$100000001;,
        Lgtandroid/universal/NeonUi$StatusBadge;,
        Lgtandroid/universal/NeonUi$IdPad;,
        Lgtandroid/universal/NeonUi$NumKeyBg;,
        Lgtandroid/universal/NeonUi$100000002;,
        Lgtandroid/universal/NeonUi$100000003;,
        Lgtandroid/universal/NeonUi$100000004;,
        Lgtandroid/universal/NeonUi$100000005;
    }
.end annotation


# static fields
.field public static final ACCENT_ADMIN:I = -0x4fe0

.field public static final ACCENT_AUTOREPORT:I = -0x95d5

.field public static final ACCENT_FAMWAR:I = -0xc12e96

.field public static final ACCENT_NORMAL:I = -0xc28401

.field public static final ACCENT_QUICK:I = -0xe6393a

.field public static final ACT_A_E:I = -0x3da600

.field public static final ACT_A_S:I = -0x5eda

.field public static final ACT_FOLLOW_E:I = -0x4fff92

.field public static final ACT_FOLLOW_S:I = -0xa338

.field public static final ACT_NO_E:I = -0x71f0e2

.field public static final ACT_NO_S:I = -0xc4b6

.field public static final ACT_OK_E:I = -0xf180d5

.field public static final ACT_OK_S:I = -0xc41fa6

.field public static final ACT_PUNISH_E:I = -0xa5eb48

.field public static final ACT_PUNISH_S:I = -0x5db401

.field public static final ACT_QUICK_E:I = -0xf4b948

.field public static final ACT_QUICK_S:I = -0xc26401

.field public static final BACK_END:I = -0xa5c030

.field public static final BACK_START:I = -0xd5d071

.field public static final BANNER_END:I = -0xd08401

.field public static final BANNER_START:I = -0xe1b028

.field public static final BG_BOTTOM:I = -0xefe4c6

.field public static final BG_TOP:I = -0xf4edda

.field public static final BORDER:I = -0xd13701

.field public static final DOT_RED:I = -0xd5c6

.field public static final GLYPH_ARROW_UP:I = 0x6a

.field public static final GLYPH_CAR:I = 0x69

.field public static final GLYPH_CHART:I = 0x6c

.field public static final GLYPH_CIRCLE_X:I = 0x71

.field public static final GLYPH_CLIPBOARD:I = 0x6f

.field public static final GLYPH_CUBE:I = 0x6b

.field public static final GLYPH_CUFFS:I = 0x74

.field public static final GLYPH_EYE_OFF:I = 0x66

.field public static final GLYPH_FUEL:I = 0x6d

.field public static final GLYPH_HAMMER:I = 0x67

.field public static final GLYPH_ID_CARD:I = 0x6e

.field public static final GLYPH_PIN:I = 0x72

.field public static final GLYPH_PISTOL:I = 0x73

.field public static final GLYPH_PLANE:I = 0x76

.field public static final GLYPH_SHIELD_CHECK:I = 0x78

.field public static final GLYPH_SHIELD_GUN:I = 0x75

.field public static final GLYPH_SNOW:I = 0x70

.field public static final GLYPH_STAMP:I = 0x77

.field public static final GLYPH_USER:I = 0x65

.field public static final GLYPH_WRENCH:I = 0x68

.field public static final ICON_BACK:I = 0x9

.field public static final ICON_BTN_DP:F = 24.0f

.field public static final ICON_CAR:I = 0x8

.field public static final ICON_CHAT:I = 0x4

.field public static final ICON_CHECK:I = 0x1

.field public static final ICON_CLOCK:I = 0xb

.field public static final ICON_CROSS:I = 0x2

.field public static final ICON_CROWN:I = 0xa

.field public static final ICON_HAMMER:I = 0x5

.field public static final ICON_NONE:I = 0x0

.field public static final ICON_PEOPLE:I = 0x7

.field public static final ICON_PERSON:I = 0xc

.field public static final ICON_SEND:I = 0xd

.field public static final ICON_SHIELD:I = 0x6

.field public static final ICON_SPEAKER:I = 0x3

.field public static final ICON_TAB_DP:F = 26.0f

.field public static final ICON_TRASH:I = 0xe

.field private static final INNER_BOTTOM:I = -0xf7f2e5

.field private static final INNER_STROKE:I = -0xe4d5b3

.field private static final INNER_TOP:I = -0xf5eede

.field public static final LINE_COLOR:I = -0x907937

.field public static final NARROW_SCREEN_DP:I = 0x208

.field public static final PRESS_SCALE:F = 0.96f

.field public static final PRESS_SCALE_TILE:F = 0.97f

.field public static final RADIUS_BACK_DP:F = 14.0f

.field public static final RADIUS_BANNER_DP:F = 16.0f

.field public static final RADIUS_BTN_DP:F = 14.0f

.field public static final RADIUS_CARD_DP:F = 12.0f

.field public static final RADIUS_SHELL_DP:F = 16.0f

.field public static final RADIUS_TAB_DP:F = 16.0f

.field public static final RADIUS_TILE_DP:F = 12.0f

.field public static final TAB_ADMIN_E:I = -0x479600

.field public static final TAB_ADMIN_S:I = -0x49d9

.field public static final TAB_AUTO_E:I = -0x3daff6

.field public static final TAB_AUTO_S:I = -0x65d5

.field public static final TAB_FAMWAR_E:I = -0xf180d5

.field public static final TAB_FAMWAR_S:I = -0xc41fa6

.field public static final TAB_NORMAL_E:I = -0xf3b042

.field public static final TAB_NORMAL_S:I = -0xc26401

.field public static final TAB_QUICK_E:I = -0xf58072

.field public static final TAB_QUICK_S:I = -0xdd221a

.field public static final TEXT_HEADER:I = -0x401901

.field public static final TEXT_MAIN:I = -0x150d01

.field public static final TEXT_SECONDARY:I = -0x705f28

.field public static final TILE_BOTTOM:I = -0xf3ebc8

.field public static final TILE_STROKE:I = -0x73d1b028

.field public static final TILE_TOP:I = -0xefe5bb

.field public static final TITLE_BLUE:I = -0x562b01


# direct methods
.method constructor <init>()V
    .locals 3

    .prologue
    .line 38
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static applyInnerPanel(Landroid/content/Context;Landroid/view/View;I)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 214
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v7, v1

    invoke-virtual {v7}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    move-object v4, v7

    .line 215
    move-object v7, v4

    instance-of v7, v7, Lgtandroid/universal/NeonUi$Panel;

    if-eqz v7, :cond_0

    .line 216
    move-object v7, v4

    move v8, v2

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 221
    :goto_0
    return-void

    .line 219
    :cond_0
    move-object v7, v0

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x3f800000    # 1.0f

    const v10, -0xf5eede

    const v11, -0xf7f2e5

    const v12, -0xe4d5b3

    invoke-static/range {v7 .. v12}, Lgtandroid/universal/NeonUi;->panel(Landroid/content/Context;FFIII)Lgtandroid/universal/NeonUi$Panel;

    move-result-object v7

    move-object v5, v7

    .line 220
    move-object v7, v5

    move v8, v2

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    .line 221
    move-object v7, v1

    move-object v8, v5

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    goto :goto_0
.end method

.method public static applyShell(Landroid/content/Context;Landroid/view/View;I)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 192
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object v10, v1

    invoke-virtual {v10}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v10

    move-object v4, v10

    .line 193
    move-object v10, v4

    instance-of v10, v10, Lgtandroid/universal/NeonUi$Shell;

    if-eqz v10, :cond_0

    .line 194
    move-object v10, v4

    move v11, v2

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 210
    :goto_0
    return-void

    .line 197
    :cond_0
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v5, v10

    .line 198
    move-object v10, v5

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 199
    move-object v10, v5

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 200
    move-object v10, v5

    move-object v11, v0

    const/high16 v12, 0x41900000    # 18.0f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 201
    move-object v10, v5

    move-object v11, v0

    const/high16 v12, 0x40600000    # 3.5f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    const v12, -0xd13701

    const/16 v13, 0x3a

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 203
    move-object v10, v0

    const/high16 v11, 0x41800000    # 16.0f

    const/high16 v12, 0x3fc00000    # 1.5f

    const v13, -0xf4edda

    const v14, -0xefe4c6

    const v15, -0xd13701

    const/16 v16, 0xe0

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v15

    invoke-static/range {v10 .. v15}, Lgtandroid/universal/NeonUi;->panel(Landroid/content/Context;FFIII)Lgtandroid/universal/NeonUi$Panel;

    move-result-object v10

    move-object v6, v10

    .line 205
    new-instance v10, Lgtandroid/universal/NeonUi$Shell;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    const/4 v12, 0x2

    new-array v12, v12, [Landroid/graphics/drawable/Drawable;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x0

    move-object v15, v5

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x1

    move-object v15, v6

    aput-object v15, v13, v14

    invoke-direct {v11, v12}, Lgtandroid/universal/NeonUi$Shell;-><init>([Landroid/graphics/drawable/Drawable;)V

    move-object v7, v10

    .line 206
    move-object v10, v0

    const/high16 v11, 0x3fc00000    # 1.5f

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    move v8, v10

    .line 207
    move-object v10, v7

    const/4 v11, 0x1

    move v12, v8

    move v13, v8

    move v14, v8

    move v15, v8

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 208
    move-object v10, v7

    move v11, v2

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/LayerDrawable;->setAlpha(I)V

    .line 209
    move-object v10, v1

    move-object v11, v7

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 210
    move-object v10, v1

    move-object v11, v0

    const/4 v12, 0x6

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    move-object v12, v0

    const/4 v13, 0x4

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    move-object v13, v0

    const/4 v14, 0x6

    int-to-float v14, v14

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    move-object v14, v0

    const/4 v15, 0x6

    int-to-float v15, v15

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    goto/16 :goto_0
.end method

.method public static attachIcon(Landroid/content/Context;Landroid/widget/Button;IF)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            "IF)V"
        }
    .end annotation

    .prologue
    .line 561
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v6, v0

    move-object v7, v1

    move v8, v2

    move v9, v3

    const v10, -0x66000001

    const/4 v11, -0x1

    invoke-static/range {v6 .. v11}, Lgtandroid/universal/NeonUi;->attachIcon(Landroid/content/Context;Landroid/widget/Button;IFII)V

    return-void
.end method

.method public static attachIcon(Landroid/content/Context;Landroid/widget/Button;IFII)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            "IFII)V"
        }
    .end annotation

    .prologue
    .line 566
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move v10, v2

    const/4 v11, 0x0

    if-ne v10, v11, :cond_0

    .line 567
    move-object v10, v1

    const/4 v11, 0x0

    check-cast v11, Landroid/graphics/drawable/Drawable;

    const/4 v12, 0x0

    check-cast v12, Landroid/graphics/drawable/Drawable;

    const/4 v13, 0x0

    check-cast v13, Landroid/graphics/drawable/Drawable;

    const/4 v14, 0x0

    check-cast v14, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 581
    :goto_0
    return-void

    .line 570
    :cond_0
    move-object v10, v0

    move v11, v3

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    move v7, v10

    .line 571
    move v10, v2

    const/high16 v11, 0x7f000000

    if-lt v10, v11, :cond_1

    .line 573
    move-object v10, v0

    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    move v11, v2

    invoke-virtual {v10, v11}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    move-object v8, v10

    .line 579
    :goto_1
    move-object v10, v8

    const/4 v11, 0x0

    const/4 v12, 0x0

    move v13, v7

    move v14, v7

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 580
    move-object v10, v1

    move-object v11, v8

    const/4 v12, 0x0

    check-cast v12, Landroid/graphics/drawable/Drawable;

    const/4 v13, 0x0

    check-cast v13, Landroid/graphics/drawable/Drawable;

    const/4 v14, 0x0

    check-cast v14, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 581
    move-object v10, v1

    move-object v11, v0

    const/high16 v12, 0x41000000    # 8.0f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    goto :goto_0

    .line 574
    :cond_1
    move v10, v2

    const/16 v11, 0x64

    if-lt v10, v11, :cond_2

    move v10, v2

    const/16 v11, 0x3e8

    if-ge v10, v11, :cond_2

    .line 575
    new-instance v10, Lgtandroid/universal/NeonUi$Glyph;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move v12, v2

    move v13, v7

    move v14, v4

    invoke-direct {v11, v12, v13, v14}, Lgtandroid/universal/NeonUi$Glyph;-><init>(III)V

    move-object v8, v10

    goto :goto_1

    .line 577
    :cond_2
    new-instance v10, Lgtandroid/universal/NeonUi$Icon;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move v12, v2

    move v13, v7

    move v14, v4

    move v15, v5

    invoke-direct {v11, v12, v13, v14, v15}, Lgtandroid/universal/NeonUi$Icon;-><init>(IIII)V

    move-object v8, v10

    goto :goto_1
.end method

.method public static attachPressEffect(Landroid/view/View;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .prologue
    .line 705
    move-object v0, p0

    move-object v3, v0

    const v4, 0x3f75c28f    # 0.96f

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;FZ)V

    return-void
.end method

.method public static attachPressEffect(Landroid/view/View;FZ)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "FZ)V"
        }
    .end annotation

    .prologue
    .line 709
    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v5, v0

    new-instance v6, Lgtandroid/universal/NeonUi$100000001;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move v8, v2

    move v9, v1

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$100000001;-><init>(ZF)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method public static buttonDrawable(Landroid/content/Context;IF)Landroid/graphics/drawable/Drawable;
    .locals 20

    .prologue
    .line 652
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move v10, v1

    invoke-static {v10}, Lgtandroid/universal/NeonUi;->isNeutral(I)Z

    move-result v10

    if-eqz v10, :cond_0

    .line 653
    move-object v10, v0

    move v11, v2

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    move v4, v10

    .line 654
    const v10, -0xdbcfb0

    move v5, v10

    .line 655
    const v10, -0xebe4d0

    move v6, v10

    .line 656
    const v10, -0xbeaa71

    move v7, v10

    .line 657
    new-instance v10, Lgtandroid/universal/NeonUi$Btn;

    move-object/from16 v19, v10

    move-object/from16 v10, v19

    move-object/from16 v11, v19

    invoke-direct {v11}, Lgtandroid/universal/NeonUi$Btn;-><init>()V

    move-object v8, v10

    .line 658
    move-object v10, v8

    const/4 v11, 0x1

    new-array v11, v11, [I

    move-object/from16 v19, v11

    move-object/from16 v11, v19

    move-object/from16 v12, v19

    const/4 v13, 0x0

    const v14, 0x10100a7

    aput v14, v12, v13

    move-object v12, v0

    move v13, v5

    const/high16 v14, 0x3e800000    # 0.25f

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v13

    move v14, v6

    const v15, 0x3e19999a    # 0.15f

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v14

    move v15, v7

    const v16, 0x3ecccccd    # 0.4f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v15

    const v16, -0xd13701

    const/16 v17, 0xaa

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v16

    move/from16 v17, v4

    const/16 v18, 0x1

    invoke-static/range {v12 .. v18}, Lgtandroid/universal/NeonUi;->layered(Landroid/content/Context;IIIIFZ)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 661
    move-object v10, v8

    const/4 v11, 0x0

    new-array v11, v11, [I

    move-object v12, v0

    move v13, v5

    move v14, v6

    move v15, v7

    move/from16 v16, v7

    const/16 v17, 0x40

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v16

    move/from16 v17, v4

    const/16 v18, 0x0

    invoke-static/range {v12 .. v18}, Lgtandroid/universal/NeonUi;->layered(Landroid/content/Context;IIIIFZ)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 662
    move-object v10, v8

    move-object v0, v10

    .line 664
    :goto_0
    return-object v0

    :cond_0
    move-object v10, v0

    move v11, v1

    const v12, 0x3e8f5c29    # 0.28f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v11

    move v12, v1

    const v13, 0x3eb33333    # 0.35f

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->darken(IF)I

    move-result v12

    move v13, v2

    invoke-static {v10, v11, v12, v13}, Lgtandroid/universal/NeonUi;->gradientButton(Landroid/content/Context;IIF)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    move-object v0, v10

    goto :goto_0
.end method

.method public static createBackBar(Landroid/content/Context;Ljava/lang/String;F)Landroid/widget/FrameLayout;
    .locals 18

    .prologue
    .line 1331
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    new-instance v10, Landroid/widget/FrameLayout;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v10

    .line 1332
    move-object v10, v4

    move-object v11, v0

    const v12, -0xd5d071

    const v13, -0xa5c030

    const/high16 v14, 0x41600000    # 14.0f

    invoke-static {v11, v12, v13, v14}, Lgtandroid/universal/NeonUi;->gradientButton(Landroid/content/Context;IIF)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1333
    move-object v10, v4

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/view/View;->setClickable(Z)V

    .line 1335
    new-instance v10, Landroid/widget/LinearLayout;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v10

    .line 1336
    move-object v10, v5

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1337
    move-object v10, v5

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1338
    move-object v10, v5

    move-object v11, v0

    const/4 v12, 0x1

    const v13, -0x637401

    const/high16 v14, 0x428c0000    # 70.0f

    invoke-static {v11, v12, v13, v14}, Lgtandroid/universal/NeonUi;->fadeLine(Landroid/content/Context;ZIF)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1340
    new-instance v10, Landroid/widget/TextView;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v10

    .line 1341
    const-string v10, "\u2190"

    move-object v7, v10

    .line 1342
    new-instance v10, Landroid/text/SpannableString;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    move-object v14, v7

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, "  "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object v8, v10

    .line 1343
    move-object v10, v8

    new-instance v11, Landroid/text/style/ForegroundColorSpan;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    const v13, -0x465701

    invoke-direct {v12, v13}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    const/4 v12, 0x0

    move-object v13, v7

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v13

    const/16 v14, 0x21

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1345
    move-object v10, v6

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1346
    move-object v10, v6

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1347
    move-object v10, v6

    move v11, v2

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1348
    move-object v10, v6

    const/4 v11, 0x0

    check-cast v11, Landroid/graphics/Typeface;

    const/4 v12, 0x1

    invoke-virtual {v10, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1349
    move-object v10, v6

    const v11, 0x3cf5c28f    # 0.03f

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1350
    move-object v10, v6

    move-object v11, v0

    const/16 v12, 0xc

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    const/4 v12, 0x0

    move-object v13, v0

    const/16 v14, 0xc

    int-to-float v14, v14

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    const/4 v14, 0x0

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1351
    move-object v10, v5

    move-object v11, v6

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1352
    move-object v10, v5

    move-object v11, v0

    const/4 v12, 0x0

    const v13, -0x637401

    const/high16 v14, 0x428c0000    # 70.0f

    invoke-static {v11, v12, v13, v14}, Lgtandroid/universal/NeonUi;->fadeLine(Landroid/content/Context;ZIF)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1354
    move-object v10, v4

    move-object v11, v5

    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, -0x1

    const/4 v15, -0x1

    const/16 v16, 0x11

    invoke-direct/range {v13 .. v16}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v10, v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1357
    move-object v10, v4

    invoke-static {v10}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;)V

    .line 1358
    move-object v10, v4

    move-object v0, v10

    return-object v0
.end method

.method public static createBanner(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;FF)Landroid/widget/FrameLayout;
    .locals 24

    .prologue
    .line 1298
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    new-instance v13, Landroid/widget/FrameLayout;

    move-object/from16 v23, v13

    move-object/from16 v13, v23

    move-object/from16 v14, v23

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v7, v13

    .line 1299
    move-object v13, v1

    const/high16 v14, 0x41800000    # 16.0f

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    int-to-float v13, v13

    move v8, v13

    .line 1300
    move-object v13, v7

    move-object v14, v1

    const v15, -0xe1b028

    const v16, -0xd08401

    const v17, -0xd08401

    const v18, 0x3ee66666    # 0.45f

    invoke-static/range {v17 .. v18}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v17

    const v18, -0xd08401

    const/16 v19, 0x66

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v18

    move/from16 v19, v8

    const/16 v20, 0x0

    const v21, 0x3fb33333    # 1.4f

    const/16 v22, 0x50

    invoke-static/range {v14 .. v22}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1303
    new-instance v13, Landroid/widget/LinearLayout;

    move-object/from16 v23, v13

    move-object/from16 v13, v23

    move-object/from16 v14, v23

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v9, v13

    .line 1304
    move-object v13, v9

    const/4 v14, 0x1

    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1305
    move-object v13, v9

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1307
    new-instance v13, Landroid/widget/TextView;

    move-object/from16 v23, v13

    move-object/from16 v13, v23

    move-object/from16 v14, v23

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v13

    .line 1308
    move-object v13, v10

    move-object v14, v2

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1309
    move-object v13, v10

    const/4 v14, -0x1

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1310
    move-object v13, v10

    move v14, v4

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1311
    move-object v13, v10

    const/4 v14, 0x0

    check-cast v14, Landroid/graphics/Typeface;

    const/4 v15, 0x1

    invoke-virtual {v13, v14, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1312
    move-object v13, v10

    const v14, 0x3cf5c28f    # 0.03f

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1313
    move-object v13, v10

    move-object v14, v1

    const/4 v15, 0x3

    int-to-float v15, v15

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v14

    int-to-float v14, v14

    const/4 v15, 0x0

    move-object/from16 v16, v1

    const/16 v17, 0x1

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v16

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    const/high16 v17, 0x66000000

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1314
    move-object v13, v10

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 1315
    move-object v13, v9

    move-object v14, v10

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1317
    new-instance v13, Landroid/widget/TextView;

    move-object/from16 v23, v13

    move-object/from16 v13, v23

    move-object/from16 v14, v23

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v11, v13

    .line 1318
    move-object v13, v11

    move-object v14, v3

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1319
    move-object v13, v11

    const v14, -0x442f01

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1320
    move-object v13, v11

    move v14, v5

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1321
    move-object v13, v11

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 1322
    move-object v13, v9

    move-object v14, v11

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1324
    move-object v13, v7

    move-object v14, v9

    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    const/16 v17, -0x1

    const/16 v18, -0x1

    const/16 v19, 0x11

    invoke-direct/range {v16 .. v19}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v13, v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1327
    move-object v13, v7

    move-object v1, v13

    return-object v1
.end method

.method public static createDot(Landroid/content/Context;IF)Landroid/view/View;
    .locals 21

    .prologue
    .line 585
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    new-instance v12, Landroid/view/View;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    move-object v14, v0

    invoke-direct {v13, v14}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v4, v12

    .line 586
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    invoke-direct {v13}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v5, v12

    .line 587
    move-object v12, v5

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 588
    move-object v12, v5

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 589
    move-object v12, v5

    move-object v13, v0

    const/high16 v14, 0x40000000    # 2.0f

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    move v14, v1

    const/16 v15, 0x66

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v14

    invoke-virtual {v12, v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 591
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    sget-object v14, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v15, 0x2

    new-array v15, v15, [I

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    const/16 v17, 0x0

    move/from16 v18, v1

    const v19, 0x3eb33333    # 0.35f

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v18

    aput v18, v16, v17

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    const/16 v17, 0x1

    move/from16 v18, v1

    const/high16 v19, 0x3e800000    # 0.25f

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/NeonUi;->darken(IF)I

    move-result v18

    aput v18, v16, v17

    invoke-direct {v13, v14, v15}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v6, v12

    .line 594
    move-object v12, v6

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 596
    new-instance v12, Landroid/graphics/drawable/LayerDrawable;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    const/4 v14, 0x2

    new-array v14, v14, [Landroid/graphics/drawable/Drawable;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x0

    move-object/from16 v17, v5

    aput-object v17, v15, v16

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    const/16 v16, 0x1

    move-object/from16 v17, v6

    aput-object v17, v15, v16

    invoke-direct {v13, v14}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    move-object v7, v12

    .line 597
    move-object v12, v0

    const/high16 v13, 0x3fc00000    # 1.5f

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    move v8, v12

    .line 598
    move-object v12, v7

    const/4 v13, 0x1

    move v14, v8

    move v15, v8

    move/from16 v16, v8

    move/from16 v17, v8

    invoke-virtual/range {v12 .. v17}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 599
    move-object v12, v4

    move-object v13, v7

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 601
    move-object v12, v0

    move v13, v2

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    move v9, v12

    .line 602
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v20, v12

    move-object/from16 v12, v20

    move-object/from16 v13, v20

    move v14, v9

    move v15, v9

    invoke-direct {v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v10, v12

    .line 603
    move-object v12, v10

    move-object v13, v0

    const/high16 v14, 0x41000000    # 8.0f

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 604
    move-object v12, v4

    move-object v13, v10

    invoke-virtual {v12, v13}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 605
    move-object v12, v4

    move-object v0, v12

    return-object v0
.end method

.method public static createEmptyCell(Landroid/content/Context;)Landroid/view/View;
    .locals 9

    .prologue
    .line 1252
    move-object v0, p0

    new-instance v5, Landroid/view/View;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v2, v5

    .line 1253
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v3, v5

    .line 1254
    move-object v5, v3

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 1255
    move-object v5, v3

    const v6, 0x66060b20

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1256
    move-object v5, v3

    move-object v6, v0

    const/high16 v7, 0x41400000    # 12.0f

    invoke-static {v6, v7}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1257
    move-object v5, v2

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1258
    move-object v5, v2

    move-object v0, v5

    return-object v0
.end method

.method public static createIdPad(Landroid/content/Context;Ljava/lang/String;F)Lgtandroid/universal/NeonUi$IdPad;
    .locals 43

    .prologue
    .line 1508
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move/from16 v4, p2

    new-instance v32, Landroid/widget/LinearLayout;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v32

    .line 1509
    move-object/from16 v32, v6

    const/16 v33, 0x1

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1511
    move-object/from16 v32, v2

    const/high16 v33, 0x42300000    # 44.0f

    invoke-static/range {v32 .. v33}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v32

    move/from16 v7, v32

    .line 1512
    move-object/from16 v32, v2

    const/high16 v33, 0x42100000    # 36.0f

    invoke-static/range {v32 .. v33}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v32

    move/from16 v8, v32

    .line 1513
    move-object/from16 v32, v2

    const/high16 v33, 0x40a00000    # 5.0f

    invoke-static/range {v32 .. v33}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v32

    move/from16 v9, v32

    .line 1515
    new-instance v32, Landroid/widget/LinearLayout;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v32

    .line 1516
    move-object/from16 v32, v10

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1517
    move-object/from16 v32, v10

    const/16 v33, 0x10

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1518
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, -0x1

    const/16 v35, -0x2

    invoke-direct/range {v33 .. v35}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v11, v32

    .line 1520
    move-object/from16 v32, v11

    move/from16 v33, v9

    move-object/from16 v34, v2

    const/high16 v35, 0x40000000    # 2.0f

    invoke-static/range {v34 .. v35}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v34

    add-int v33, v33, v34

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 1521
    move-object/from16 v32, v6

    move-object/from16 v33, v10

    move-object/from16 v34, v11

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1523
    new-instance v32, Landroid/widget/LinearLayout;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v32

    .line 1524
    move-object/from16 v32, v12

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1525
    move-object/from16 v32, v12

    const/16 v33, 0x10

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1526
    move-object/from16 v32, v12

    move-object/from16 v33, v2

    const v34, -0xeddec3

    const v35, -0xf1e4cd

    const v36, -0xd05701

    const/16 v37, 0xb0

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v36

    const v37, -0xd05701

    const/16 v38, 0x40

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v37

    move-object/from16 v38, v2

    const/high16 v39, 0x41600000    # 14.0f

    invoke-static/range {v38 .. v39}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v38

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    const/16 v39, 0x0

    const/high16 v40, 0x3fc00000    # 1.5f

    const/16 v41, 0x18

    invoke-static/range {v33 .. v41}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v33

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1528
    move-object/from16 v32, v12

    move-object/from16 v33, v2

    const/16 v34, 0x6

    move/from16 v0, v34

    int-to-float v0, v0

    move/from16 v34, v0

    invoke-static/range {v33 .. v34}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v33

    const/16 v34, 0x0

    move-object/from16 v35, v2

    const/16 v36, 0xa

    move/from16 v0, v36

    int-to-float v0, v0

    move/from16 v36, v0

    invoke-static/range {v35 .. v36}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v35

    const/16 v36, 0x0

    invoke-virtual/range {v32 .. v36}, Landroid/view/View;->setPadding(IIII)V

    .line 1529
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x0

    move/from16 v35, v7

    const/high16 v36, 0x3f800000    # 1.0f

    invoke-direct/range {v33 .. v36}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v13, v32

    .line 1530
    move-object/from16 v32, v13

    move-object/from16 v33, v2

    const/high16 v34, 0x40c00000    # 6.0f

    invoke-static/range {v33 .. v34}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v33

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1531
    move-object/from16 v32, v10

    move-object/from16 v33, v12

    move-object/from16 v34, v13

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1533
    new-instance v32, Landroid/view/View;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v32

    .line 1534
    move-object/from16 v32, v2

    const/high16 v33, 0x41f00000    # 30.0f

    invoke-static/range {v32 .. v33}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v32

    move/from16 v15, v32

    .line 1535
    move-object/from16 v32, v14

    new-instance v33, Lgtandroid/universal/NeonUi$Icon;

    move-object/from16 v42, v33

    move-object/from16 v33, v42

    move-object/from16 v34, v42

    const/16 v35, 0xc

    move/from16 v36, v15

    const v37, -0xd05701

    const/16 v38, 0x99

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v37

    const v38, -0x150b01

    invoke-direct/range {v34 .. v38}, Lgtandroid/universal/NeonUi$Icon;-><init>(IIII)V

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1536
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move/from16 v34, v15

    move/from16 v35, v15

    invoke-direct/range {v33 .. v35}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v16, v32

    .line 1537
    move-object/from16 v32, v16

    move-object/from16 v33, v2

    const/high16 v34, 0x41000000    # 8.0f

    invoke-static/range {v33 .. v34}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v33

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1538
    move-object/from16 v32, v12

    move-object/from16 v33, v14

    move-object/from16 v34, v16

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1540
    new-instance v32, Landroid/widget/EditText;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v32

    .line 1541
    move-object/from16 v32, v17

    move-object/from16 v33, v3

    if-nez v33, :cond_0

    const-string v33, "ID \u0438\u0433\u0440\u043e\u043a\u0430"

    :goto_0
    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1542
    move-object/from16 v32, v17

    const v33, -0x705c3c

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setHintTextColor(I)V

    .line 1543
    move-object/from16 v32, v17

    const/16 v33, -0x1

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1544
    move-object/from16 v32, v17

    const/high16 v33, 0x41700000    # 15.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1545
    move-object/from16 v32, v17

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/Typeface;

    const/16 v34, 0x1

    invoke-virtual/range {v32 .. v34}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1546
    move-object/from16 v32, v17

    const/16 v33, 0x1

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1547
    move-object/from16 v32, v17

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/drawable/Drawable;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1548
    move-object/from16 v32, v17

    const/16 v33, 0x2

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setInputType(I)V

    .line 1549
    move-object/from16 v32, v17

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setFocusable(Z)V

    .line 1550
    move-object/from16 v32, v17

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setCursorVisible(Z)V

    .line 1551
    move-object/from16 v32, v17

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    invoke-virtual/range {v32 .. v36}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1552
    move-object/from16 v32, v12

    move-object/from16 v33, v17

    new-instance v34, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v34

    move-object/from16 v34, v42

    move-object/from16 v35, v42

    const/16 v36, 0x0

    const/16 v37, -0x1

    const/high16 v38, 0x3f800000    # 1.0f

    invoke-direct/range {v35 .. v38}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1554
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v32

    .line 1555
    move-object/from16 v32, v18

    const-string v33, "\u274c"

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1556
    move-object/from16 v32, v18

    const/high16 v33, 0x41500000    # 13.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1557
    move-object/from16 v32, v18

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/drawable/Drawable;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1558
    move-object/from16 v32, v18

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    invoke-virtual/range {v32 .. v36}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1559
    move-object/from16 v32, v18

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 1560
    move-object/from16 v32, v18

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 1561
    move-object/from16 v32, v18

    const/16 v33, 0x0

    check-cast v33, Landroid/animation/StateListAnimator;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1562
    move-object/from16 v32, v18

    new-instance v33, Lgtandroid/universal/NeonUi$100000002;

    move-object/from16 v42, v33

    move-object/from16 v33, v42

    move-object/from16 v34, v42

    move-object/from16 v35, v17

    invoke-direct/range {v34 .. v35}, Lgtandroid/universal/NeonUi$100000002;-><init>(Landroid/widget/EditText;)V

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1568
    move-object/from16 v32, v12

    move-object/from16 v33, v18

    new-instance v34, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v34

    move-object/from16 v34, v42

    move-object/from16 v35, v42

    move-object/from16 v36, v2

    const/high16 v37, 0x41d00000    # 26.0f

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v36

    move-object/from16 v37, v2

    const/high16 v38, 0x41d00000    # 26.0f

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v37

    invoke-direct/range {v35 .. v37}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1569
    move-object/from16 v32, v18

    invoke-static/range {v32 .. v32}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;)V

    .line 1571
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v19, v32

    .line 1572
    move-object/from16 v32, v19

    const-string v33, "\u041f\u0420\u041e\u0414\u041e\u041b\u0416\u0418\u0422\u042c"

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1573
    move-object/from16 v32, v2

    move-object/from16 v33, v19

    const/16 v34, 0xd

    const v35, -0xe19c17

    const v36, -0xd07301

    const/high16 v37, 0x41600000    # 14.0f

    const/high16 v38, 0x41800000    # 16.0f

    invoke-static/range {v32 .. v38}, Lgtandroid/universal/NeonUi;->styleNeonButton(Landroid/content/Context;Landroid/widget/Button;IIIFF)V

    .line 1574
    move-object/from16 v32, v19

    const/high16 v33, 0x41300000    # 11.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1575
    move-object/from16 v32, v19

    move-object/from16 v33, v2

    const/16 v34, 0xa

    move/from16 v0, v34

    int-to-float v0, v0

    move/from16 v34, v0

    invoke-static/range {v33 .. v34}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v33

    const/16 v34, 0x0

    move-object/from16 v35, v2

    const/16 v36, 0xa

    move/from16 v0, v36

    int-to-float v0, v0

    move/from16 v36, v0

    invoke-static/range {v35 .. v36}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v35

    const/16 v36, 0x0

    invoke-virtual/range {v32 .. v36}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1576
    move-object/from16 v32, v10

    move-object/from16 v33, v19

    new-instance v34, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v34

    move-object/from16 v34, v42

    move-object/from16 v35, v42

    const/16 v36, -0x2

    move/from16 v37, v7

    invoke-direct/range {v35 .. v37}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1579
    move-object/from16 v32, v17

    move-object/from16 v20, v32

    .line 1580
    const/16 v32, 0x3

    move/from16 v0, v32

    new-array v0, v0, [[Ljava/lang/String;

    move-object/from16 v32, v0

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x0

    const/16 v35, 0x3

    move/from16 v0, v35

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v35, v0

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x0

    const-string v38, "1"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x1

    const-string v38, "2"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x2

    const-string v38, "3"

    aput-object v38, v36, v37

    aput-object v35, v33, v34

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x1

    const/16 v35, 0x3

    move/from16 v0, v35

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v35, v0

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x0

    const-string v38, "4"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x1

    const-string v38, "5"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x2

    const-string v38, "6"

    aput-object v38, v36, v37

    aput-object v35, v33, v34

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x2

    const/16 v35, 0x3

    move/from16 v0, v35

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v35, v0

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x0

    const-string v38, "7"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x1

    const-string v38, "8"

    aput-object v38, v36, v37

    move-object/from16 v42, v35

    move-object/from16 v35, v42

    move-object/from16 v36, v42

    const/16 v37, 0x2

    const-string v38, "9"

    aput-object v38, v36, v37

    aput-object v35, v33, v34

    move-object/from16 v21, v32

    .line 1585
    move-object/from16 v32, v21

    move-object/from16 v22, v32

    const/16 v32, 0x0

    move/from16 v23, v32

    .line 1592
    :goto_1
    move/from16 v32, v23

    move-object/from16 v33, v22

    move-object/from16 v0, v33

    array-length v0, v0

    move/from16 v33, v0

    move/from16 v0, v32

    move/from16 v1, v33

    if-lt v0, v1, :cond_1

    .line 1612
    new-instance v32, Landroid/widget/LinearLayout;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v24, v32

    .line 1613
    move-object/from16 v32, v24

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1614
    move-object/from16 v32, v6

    move-object/from16 v33, v24

    new-instance v34, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v34

    move-object/from16 v34, v42

    move-object/from16 v35, v42

    const/16 v36, -0x1

    const/16 v37, -0x2

    invoke-direct/range {v35 .. v37}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1617
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v25, v32

    .line 1618
    move-object/from16 v32, v25

    const-string v33, "C"

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1619
    move-object/from16 v32, v25

    const v33, -0x342914

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1620
    move-object/from16 v32, v25

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/Typeface;

    const/16 v34, 0x1

    invoke-virtual/range {v32 .. v34}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1621
    move-object/from16 v32, v25

    const/high16 v33, 0x41880000    # 17.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1622
    move-object/from16 v32, v25

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1623
    move-object/from16 v32, v25

    const/16 v33, 0x0

    check-cast v33, Landroid/animation/StateListAnimator;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1624
    move-object/from16 v32, v25

    move-object/from16 v33, v2

    const/high16 v34, 0x41200000    # 10.0f

    const v35, -0xefe6d4

    const v36, -0xf4eede

    const v37, -0xccbaa2

    const/16 v38, 0x77

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v37

    const v38, -0xc05601

    invoke-static/range {v33 .. v38}, Lgtandroid/universal/NeonUi;->numKeyDrawable(Landroid/content/Context;FIIII)Landroid/graphics/drawable/Drawable;

    move-result-object v33

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1625
    move-object/from16 v32, v25

    new-instance v33, Lgtandroid/universal/NeonUi$100000004;

    move-object/from16 v42, v33

    move-object/from16 v33, v42

    move-object/from16 v34, v42

    move-object/from16 v35, v20

    invoke-direct/range {v34 .. v35}, Lgtandroid/universal/NeonUi$100000004;-><init>(Landroid/widget/EditText;)V

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1628
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x0

    move/from16 v35, v8

    const/high16 v36, 0x3f800000    # 1.0f

    invoke-direct/range {v33 .. v36}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v26, v32

    .line 1629
    move-object/from16 v32, v26

    move/from16 v33, v9

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1630
    move-object/from16 v32, v25

    const v33, 0x3f7851ec    # 0.97f

    const/16 v34, 0x1

    invoke-static/range {v32 .. v34}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;FZ)V

    .line 1631
    move-object/from16 v32, v24

    move-object/from16 v33, v25

    move-object/from16 v34, v26

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1633
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v27, v32

    .line 1634
    move-object/from16 v32, v27

    const-string v33, "0"

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1635
    move-object/from16 v32, v27

    const/16 v33, -0x1

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1636
    move-object/from16 v32, v27

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/Typeface;

    const/16 v34, 0x1

    invoke-virtual/range {v32 .. v34}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1637
    move-object/from16 v32, v27

    const/high16 v33, 0x41880000    # 17.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1638
    move-object/from16 v32, v27

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1639
    move-object/from16 v32, v27

    const/16 v33, 0x0

    check-cast v33, Landroid/animation/StateListAnimator;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1640
    move-object/from16 v32, v27

    move-object/from16 v33, v2

    const/high16 v34, 0x41200000    # 10.0f

    const v35, -0xe9cba1

    const v36, -0xf3e4cd

    const v37, -0xc05601

    const/16 v38, 0xcc

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v37

    const v38, -0x903401

    invoke-static/range {v33 .. v38}, Lgtandroid/universal/NeonUi;->numKeyDrawable(Landroid/content/Context;FIIII)Landroid/graphics/drawable/Drawable;

    move-result-object v33

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1641
    move-object/from16 v32, v27

    new-instance v33, Lgtandroid/universal/NeonUi$100000005;

    move-object/from16 v42, v33

    move-object/from16 v33, v42

    move-object/from16 v34, v42

    move-object/from16 v35, v20

    invoke-direct/range {v34 .. v35}, Lgtandroid/universal/NeonUi$100000005;-><init>(Landroid/widget/EditText;)V

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1644
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x0

    move/from16 v35, v8

    const/high16 v36, 0x3f800000    # 1.0f

    invoke-direct/range {v33 .. v36}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v28, v32

    .line 1645
    move-object/from16 v32, v28

    move/from16 v33, v9

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1646
    move-object/from16 v32, v27

    const v33, 0x3f7851ec    # 0.97f

    const/16 v34, 0x1

    invoke-static/range {v32 .. v34}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;FZ)V

    .line 1647
    move-object/from16 v32, v24

    move-object/from16 v33, v27

    move-object/from16 v34, v28

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1649
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v29, v32

    .line 1650
    move-object/from16 v32, v29

    const-string v33, "\u041d\u0410\u0417\u0410\u0414"

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1651
    move-object/from16 v32, v2

    move-object/from16 v33, v29

    const/16 v34, 0x9

    const v35, -0xddcfa9

    const v36, -0xebe3cd

    const/high16 v37, 0x41200000    # 10.0f

    const/high16 v38, 0x41700000    # 15.0f

    invoke-static/range {v32 .. v38}, Lgtandroid/universal/NeonUi;->styleNeonButton(Landroid/content/Context;Landroid/widget/Button;IIIFF)V

    .line 1652
    move-object/from16 v32, v29

    const/high16 v33, 0x41300000    # 11.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1653
    move-object/from16 v32, v29

    const/16 v33, 0x11

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setGravity(I)V

    .line 1654
    move-object/from16 v32, v24

    move-object/from16 v33, v29

    new-instance v34, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v34

    move-object/from16 v34, v42

    move-object/from16 v35, v42

    const/16 v36, 0x0

    move/from16 v37, v8

    const/high16 v38, 0x3f800000    # 1.0f

    invoke-direct/range {v35 .. v38}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1656
    new-instance v32, Lgtandroid/universal/NeonUi$IdPad;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v6

    move-object/from16 v35, v17

    move-object/from16 v36, v19

    move-object/from16 v37, v29

    invoke-direct/range {v33 .. v37}, Lgtandroid/universal/NeonUi$IdPad;-><init>(Landroid/widget/LinearLayout;Landroid/widget/EditText;Landroid/widget/Button;Landroid/widget/Button;)V

    move-object/from16 v2, v32

    return-object v2

    .line 1541
    :cond_0
    move-object/from16 v33, v3

    goto/16 :goto_0

    .line 1585
    :cond_1
    move-object/from16 v32, v22

    move/from16 v33, v23

    aget-object v32, v32, v33

    move-object/from16 v24, v32

    .line 1586
    new-instance v32, Landroid/widget/LinearLayout;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v25, v32

    .line 1587
    move-object/from16 v32, v25

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1588
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, -0x1

    const/16 v35, -0x2

    invoke-direct/range {v33 .. v35}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v26, v32

    .line 1590
    move-object/from16 v32, v26

    move/from16 v33, v9

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 1591
    move-object/from16 v32, v6

    move-object/from16 v33, v25

    move-object/from16 v34, v26

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1592
    const/16 v32, 0x0

    move/from16 v27, v32

    :goto_2
    move/from16 v32, v27

    move-object/from16 v33, v24

    move-object/from16 v0, v33

    array-length v0, v0

    move/from16 v33, v0

    move/from16 v0, v32

    move/from16 v1, v33

    if-lt v0, v1, :cond_2

    add-int/lit8 v23, v23, 0x1

    goto/16 :goto_1

    .line 1593
    :cond_2
    move-object/from16 v32, v24

    move/from16 v33, v27

    aget-object v32, v32, v33

    move-object/from16 v28, v32

    .line 1594
    new-instance v32, Landroid/widget/Button;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    move-object/from16 v34, v2

    invoke-direct/range {v33 .. v34}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v29, v32

    .line 1595
    move-object/from16 v32, v29

    move-object/from16 v33, v28

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1596
    move-object/from16 v32, v29

    const/16 v33, -0x1

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1597
    move-object/from16 v32, v29

    const/16 v33, 0x0

    check-cast v33, Landroid/graphics/Typeface;

    const/16 v34, 0x1

    invoke-virtual/range {v32 .. v34}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1598
    move-object/from16 v32, v29

    const/high16 v33, 0x41880000    # 17.0f

    move/from16 v34, v4

    mul-float v33, v33, v34

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1599
    move-object/from16 v32, v29

    const/16 v33, 0x0

    invoke-virtual/range {v32 .. v33}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1600
    move-object/from16 v32, v29

    const/16 v33, 0x0

    check-cast v33, Landroid/animation/StateListAnimator;

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1601
    move-object/from16 v32, v29

    move-object/from16 v33, v2

    const/high16 v34, 0x41200000    # 10.0f

    const v35, -0xecd5b3

    const v36, -0xf3e4cd

    const v37, -0xe0a362

    const/16 v38, 0x99

    invoke-static/range {v37 .. v38}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v37

    const v38, -0xc05601

    invoke-static/range {v33 .. v38}, Lgtandroid/universal/NeonUi;->numKeyDrawable(Landroid/content/Context;FIIII)Landroid/graphics/drawable/Drawable;

    move-result-object v33

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1602
    new-instance v32, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v42, v32

    move-object/from16 v32, v42

    move-object/from16 v33, v42

    const/16 v34, 0x0

    move/from16 v35, v8

    const/high16 v36, 0x3f800000    # 1.0f

    invoke-direct/range {v33 .. v36}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v30, v32

    .line 1603
    move/from16 v32, v27

    move-object/from16 v33, v24

    move-object/from16 v0, v33

    array-length v0, v0

    move/from16 v33, v0

    const/16 v34, 0x1

    add-int/lit8 v33, v33, -0x1

    move/from16 v0, v32

    move/from16 v1, v33

    if-ge v0, v1, :cond_3

    move-object/from16 v32, v30

    move/from16 v33, v9

    move/from16 v0, v33

    move-object/from16 v1, v32

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1604
    :cond_3
    move-object/from16 v32, v29

    new-instance v33, Lgtandroid/universal/NeonUi$100000003;

    move-object/from16 v42, v33

    move-object/from16 v33, v42

    move-object/from16 v34, v42

    move-object/from16 v35, v20

    move-object/from16 v36, v28

    invoke-direct/range {v34 .. v36}, Lgtandroid/universal/NeonUi$100000003;-><init>(Landroid/widget/EditText;Ljava/lang/String;)V

    invoke-virtual/range {v32 .. v33}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1607
    move-object/from16 v32, v29

    const v33, 0x3f7851ec    # 0.97f

    const/16 v34, 0x1

    invoke-static/range {v32 .. v34}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;FZ)V

    .line 1608
    move-object/from16 v32, v25

    move-object/from16 v33, v29

    move-object/from16 v34, v30

    invoke-virtual/range {v32 .. v34}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1592
    add-int/lit8 v27, v27, 0x1

    goto/16 :goto_2
.end method

.method public static createNeonButton(Landroid/content/Context;Ljava/lang/String;III)Landroid/widget/Button;
    .locals 16

    .prologue
    .line 742
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    new-instance v8, Landroid/widget/Button;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v8

    .line 743
    move-object v8, v6

    move-object v9, v1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 744
    move-object v8, v0

    move-object v9, v6

    move v10, v2

    move v11, v3

    move v12, v4

    const/high16 v13, 0x41600000    # 14.0f

    const/high16 v14, 0x41c00000    # 24.0f

    invoke-static/range {v8 .. v14}, Lgtandroid/universal/NeonUi;->styleNeonButton(Landroid/content/Context;Landroid/widget/Button;IIIFF)V

    .line 745
    move-object v8, v6

    move-object v0, v8

    return-object v0
.end method

.method public static createSectionTitle(Landroid/content/Context;Ljava/lang/String;F)Landroid/view/View;
    .locals 15

    .prologue
    .line 1273
    move-object v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    new-instance v8, Landroid/widget/FrameLayout;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v8

    .line 1274
    move-object v8, v4

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    const/4 v11, -0x1

    const/4 v12, -0x2

    invoke-direct {v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1276
    new-instance v8, Landroid/widget/LinearLayout;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v8

    .line 1277
    move-object v8, v5

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1278
    move-object v8, v5

    const/16 v9, 0x11

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1279
    move-object v8, v4

    move-object v9, v5

    new-instance v10, Landroid/widget/FrameLayout$LayoutParams;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1282
    move-object v8, v5

    move-object v9, v0

    const/4 v10, 0x1

    const v11, -0xd13701

    const/high16 v12, 0x42b40000    # 90.0f

    invoke-static {v9, v10, v11, v12}, Lgtandroid/universal/NeonUi;->fadeLine(Landroid/content/Context;ZIF)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1283
    new-instance v8, Landroid/widget/TextView;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v8

    .line 1284
    move-object v8, v6

    move-object v9, v1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1285
    move-object v8, v6

    const v9, -0x562b01

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1286
    move-object v8, v6

    move v9, v2

    const/high16 v10, 0x41100000    # 9.0f

    invoke-static {v9, v10}, Ljava/lang/Math;->min(FF)F

    move-result v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1287
    move-object v8, v6

    const/4 v9, 0x0

    check-cast v9, Landroid/graphics/Typeface;

    const/4 v10, 0x1

    invoke-virtual {v8, v9, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1288
    move-object v8, v6

    const v9, 0x3d4ccccd    # 0.05f

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1289
    move-object v8, v6

    move-object v9, v0

    const/4 v10, 0x3

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    int-to-float v9, v9

    const/4 v10, 0x0

    const/4 v11, 0x0

    const v12, -0xd13701

    const/16 v13, 0xaa

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1290
    move-object v8, v6

    move-object v9, v0

    const/16 v10, 0x8

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    move-object v10, v0

    const/4 v11, 0x1

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    move-object v11, v0

    const/16 v12, 0x8

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    move-object v12, v0

    const/4 v13, 0x1

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1291
    move-object v8, v5

    move-object v9, v6

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1292
    move-object v8, v5

    move-object v9, v0

    const/4 v10, 0x0

    const v11, -0xd13701

    const/high16 v12, 0x42b40000    # 90.0f

    invoke-static {v9, v10, v11, v12}, Lgtandroid/universal/NeonUi;->fadeLine(Landroid/content/Context;ZIF)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1293
    move-object v8, v4

    move-object v0, v8

    return-object v0
.end method

.method public static createStatusPill(Landroid/content/Context;ILjava/lang/String;F)Landroid/widget/Button;
    .locals 19

    .prologue
    .line 1139
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    new-instance v8, Landroid/widget/Button;

    move-object/from16 v18, v8

    move-object/from16 v8, v18

    move-object/from16 v9, v18

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v5, v8

    .line 1140
    move-object v8, v5

    move-object v9, v2

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1141
    const v8, 0x4479c000    # 999.0f

    move v6, v8

    .line 1142
    move-object v8, v5

    move-object v9, v0

    const v10, -0xead9b1

    const v11, -0xf5ecd0

    const v12, -0xd13701

    const/16 v13, 0xb0

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    const v13, -0xd13701

    const/16 v14, 0x55

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v13

    move-object v14, v0

    const v15, 0x4479c000    # 999.0f

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v14

    int-to-float v14, v14

    const/4 v15, 0x0

    const v16, 0x3fb33333    # 1.4f

    const/16 v17, 0x30

    invoke-static/range {v9 .. v17}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 1144
    move-object v8, v5

    const/4 v9, -0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1145
    move-object v8, v5

    move v9, v3

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1146
    move-object v8, v5

    const/4 v9, 0x0

    check-cast v9, Landroid/graphics/Typeface;

    const/4 v10, 0x1

    invoke-virtual {v8, v9, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1147
    move-object v8, v5

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1148
    move-object v8, v5

    const/4 v9, 0x0

    check-cast v9, Landroid/animation/StateListAnimator;

    invoke-virtual {v8, v9}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1149
    move-object v8, v5

    move-object v9, v0

    const/4 v10, 0x3

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    int-to-float v9, v9

    const/4 v10, 0x0

    const/4 v11, 0x0

    const v12, -0xd13701

    const/16 v13, 0x99

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1150
    move-object v8, v5

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1151
    move-object v8, v5

    invoke-static {v8}, Lgtandroid/universal/NeonUi;->fixTextLayout(Landroid/widget/TextView;)V

    .line 1152
    move v8, v1

    const/4 v9, 0x0

    if-eq v8, v9, :cond_0

    .line 1153
    move-object v8, v0

    move-object v9, v5

    move v10, v1

    const/high16 v11, 0x41700000    # 15.0f

    const v12, -0xd13701

    const/16 v13, 0xcc

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    const v13, -0x150d01

    invoke-static/range {v8 .. v13}, Lgtandroid/universal/NeonUi;->attachIcon(Landroid/content/Context;Landroid/widget/Button;IFII)V

    .line 1154
    move-object v8, v5

    const/16 v9, 0x13

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setGravity(I)V

    .line 1155
    move-object v8, v5

    move-object v9, v0

    const/4 v10, 0x6

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    const/4 v10, 0x0

    move-object v11, v0

    const/16 v12, 0xa

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    const/4 v12, 0x0

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1160
    :goto_0
    move-object v8, v5

    move-object v0, v8

    return-object v0

    .line 1157
    :cond_0
    move-object v8, v5

    const/16 v9, 0x11

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setGravity(I)V

    .line 1158
    move-object v8, v5

    move-object v9, v0

    const/16 v10, 0xa

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    const/4 v10, 0x0

    move-object v11, v0

    const/16 v12, 0xa

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    const/4 v12, 0x0

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    goto :goto_0
.end method

.method public static createTile(Landroid/content/Context;Ljava/lang/String;IIZF)Landroid/widget/Button;
    .locals 16

    .prologue
    .line 1219
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    new-instance v9, Landroid/widget/Button;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v7, v9

    .line 1220
    move-object v9, v7

    move-object v10, v1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1221
    move-object v9, v7

    move-object v10, v0

    invoke-static {v10}, Lgtandroid/universal/NeonUi;->tileDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 1222
    move-object v9, v7

    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1223
    move-object v9, v7

    move v10, v5

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1224
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1225
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 1226
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/view/View;->setMinimumHeight(I)V

    .line 1227
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 1228
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/view/View;->setMinimumWidth(I)V

    .line 1229
    move-object v9, v7

    const/4 v10, 0x0

    check-cast v10, Landroid/animation/StateListAnimator;

    invoke-virtual {v9, v10}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1230
    move-object v9, v7

    move-object v10, v0

    const/4 v11, 0x2

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    const/4 v11, 0x0

    move-object v12, v0

    const/4 v13, 0x1

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    int-to-float v12, v12

    const/high16 v13, -0x67000000

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1231
    move v9, v4

    if-eqz v9, :cond_0

    move v9, v2

    const/4 v10, 0x0

    if-eq v9, v10, :cond_0

    .line 1232
    move-object v9, v0

    move-object v10, v7

    move v11, v2

    const/high16 v12, 0x41d00000    # 26.0f

    move v13, v3

    const/4 v14, -0x1

    invoke-static/range {v9 .. v14}, Lgtandroid/universal/NeonUi;->attachIcon(Landroid/content/Context;Landroid/widget/Button;IFII)V

    .line 1233
    move-object v9, v7

    const/16 v10, 0x13

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 1234
    move-object v9, v7

    move-object v10, v0

    const/16 v11, 0x8

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    const/4 v11, 0x0

    move-object v12, v0

    const/4 v13, 0x6

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1235
    move-object v9, v7

    const/4 v10, 0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1241
    :goto_0
    move-object v9, v7

    invoke-static {v9}, Lgtandroid/universal/NeonUi;->fixTextLayout(Landroid/widget/TextView;)V

    .line 1242
    move-object v9, v7

    const v10, 0x3f7851ec    # 0.97f

    const/4 v11, 0x1

    invoke-static {v9, v10, v11}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;FZ)V

    .line 1243
    move-object v9, v7

    move-object v0, v9

    return-object v0

    .line 1237
    :cond_0
    move-object v9, v7

    const/16 v10, 0x11

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 1238
    move-object v9, v7

    move-object v10, v0

    const/4 v11, 0x3

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    const/4 v11, 0x0

    move-object v12, v0

    const/4 v13, 0x3

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1239
    move-object v9, v7

    const/4 v10, 0x2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    goto :goto_0
.end method

.method public static darken(IF)I
    .locals 7

    .prologue
    .line 159
    move v0, p0

    move v1, p1

    move v4, v0

    const/high16 v5, -0x1000000

    move v6, v1

    invoke-static {v4, v5, v6}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v4

    move v0, v4

    return v0
.end method

.method public static dp(Landroid/content/Context;F)I
    .locals 7

    .prologue
    .line 139
    move-object v0, p0

    move v1, p1

    const/4 v4, 0x1

    move v5, v1

    move-object v6, v0

    invoke-virtual {v6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    invoke-static {v4, v5, v6}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v4

    float-to-int v4, v4

    move v0, v4

    return v0
.end method

.method private static fadeLine(Landroid/content/Context;ZIF)Landroid/view/View;
    .locals 19

    .prologue
    .line 1262
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    new-instance v10, Landroid/view/View;

    move-object/from16 v18, v10

    move-object/from16 v10, v18

    move-object/from16 v11, v18

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v5, v10

    .line 1263
    move v10, v2

    const/16 v11, 0xe0

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v10

    move v6, v10

    .line 1264
    move v10, v2

    const/4 v11, 0x0

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v10

    move v7, v10

    .line 1265
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v18, v10

    move-object/from16 v10, v18

    move-object/from16 v11, v18

    sget-object v12, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    move v13, v1

    if-eqz v13, :cond_0

    const/4 v13, 0x2

    new-array v13, v13, [I

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    const/4 v15, 0x0

    move/from16 v16, v7

    aput v16, v14, v15

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    const/4 v15, 0x1

    move/from16 v16, v6

    aput v16, v14, v15

    :goto_0
    invoke-direct {v11, v12, v13}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v8, v10

    .line 1267
    move-object v10, v5

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1268
    move-object v10, v5

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v0

    move v14, v3

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v13

    const/4 v14, 0x1

    move-object v15, v0

    const/high16 v16, 0x40000000    # 2.0f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v15

    invoke-static {v14, v15}, Ljava/lang/Math;->max(II)I

    move-result v14

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1269
    move-object v10, v5

    move-object v0, v10

    return-object v0

    .line 1265
    :cond_0
    const/4 v13, 0x2

    new-array v13, v13, [I

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    const/4 v15, 0x0

    move/from16 v16, v6

    aput v16, v14, v15

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    const/4 v15, 0x1

    move/from16 v16, v7

    aput v16, v14, v15

    goto :goto_0
.end method

.method public static fixTextLayout(Landroid/widget/TextView;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    .prologue
    .line 692
    move-object v0, p0

    move-object v3, v0

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 693
    move-object v3, v0

    new-instance v4, Lgtandroid/universal/NeonUi$100000000;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Lgtandroid/universal/NeonUi$100000000;-><init>()V

    invoke-virtual {v3, v4}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    return-void
.end method

.method private static fixTextLayoutOnce(Landroid/widget/TextView;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1164
    move-object v0, p0

    move-object v3, v0

    invoke-virtual {v3}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_0

    .line 1165
    move-object v3, v0

    const-string v4, "neonfix"

    invoke-virtual {v3, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 1166
    move-object v3, v0

    invoke-static {v3}, Lgtandroid/universal/NeonUi;->fixTextLayout(Landroid/widget/TextView;)V

    .line 1168
    :goto_0
    return-void

    :cond_0
    move-object v3, v0

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    goto :goto_0
.end method

.method public static gradientButton(Landroid/content/Context;IIF)Landroid/graphics/drawable/Drawable;
    .locals 20

    .prologue
    .line 640
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object v10, v0

    move v11, v3

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    move v5, v10

    .line 641
    move v10, v1

    const v11, 0x3ee66666    # 0.45f

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v10

    move v6, v10

    .line 642
    move v10, v1

    const/16 v11, 0x77

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v10

    move v7, v10

    .line 643
    new-instance v10, Lgtandroid/universal/NeonUi$Btn;

    move-object/from16 v19, v10

    move-object/from16 v10, v19

    move-object/from16 v11, v19

    invoke-direct {v11}, Lgtandroid/universal/NeonUi$Btn;-><init>()V

    move-object v8, v10

    .line 644
    move-object v10, v8

    const/4 v11, 0x1

    new-array v11, v11, [I

    move-object/from16 v19, v11

    move-object/from16 v11, v19

    move-object/from16 v12, v19

    const/4 v13, 0x0

    const v14, 0x10100a7

    aput v14, v12, v13

    move-object v12, v0

    move v13, v1

    const/high16 v14, 0x3e800000    # 0.25f

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v13

    move v14, v2

    const v15, 0x3e19999a    # 0.15f

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v14

    move v15, v6

    const v16, 0x3ecccccd    # 0.4f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v15

    move/from16 v16, v1

    const v17, 0x3e99999a    # 0.3f

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v16

    const/16 v17, 0xcc

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v16

    move/from16 v17, v5

    const/16 v18, 0x1

    invoke-static/range {v12 .. v18}, Lgtandroid/universal/NeonUi;->layered(Landroid/content/Context;IIIIFZ)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 647
    move-object v10, v8

    const/4 v11, 0x0

    new-array v11, v11, [I

    move-object v12, v0

    move v13, v1

    move v14, v2

    move v15, v6

    move/from16 v16, v7

    move/from16 v17, v5

    const/16 v18, 0x0

    invoke-static/range {v12 .. v18}, Lgtandroid/universal/NeonUi;->layered(Landroid/content/Context;IIIIFZ)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 648
    move-object v10, v8

    move-object v0, v10

    return-object v0
.end method

.method private static isDecoratedTitle(Landroid/widget/TextView;)Z
    .locals 6

    .prologue
    .line 768
    move-object v0, p0

    move-object v4, v0

    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    move-object v2, v4

    .line 769
    move-object v4, v2

    if-eqz v4, :cond_0

    move-object v4, v2

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, 0x2

    if-le v4, v5, :cond_0

    move-object v4, v2

    const/4 v5, 0x0

    invoke-interface {v4, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/16 v5, 0x2550

    if-eq v4, v5, :cond_1

    :cond_0
    const/4 v4, 0x0

    :goto_0
    move v0, v4

    return v0

    :cond_1
    const/4 v4, 0x1

    goto :goto_0
.end method

.method public static isNeutral(I)Z
    .locals 6

    .prologue
    .line 162
    move v0, p0

    const/4 v4, 0x3

    new-array v4, v4, [F

    move-object v2, v4

    .line 163
    move v4, v0

    move-object v5, v2

    invoke-static {v4, v5}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 164
    move-object v4, v2

    const/4 v5, 0x1

    aget v4, v4, v5

    const v5, 0x3e6147ae    # 0.22f

    cmpl-float v4, v4, v5

    if-ltz v4, :cond_0

    const/4 v4, 0x0

    :goto_0
    move v0, v4

    return v0

    :cond_0
    const/4 v4, 0x1

    goto :goto_0
.end method

.method public static keyDrawable(Landroid/content/Context;IIF)Landroid/graphics/drawable/Drawable;
    .locals 15

    .prologue
    .line 668
    move-object v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    new-instance v7, Landroid/graphics/drawable/StateListDrawable;

    move-object v14, v7

    move-object v7, v14

    move-object v8, v14

    invoke-direct {v8}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    move-object v5, v7

    .line 669
    move-object v7, v5

    const/4 v8, 0x1

    new-array v8, v8, [I

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    const/4 v10, 0x0

    const v11, 0x10100a7

    aput v11, v9, v10

    move-object v9, v0

    move v10, v2

    const v11, 0x3dcccccd    # 0.1f

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v10

    move v11, v2

    const v12, 0x3d4ccccd    # 0.05f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->darken(IF)I

    move-result v11

    const v12, -0xd13701

    move v13, v3

    invoke-static {v9, v10, v11, v12, v13}, Lgtandroid/universal/NeonUi;->keyShape(Landroid/content/Context;IIIF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 671
    move-object v7, v5

    const/4 v8, 0x0

    new-array v8, v8, [I

    move-object v9, v0

    move v10, v1

    const v11, 0x3dcccccd    # 0.1f

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v10

    move v11, v1

    const v12, 0x3e0f5c29    # 0.14f

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->darken(IF)I

    move-result v11

    move v12, v1

    const v13, 0x3ec28f5c    # 0.38f

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v12

    const/16 v13, 0xaa

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    move v13, v3

    invoke-static {v9, v10, v11, v12, v13}, Lgtandroid/universal/NeonUi;->keyShape(Landroid/content/Context;IIIF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 674
    move-object v7, v5

    move-object v0, v7

    return-object v0
.end method

.method private static keyShape(Landroid/content/Context;IIIF)Landroid/graphics/drawable/GradientDrawable;
    .locals 16

    .prologue
    .line 678
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    sget-object v10, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/4 v11, 0x2

    new-array v11, v11, [I

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const/4 v13, 0x0

    move v14, v1

    aput v14, v12, v13

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const/4 v13, 0x1

    move v14, v2

    aput v14, v12, v13

    invoke-direct {v9, v10, v11}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object v6, v8

    .line 680
    move-object v8, v6

    move v9, v4

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 681
    move-object v8, v6

    const/4 v9, 0x1

    move-object v10, v0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v10, v3

    invoke-virtual {v8, v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 682
    move-object v8, v6

    move-object v0, v8

    return-object v0
.end method

.method private static layered(Landroid/content/Context;IIIIFZ)Landroid/graphics/drawable/Drawable;
    .locals 18

    .prologue
    .line 610
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object v9, v0

    move v10, v1

    move v11, v2

    move v12, v3

    move v13, v4

    move v14, v5

    move v15, v6

    const v16, 0x3f99999a    # 1.2f

    move/from16 v17, v6

    if-eqz v17, :cond_0

    const/16 v17, 0x10

    :goto_0
    invoke-static/range {v9 .. v17}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    move-object v0, v9

    return-object v0

    :cond_0
    const/16 v17, 0x44

    goto :goto_0
.end method

.method private static layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;
    .locals 27

    .prologue
    .line 615
    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move/from16 v8, p7

    move/from16 v9, p8

    new-instance v18, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v26, v18

    move-object/from16 v18, v26

    move-object/from16 v19, v26

    invoke-direct/range {v19 .. v19}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v11, v18

    .line 616
    move-object/from16 v18, v11

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 617
    move-object/from16 v18, v11

    move/from16 v19, v6

    move-object/from16 v20, v1

    const/16 v21, 0x1

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-static/range {v20 .. v21}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v20

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    add-float v19, v19, v20

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 618
    move-object/from16 v18, v11

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 619
    move-object/from16 v18, v11

    move-object/from16 v19, v1

    const/16 v20, 0x3

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-static/range {v19 .. v20}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v19

    move/from16 v20, v5

    invoke-virtual/range {v18 .. v20}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 621
    new-instance v18, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v26, v18

    move-object/from16 v18, v26

    move-object/from16 v19, v26

    sget-object v20, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/16 v21, 0x2

    move/from16 v0, v21

    new-array v0, v0, [I

    move-object/from16 v21, v0

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    const/16 v23, 0x0

    move/from16 v24, v2

    aput v24, v22, v23

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    const/16 v23, 0x1

    move/from16 v24, v3

    aput v24, v22, v23

    invoke-direct/range {v19 .. v21}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object/from16 v12, v18

    .line 623
    move-object/from16 v18, v12

    move/from16 v19, v6

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 624
    move-object/from16 v18, v12

    const/16 v19, 0x1

    move-object/from16 v20, v1

    move/from16 v21, v8

    invoke-static/range {v20 .. v21}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v20

    invoke-static/range {v19 .. v20}, Ljava/lang/Math;->max(II)I

    move-result v19

    move/from16 v20, v4

    invoke-virtual/range {v18 .. v20}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 626
    new-instance v18, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v26, v18

    move-object/from16 v18, v26

    move-object/from16 v19, v26

    sget-object v20, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/16 v21, 0x2

    move/from16 v0, v21

    new-array v0, v0, [I

    move-object/from16 v21, v0

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    const/16 v23, 0x0

    const/16 v24, -0x1

    move/from16 v25, v9

    invoke-static/range {v24 .. v25}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v24

    aput v24, v22, v23

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    const/16 v23, 0x1

    const v24, 0xffffff

    aput v24, v22, v23

    invoke-direct/range {v19 .. v21}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    move-object/from16 v13, v18

    .line 629
    move-object/from16 v18, v13

    move/from16 v19, v6

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 631
    new-instance v18, Landroid/graphics/drawable/LayerDrawable;

    move-object/from16 v26, v18

    move-object/from16 v18, v26

    move-object/from16 v19, v26

    const/16 v20, 0x3

    move/from16 v0, v20

    new-array v0, v0, [Landroid/graphics/drawable/Drawable;

    move-object/from16 v20, v0

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x0

    move-object/from16 v23, v11

    aput-object v23, v21, v22

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x1

    move-object/from16 v23, v12

    aput-object v23, v21, v22

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x2

    move-object/from16 v23, v13

    aput-object v23, v21, v22

    invoke-direct/range {v19 .. v20}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    move-object/from16 v14, v18

    .line 632
    move-object/from16 v18, v1

    const/16 v19, 0x2

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v18

    move/from16 v15, v18

    .line 633
    move-object/from16 v18, v14

    const/16 v19, 0x1

    move/from16 v20, v15

    move/from16 v21, v15

    move/from16 v22, v15

    move/from16 v23, v15

    invoke-virtual/range {v18 .. v23}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 634
    move/from16 v18, v15

    move-object/from16 v19, v1

    const/16 v20, 0x1

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-static/range {v19 .. v20}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v19

    add-int v18, v18, v19

    move/from16 v16, v18

    .line 635
    move-object/from16 v18, v14

    const/16 v19, 0x2

    move/from16 v20, v16

    move/from16 v21, v16

    move/from16 v22, v16

    move/from16 v23, v16

    invoke-virtual/range {v18 .. v23}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 636
    move-object/from16 v18, v14

    move-object/from16 v1, v18

    return-object v1
.end method

.method public static lighten(IF)I
    .locals 7

    .prologue
    .line 158
    move v0, p0

    move v1, p1

    move v4, v0

    const/4 v5, -0x1

    move v6, v1

    invoke-static {v4, v5, v6}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v4

    move v0, v4

    return v0
.end method

.method public static luma(I)I
    .locals 6

    .prologue
    .line 168
    move v0, p0

    const v3, 0x3e991687    # 0.299f

    move v4, v0

    invoke-static {v4}, Landroid/graphics/Color;->red(I)I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v3, v4

    const v4, 0x3f1645a2    # 0.587f

    move v5, v0

    invoke-static {v5}, Landroid/graphics/Color;->green(I)I

    move-result v5

    int-to-float v5, v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    const v4, 0x3de978d5    # 0.114f

    move v5, v0

    invoke-static {v5}, Landroid/graphics/Color;->blue(I)I

    move-result v5

    int-to-float v5, v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    float-to-int v3, v3

    move v0, v3

    return v0
.end method

.method public static mix(IIF)I
    .locals 17

    .prologue
    .line 148
    move/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move v14, v2

    const/4 v15, 0x0

    cmpg-float v14, v14, v15

    if-gez v14, :cond_0

    const/4 v14, 0x0

    move v2, v14

    .line 149
    :cond_0
    move v14, v2

    const/high16 v15, 0x3f800000    # 1.0f

    cmpl-float v14, v14, v15

    if-lez v14, :cond_1

    const/high16 v14, 0x3f800000    # 1.0f

    move v2, v14

    .line 150
    :cond_1
    move v14, v0

    const/16 v15, 0x10

    shr-int/lit8 v14, v14, 0x10

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v4, v14

    move v14, v0

    const/16 v15, 0x8

    shr-int/lit8 v14, v14, 0x8

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v5, v14

    move v14, v0

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v6, v14

    .line 151
    move v14, v1

    const/16 v15, 0x10

    shr-int/lit8 v14, v14, 0x10

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v7, v14

    move v14, v1

    const/16 v15, 0x8

    shr-int/lit8 v14, v14, 0x8

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v8, v14

    move v14, v1

    const/16 v15, 0xff

    and-int/lit16 v14, v14, 0xff

    move v9, v14

    .line 152
    move v14, v4

    int-to-float v14, v14

    move v15, v7

    move/from16 v16, v4

    sub-int v15, v15, v16

    int-to-float v15, v15

    move/from16 v16, v2

    mul-float v15, v15, v16

    add-float/2addr v14, v15

    float-to-int v14, v14

    move v10, v14

    .line 153
    move v14, v5

    int-to-float v14, v14

    move v15, v8

    move/from16 v16, v5

    sub-int v15, v15, v16

    int-to-float v15, v15

    move/from16 v16, v2

    mul-float v15, v15, v16

    add-float/2addr v14, v15

    float-to-int v14, v14

    move v11, v14

    .line 154
    move v14, v6

    int-to-float v14, v14

    move v15, v9

    move/from16 v16, v6

    sub-int v15, v15, v16

    int-to-float v15, v15

    move/from16 v16, v2

    mul-float v15, v15, v16

    add-float/2addr v14, v15

    float-to-int v14, v14

    move v12, v14

    .line 155
    const/high16 v14, -0x1000000

    move v15, v10

    const/16 v16, 0x10

    shl-int/lit8 v15, v15, 0x10

    or-int/2addr v14, v15

    move v15, v11

    const/16 v16, 0x8

    shl-int/lit8 v15, v15, 0x8

    or-int/2addr v14, v15

    move v15, v12

    or-int/2addr v14, v15

    move v0, v14

    return v0
.end method

.method public static neonifyButton(Landroid/content/Context;Landroid/widget/Button;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            ")V"
        }
    .end annotation

    .prologue
    .line 749
    move-object v0, p0

    move-object v1, p1

    move-object v7, v1

    invoke-virtual {v7}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    move-object v3, v7

    .line 750
    move-object v7, v3

    if-eqz v7, :cond_0

    move-object v7, v3

    instance-of v7, v7, Lgtandroid/universal/NeonUi$Btn;

    if-eqz v7, :cond_1

    .line 764
    :cond_0
    :goto_0
    return-void

    .line 751
    :cond_1
    move-object v7, v3

    instance-of v7, v7, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v7, :cond_3

    .line 753
    move-object v7, v3

    check-cast v7, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v7}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v7

    move v5, v7

    .line 754
    move v7, v5

    invoke-static {v7}, Landroid/graphics/Color;->alpha(I)I

    move-result v7

    const/16 v8, 0x10

    if-ge v7, v8, :cond_2

    goto :goto_0

    .line 755
    :cond_2
    move v7, v5

    const/high16 v8, -0x1000000

    or-int/2addr v7, v8

    move v4, v7

    .line 759
    :goto_1
    move-object v7, v1

    move-object v8, v0

    move v9, v4

    const/high16 v10, 0x41600000    # 14.0f

    invoke-static {v8, v9, v10}, Lgtandroid/universal/NeonUi;->buttonDrawable(Landroid/content/Context;IF)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 760
    move-object v7, v1

    invoke-static {v7}, Lgtandroid/universal/NeonUi;->fixTextLayout(Landroid/widget/TextView;)V

    .line 761
    move-object v7, v1

    const/4 v8, 0x0

    check-cast v8, Landroid/graphics/Typeface;

    const/4 v9, 0x1

    invoke-virtual {v7, v8, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 762
    move-object v7, v1

    move-object v8, v0

    const/4 v9, 0x2

    int-to-float v9, v9

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v8

    int-to-float v8, v8

    const/4 v9, 0x0

    move-object v10, v0

    const/4 v11, 0x1

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    const/high16 v11, -0x56000000

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 763
    move-object v7, v1

    const/4 v8, 0x0

    check-cast v8, Landroid/animation/StateListAnimator;

    invoke-virtual {v7, v8}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 764
    move-object v7, v1

    invoke-static {v7}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;)V

    goto :goto_0

    .line 757
    :cond_3
    const v7, -0xaaaaab

    move v4, v7

    goto :goto_1
.end method

.method private static neonifyPanel(Landroid/content/Context;Landroid/view/View;I)V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 793
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object v15, v2

    invoke-virtual {v15}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v15

    move-object v5, v15

    .line 794
    move-object v15, v5

    instance-of v15, v15, Lgtandroid/universal/NeonUi$Panel;

    if-eqz v15, :cond_0

    .line 795
    move-object v15, v5

    move/from16 v16, v3

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 828
    :goto_0
    return-void

    .line 798
    :cond_0
    move-object v15, v5

    instance-of v15, v15, Landroid/graphics/drawable/ColorDrawable;

    if-nez v15, :cond_1

    goto :goto_0

    .line 799
    :cond_1
    move-object v15, v5

    check-cast v15, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v15}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v15

    move v6, v15

    .line 800
    move v15, v6

    invoke-static {v15}, Landroid/graphics/Color;->alpha(I)I

    move-result v15

    const/16 v16, 0x10

    move/from16 v0, v16

    if-ge v15, v0, :cond_2

    goto :goto_0

    .line 801
    :cond_2
    move v15, v6

    const/high16 v16, -0x1000000

    or-int v15, v15, v16

    move v7, v15

    .line 803
    move-object v15, v2

    invoke-virtual {v15}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v15

    move-object v8, v15

    .line 804
    move-object v15, v8

    if-eqz v15, :cond_3

    move-object v15, v8

    iget v15, v15, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_3

    move-object v15, v8

    iget v15, v15, Landroid/view/ViewGroup$LayoutParams;->height:I

    move-object/from16 v16, v1

    const/16 v17, 0x8

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v16

    move/from16 v0, v16

    if-gt v15, v0, :cond_3

    .line 805
    move-object v15, v2

    const v16, -0xe1d5b8

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setBackgroundColor(I)V

    .line 806
    goto :goto_0

    .line 809
    :cond_3
    move-object v15, v2

    instance-of v15, v15, Landroid/view/ViewGroup;

    if-eqz v15, :cond_4

    const/4 v15, 0x0

    :goto_1
    move v9, v15

    .line 811
    move v15, v9

    if-nez v15, :cond_5

    move v15, v7

    invoke-static {v15}, Lgtandroid/universal/NeonUi;->luma(I)I

    move-result v15

    const/16 v16, 0x28

    move/from16 v0, v16

    if-ge v15, v0, :cond_5

    move v15, v7

    invoke-static {v15}, Lgtandroid/universal/NeonUi;->isNeutral(I)Z

    move-result v15

    if-eqz v15, :cond_5

    .line 812
    move-object v15, v2

    const/16 v16, 0x0

    check-cast v16, Landroid/graphics/drawable/Drawable;

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 813
    goto :goto_0

    .line 809
    :cond_4
    const/4 v15, 0x1

    goto :goto_1

    .line 816
    :cond_5
    move v15, v7

    invoke-static {v15}, Lgtandroid/universal/NeonUi;->isNeutral(I)Z

    move-result v15

    if-eqz v15, :cond_6

    .line 818
    const v15, -0xe9ddc2

    move v10, v15

    .line 819
    const v15, -0xf1e9d8

    move v11, v15

    .line 820
    const v15, -0xd5c59d

    move v12, v15

    .line 826
    :goto_2
    move-object v15, v1

    move/from16 v16, v9

    if-eqz v16, :cond_7

    const/high16 v16, 0x41000000    # 8.0f

    :goto_3
    const/high16 v17, 0x3f800000    # 1.0f

    move/from16 v18, v10

    move/from16 v19, v11

    move/from16 v20, v12

    invoke-static/range {v15 .. v20}, Lgtandroid/universal/NeonUi;->panel(Landroid/content/Context;FFIII)Lgtandroid/universal/NeonUi$Panel;

    move-result-object v15

    move-object v13, v15

    .line 827
    move-object v15, v13

    move/from16 v16, v3

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    .line 828
    move-object v15, v2

    move-object/from16 v16, v13

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_0

    .line 822
    :cond_6
    move v15, v7

    const v16, -0xf4efe0

    const v17, 0x3f3851ec    # 0.72f

    invoke-static/range {v15 .. v17}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v15

    move v10, v15

    .line 823
    move v15, v7

    const v16, -0xf9f5ec

    const v17, 0x3f59999a    # 0.85f

    invoke-static/range {v15 .. v17}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v15

    move v11, v15

    .line 824
    move v15, v7

    const v16, 0x3e4ccccd    # 0.2f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v15

    const/16 v16, 0xc0

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v15

    move v12, v15

    goto :goto_2

    .line 826
    :cond_7
    const/high16 v16, 0x41400000    # 12.0f

    goto :goto_3
.end method

.method public static neonifyTree(Landroid/content/Context;Landroid/view/View;I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 832
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v7, v1

    if-nez v7, :cond_0

    .line 846
    :goto_0
    return-void

    .line 834
    :cond_0
    move-object v7, v1

    instance-of v7, v7, Landroid/widget/Button;

    if-eqz v7, :cond_2

    .line 835
    move-object v7, v0

    move-object v8, v1

    check-cast v8, Landroid/widget/Button;

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->neonifyButton(Landroid/content/Context;Landroid/widget/Button;)V

    .line 844
    :goto_1
    move-object v7, v1

    instance-of v7, v7, Landroid/view/ViewGroup;

    if-eqz v7, :cond_1

    .line 845
    move-object v7, v1

    check-cast v7, Landroid/view/ViewGroup;

    move-object v4, v7

    .line 846
    const/4 v7, 0x0

    move v5, v7

    :goto_2
    move v7, v5

    move-object v8, v4

    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    if-lt v7, v8, :cond_5

    :cond_1
    goto :goto_0

    .line 836
    :cond_2
    move-object v7, v1

    instance-of v7, v7, Landroid/widget/EditText;

    if-eqz v7, :cond_3

    goto :goto_1

    .line 838
    :cond_3
    move-object v7, v1

    instance-of v7, v7, Landroid/widget/TextView;

    if-eqz v7, :cond_4

    move-object v7, v1

    check-cast v7, Landroid/widget/TextView;

    invoke-static {v7}, Lgtandroid/universal/NeonUi;->isDecoratedTitle(Landroid/widget/TextView;)Z

    move-result v7

    if-eqz v7, :cond_4

    .line 839
    move-object v7, v0

    move-object v8, v1

    check-cast v8, Landroid/widget/TextView;

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->styleTitle(Landroid/content/Context;Landroid/widget/TextView;)V

    goto :goto_1

    .line 841
    :cond_4
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-static {v7, v8, v9}, Lgtandroid/universal/NeonUi;->neonifyPanel(Landroid/content/Context;Landroid/view/View;I)V

    goto :goto_1

    .line 847
    :cond_5
    move-object v7, v0

    move-object v8, v4

    move v9, v5

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    move v9, v2

    invoke-static {v7, v8, v9}, Lgtandroid/universal/NeonUi;->neonifyTree(Landroid/content/Context;Landroid/view/View;I)V

    .line 846
    add-int/lit8 v5, v5, 0x1

    goto :goto_2
.end method

.method private static numKeyDrawable(Landroid/content/Context;FIIII)Landroid/graphics/drawable/Drawable;
    .locals 19

    .prologue
    .line 1500
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    new-instance v10, Landroid/graphics/drawable/StateListDrawable;

    move-object/from16 v18, v10

    move-object/from16 v10, v18

    move-object/from16 v11, v18

    invoke-direct {v11}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    move-object v7, v10

    .line 1501
    move-object v10, v0

    move v11, v1

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    move v8, v10

    .line 1502
    move-object v10, v7

    const/4 v11, 0x1

    new-array v11, v11, [I

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    const/4 v13, 0x0

    const v14, 0x10100a7

    aput v14, v12, v13

    new-instance v12, Lgtandroid/universal/NeonUi$NumKeyBg;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v8

    move v15, v2

    const v16, 0x3df5c28f    # 0.12f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v15

    move/from16 v16, v3

    const v17, 0x3dcccccd    # 0.1f

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v16

    move/from16 v17, v5

    invoke-direct/range {v13 .. v17}, Lgtandroid/universal/NeonUi$NumKeyBg;-><init>(FIII)V

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1503
    move-object v10, v7

    const/4 v11, 0x0

    new-array v11, v11, [I

    new-instance v12, Lgtandroid/universal/NeonUi$NumKeyBg;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v8

    move v15, v2

    move/from16 v16, v3

    move/from16 v17, v4

    invoke-direct/range {v13 .. v17}, Lgtandroid/universal/NeonUi$NumKeyBg;-><init>(FIII)V

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1504
    move-object v10, v7

    move-object v0, v10

    return-object v0
.end method

.method public static panel(Landroid/content/Context;FFIII)Lgtandroid/universal/NeonUi$Panel;
    .locals 15

    .prologue
    .line 180
    move-object v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    new-instance v9, Lgtandroid/universal/NeonUi$Panel;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Lgtandroid/universal/NeonUi$Panel;-><init>()V

    move-object v7, v9

    .line 181
    move-object v9, v7

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 182
    move-object v9, v7

    sget-object v10, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    .line 183
    move-object v9, v7

    const/4 v10, 0x2

    new-array v10, v10, [I

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, 0x0

    move v13, v3

    aput v13, v11, v12

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, 0x1

    move v13, v4

    aput v13, v11, v12

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setColors([I)V

    .line 184
    move-object v9, v7

    move-object v10, v0

    move v11, v1

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 185
    move v9, v2

    const/4 v10, 0x0

    cmpl-float v9, v9, v10

    if-lez v9, :cond_0

    .line 186
    move-object v9, v7

    const/4 v10, 0x1

    move-object v11, v0

    move v12, v2

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-static {v10, v11}, Ljava/lang/Math;->max(II)I

    move-result v10

    move v11, v5

    invoke-virtual {v9, v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 188
    :cond_0
    move-object v9, v7

    move-object v0, v9

    return-object v0
.end method

.method public static refreshTextLayout(Landroid/widget/TextView;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    .prologue
    .line 686
    move-object v0, p0

    move-object v4, v0

    invoke-virtual {v4}, Landroid/widget/TextView;->getIncludeFontPadding()Z

    move-result v4

    move v2, v4

    .line 687
    move-object v4, v0

    move v5, v2

    if-eqz v5, :cond_0

    const/4 v5, 0x0

    :goto_0
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 688
    move-object v4, v0

    move v5, v2

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    return-void

    .line 687
    :cond_0
    const/4 v5, 0x1

    goto :goto_0
.end method

.method public static setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Landroid/graphics/drawable/Drawable;",
            ")V"
        }
    .end annotation

    .prologue
    .line 172
    move-object v0, p0

    move-object v1, p1

    move-object v8, v0

    invoke-virtual {v8}, Landroid/view/View;->getPaddingLeft()I

    move-result v8

    move v3, v8

    move-object v8, v0

    invoke-virtual {v8}, Landroid/view/View;->getPaddingTop()I

    move-result v8

    move v4, v8

    move-object v8, v0

    invoke-virtual {v8}, Landroid/view/View;->getPaddingRight()I

    move-result v8

    move v5, v8

    move-object v8, v0

    invoke-virtual {v8}, Landroid/view/View;->getPaddingBottom()I

    move-result v8

    move v6, v8

    .line 174
    move-object v8, v0

    move-object v9, v1

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 175
    move-object v8, v0

    move v9, v3

    move v10, v4

    move v11, v5

    move v12, v6

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    return-void
.end method

.method public static styleHeader(Landroid/content/Context;Landroid/widget/TextView;I)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/TextView;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 311
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move-object v7, v1

    invoke-virtual {v7}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    move-object v4, v7

    .line 312
    move-object v7, v4

    instance-of v7, v7, Lgtandroid/universal/NeonUi$HeaderBg;

    if-nez v7, :cond_0

    .line 313
    new-instance v7, Lgtandroid/universal/NeonUi$HeaderBg;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v9, v0

    move-object v10, v1

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/NeonUi$HeaderBg;-><init>(Landroid/content/Context;Landroid/widget/TextView;)V

    move-object v4, v7

    .line 314
    move-object v7, v1

    move-object v8, v4

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 315
    move-object v7, v1

    move-object v8, v0

    const/16 v9, 0x8

    int-to-float v9, v9

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v8

    move-object v9, v0

    const/4 v10, 0x4

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0x8

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    move-object v11, v0

    const/4 v12, 0x4

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 316
    move-object v7, v1

    const/16 v8, 0x11

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setGravity(I)V

    .line 317
    move-object v7, v1

    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    move-object v5, v7

    .line 318
    move-object v7, v5

    instance-of v7, v7, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v7, :cond_0

    .line 319
    move-object v7, v5

    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    move-object v8, v0

    const/4 v9, 0x3

    int-to-float v9, v9

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v8

    iput v8, v7, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 320
    move-object v7, v1

    move-object v8, v5

    invoke-virtual {v7, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 323
    :cond_0
    move-object v7, v4

    move v8, v2

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 324
    move-object v7, v1

    const v8, -0x401901

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 325
    move-object v7, v1

    const/4 v8, 0x0

    check-cast v8, Landroid/graphics/Typeface;

    const/4 v9, 0x1

    invoke-virtual {v7, v8, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 326
    move-object v7, v1

    const v8, 0x3d23d70a    # 0.04f

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 327
    move-object v7, v1

    move-object v8, v0

    const/4 v9, 0x4

    int-to-float v9, v9

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v8

    int-to-float v8, v8

    const/4 v9, 0x0

    const/4 v10, 0x0

    const v11, -0xd13701

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    return-void
.end method

.method public static styleNeonButton(Landroid/content/Context;Landroid/widget/Button;IIIFF)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            "IIIFF)V"
        }
    .end annotation

    .prologue
    .line 727
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object v9, v1

    move-object v10, v0

    move v11, v3

    move v12, v4

    move v13, v5

    invoke-static {v10, v11, v12, v13}, Lgtandroid/universal/NeonUi;->gradientButton(Landroid/content/Context;IIF)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 728
    move-object v9, v1

    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 729
    move-object v9, v1

    const/4 v10, 0x0

    check-cast v10, Landroid/graphics/Typeface;

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 730
    move-object v9, v1

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 731
    move-object v9, v1

    invoke-static {v9}, Lgtandroid/universal/NeonUi;->fixTextLayout(Landroid/widget/TextView;)V

    .line 732
    move-object v9, v1

    move-object v10, v0

    const/4 v11, 0x2

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    const/4 v11, 0x0

    move-object v12, v0

    const/4 v13, 0x1

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    int-to-float v12, v12

    const/high16 v13, -0x56000000

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 733
    move-object v9, v1

    const/4 v10, 0x0

    check-cast v10, Landroid/animation/StateListAnimator;

    invoke-virtual {v9, v10}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 734
    move-object v9, v1

    move v10, v2

    const/4 v11, 0x0

    if-ne v10, v11, :cond_0

    const/16 v10, 0x11

    :goto_0
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 735
    move-object v9, v1

    move-object v10, v0

    const/16 v11, 0xa

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    const/4 v11, 0x0

    move-object v12, v0

    const/16 v13, 0x8

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 736
    move-object v9, v0

    move-object v10, v1

    move v11, v2

    move v12, v6

    invoke-static {v9, v10, v11, v12}, Lgtandroid/universal/NeonUi;->attachIcon(Landroid/content/Context;Landroid/widget/Button;IF)V

    .line 737
    move-object v9, v1

    invoke-static {v9}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;)V

    return-void

    .line 734
    :cond_0
    const/16 v10, 0x13

    goto :goto_0
.end method

.method public static styleTabButton(Landroid/content/Context;Landroid/widget/Button;IIZLjava/lang/String;FI)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            "IIZ",
            "Ljava/lang/String;",
            "FI)V"
        }
    .end annotation

    .prologue
    .line 1189
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move/from16 v4, p2

    move/from16 v5, p3

    move/from16 v6, p4

    move-object/from16 v7, p5

    move/from16 v8, p6

    move/from16 v9, p7

    move-object v13, v3

    move-object v14, v2

    move v15, v5

    move/from16 v16, v6

    const/high16 v17, 0x41800000    # 16.0f

    invoke-static/range {v14 .. v17}, Lgtandroid/universal/NeonUi;->tabDrawable(Landroid/content/Context;IZF)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 1190
    move-object v13, v3

    const/4 v14, -0x1

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1191
    move-object v13, v3

    const/4 v14, 0x0

    check-cast v14, Landroid/graphics/Typeface;

    const/4 v15, 0x1

    invoke-virtual {v13, v14, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1192
    move-object v13, v3

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1193
    move-object v13, v3

    invoke-static {v13}, Lgtandroid/universal/NeonUi;->fixTextLayoutOnce(Landroid/widget/TextView;)V

    .line 1194
    move-object v13, v3

    move-object v14, v2

    const/4 v15, 0x3

    int-to-float v15, v15

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v14

    int-to-float v14, v14

    const/4 v15, 0x0

    const/16 v16, 0x0

    move/from16 v17, v5

    const/16 v18, 0xaa

    invoke-static/range {v17 .. v18}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v17

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 1195
    move-object v13, v3

    const/4 v14, 0x0

    check-cast v14, Landroid/animation/StateListAnimator;

    invoke-virtual {v13, v14}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 1196
    move v13, v4

    const/4 v14, 0x0

    if-ne v13, v14, :cond_0

    const/4 v13, 0x0

    :goto_0
    move v11, v13

    .line 1197
    move-object v13, v3

    move v14, v11

    if-eqz v14, :cond_1

    const/16 v14, 0x13

    :goto_1
    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 1198
    move-object v13, v3

    move-object v14, v2

    const/4 v15, 0x6

    int-to-float v15, v15

    invoke-static {v14, v15}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v14

    move v15, v9

    add-int/2addr v14, v15

    const/4 v15, 0x0

    move-object/from16 v16, v2

    const/16 v17, 0x4

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v16

    const/16 v17, 0x0

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1199
    move-object v13, v2

    move-object v14, v3

    move v15, v4

    move/from16 v16, v8

    move/from16 v17, v5

    move/from16 v18, v4

    const/16 v19, 0xa

    move/from16 v0, v18

    move/from16 v1, v19

    if-ne v0, v1, :cond_2

    const/16 v18, -0x36b3

    :goto_2
    invoke-static/range {v13 .. v18}, Lgtandroid/universal/NeonUi;->attachIcon(Landroid/content/Context;Landroid/widget/Button;IFII)V

    .line 1200
    move-object v13, v3

    const/4 v14, 0x2

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1201
    move-object v13, v3

    move-object v14, v7

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1202
    move-object v13, v3

    invoke-static {v13}, Lgtandroid/universal/NeonUi;->attachPressEffect(Landroid/view/View;)V

    return-void

    .line 1196
    :cond_0
    const/4 v13, 0x1

    goto :goto_0

    .line 1197
    :cond_1
    const/16 v14, 0x11

    goto :goto_1

    .line 1199
    :cond_2
    const/16 v18, -0x1

    goto :goto_2
.end method

.method private static styleTitle(Landroid/content/Context;Landroid/widget/TextView;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    .prologue
    .line 773
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v8, v1

    invoke-virtual {v8}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v8

    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v8

    const-string v9, "\u2550"

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v3, v8

    .line 774
    const-string v8, "\u2501\u2501\u2501"

    move-object v4, v8

    .line 775
    new-instance v8, Ljava/lang/StringBuffer;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    move-object v12, v4

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "  "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v3

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "  "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v4

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v5, v8

    .line 776
    new-instance v8, Landroid/text/SpannableString;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v5

    invoke-direct {v9, v10}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object v6, v8

    .line 777
    move-object v8, v6

    new-instance v9, Landroid/text/style/ForegroundColorSpan;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    const v11, -0x907937

    invoke-direct {v10, v11}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    const/4 v10, 0x0

    move-object v11, v4

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    const/16 v12, 0x21

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 779
    move-object v8, v6

    new-instance v9, Landroid/text/style/ForegroundColorSpan;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    const v11, -0x907937

    invoke-direct {v10, v11}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    move-object v10, v5

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    move-object v11, v4

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    sub-int/2addr v10, v11

    move-object v11, v5

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    const/16 v12, 0x21

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 781
    move-object v8, v1

    move-object v9, v6

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 782
    move-object v8, v1

    invoke-virtual {v8}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v8

    const/4 v9, -0x1

    if-ne v8, v9, :cond_0

    move-object v8, v1

    const v9, -0x150d01

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 783
    :cond_0
    move-object v8, v1

    const/4 v9, 0x0

    check-cast v9, Landroid/graphics/Typeface;

    const/4 v10, 0x1

    invoke-virtual {v8, v9, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 784
    move-object v8, v1

    const v9, 0x3d75c28f    # 0.06f

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 785
    move-object v8, v1

    move-object v9, v0

    const/4 v10, 0x5

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    int-to-float v9, v9

    const/4 v10, 0x0

    const/4 v11, 0x0

    const v12, -0xd13701

    const/16 v13, 0xaa

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 786
    move-object v8, v1

    const/4 v9, 0x0

    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 788
    move-object v8, v1

    const/high16 v9, 0x41000000    # 8.0f

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 789
    move-object v8, v1

    move-object v9, v0

    const/4 v10, 0x2

    int-to-float v10, v10

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v9

    move-object v10, v0

    const/4 v11, 0x1

    int-to-float v11, v11

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v10

    move-object v11, v0

    const/4 v12, 0x2

    int-to-float v12, v12

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v11

    move-object v12, v0

    const/4 v13, 0x1

    int-to-float v13, v13

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    return-void
.end method

.method public static tabDrawable(Landroid/content/Context;IZF)Landroid/graphics/drawable/Drawable;
    .locals 29

    .prologue
    .line 1173
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object v12, v0

    move v13, v3

    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v12

    int-to-float v12, v12

    move v5, v12

    .line 1174
    move v12, v1

    const v13, -0xf4edd0

    move v14, v2

    if-eqz v14, :cond_0

    const v14, 0x3f28f5c3    # 0.66f

    :goto_0
    invoke-static {v12, v13, v14}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v12

    move v6, v12

    .line 1175
    move v12, v1

    const v13, -0xf8f3dc

    move v14, v2

    if-eqz v14, :cond_1

    const v14, 0x3f47ae14    # 0.78f

    :goto_1
    invoke-static {v12, v13, v14}, Lgtandroid/universal/NeonUi;->mix(IIF)I

    move-result v12

    move v7, v12

    .line 1176
    move v12, v2

    if-eqz v12, :cond_2

    const/high16 v12, 0x40000000    # 2.0f

    :goto_2
    move v8, v12

    .line 1177
    move v12, v1

    move v13, v2

    if-eqz v13, :cond_3

    const/16 v13, 0x88

    :goto_3
    invoke-static {v12, v13}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v12

    move v9, v12

    .line 1178
    new-instance v12, Lgtandroid/universal/NeonUi$Btn;

    move-object/from16 v28, v12

    move-object/from16 v12, v28

    move-object/from16 v13, v28

    invoke-direct {v13}, Lgtandroid/universal/NeonUi$Btn;-><init>()V

    move-object v10, v12

    .line 1179
    move-object v12, v10

    const/4 v13, 0x1

    new-array v13, v13, [I

    move-object/from16 v28, v13

    move-object/from16 v13, v28

    move-object/from16 v14, v28

    const/4 v15, 0x0

    const v16, 0x10100a7

    aput v16, v14, v15

    move-object v14, v0

    move v15, v6

    const v16, 0x3df5c28f    # 0.12f

    invoke-static/range {v15 .. v16}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v15

    move/from16 v16, v7

    const v17, 0x3dcccccd    # 0.1f

    invoke-static/range {v16 .. v17}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v16

    move/from16 v17, v1

    const v18, 0x3e99999a    # 0.3f

    invoke-static/range {v17 .. v18}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v17

    move/from16 v18, v1

    const/16 v19, 0xaa

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v18

    move/from16 v19, v5

    const/16 v20, 0x1

    move/from16 v21, v8

    const/16 v22, 0x10

    invoke-static/range {v14 .. v22}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-virtual {v12, v13, v14}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1182
    move-object v12, v10

    const/4 v13, 0x0

    new-array v13, v13, [I

    move-object v14, v0

    move v15, v6

    move/from16 v16, v7

    move/from16 v17, v1

    move/from16 v18, v9

    move/from16 v19, v5

    const/16 v20, 0x0

    move/from16 v21, v8

    move/from16 v22, v2

    if-eqz v22, :cond_4

    const/16 v22, 0x22

    :goto_4
    invoke-static/range {v14 .. v22}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-virtual {v12, v13, v14}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1184
    move-object v12, v10

    move-object v0, v12

    return-object v0

    .line 1174
    :cond_0
    const v14, 0x3f4ccccd    # 0.8f

    goto/16 :goto_0

    .line 1175
    :cond_1
    const v14, 0x3f6147ae    # 0.88f

    goto/16 :goto_1

    .line 1176
    :cond_2
    const/high16 v12, 0x3fc00000    # 1.5f

    goto/16 :goto_2

    .line 1177
    :cond_3
    const/16 v13, 0x44

    goto/16 :goto_3

    .line 1182
    :cond_4
    const/16 v22, 0x14

    goto :goto_4
.end method

.method public static tileDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .locals 17

    .prologue
    .line 1206
    move-object/from16 v0, p0

    move-object v5, v0

    const/high16 v6, 0x41400000    # 12.0f

    invoke-static {v5, v6}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v5

    int-to-float v5, v5

    move v2, v5

    .line 1207
    new-instance v5, Lgtandroid/universal/NeonUi$Btn;

    move-object/from16 v16, v5

    move-object/from16 v5, v16

    move-object/from16 v6, v16

    invoke-direct {v6}, Lgtandroid/universal/NeonUi$Btn;-><init>()V

    move-object v3, v5

    .line 1208
    move-object v5, v3

    const/4 v6, 0x1

    new-array v6, v6, [I

    move-object/from16 v16, v6

    move-object/from16 v6, v16

    move-object/from16 v7, v16

    const/4 v8, 0x0

    const v9, 0x10100a7

    aput v9, v7, v8

    move-object v7, v0

    const v8, -0xefe5bb

    const v9, 0x3df5c28f    # 0.12f

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v8

    const v9, -0xf3ebc8

    const v10, 0x3df5c28f    # 0.12f

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->lighten(IF)I

    move-result v9

    const v10, -0x907301

    const/16 v11, 0xe0

    invoke-static {v10, v11}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v10

    const v11, -0xb28401

    const/16 v12, 0x66

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v11

    move v12, v2

    const/4 v13, 0x1

    const v14, 0x3fa66666    # 1.3f

    const/16 v15, 0x10

    invoke-static/range {v7 .. v15}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1211
    move-object v5, v3

    const/4 v6, 0x0

    new-array v6, v6, [I

    move-object v7, v0

    const v8, -0xefe5bb

    const v9, -0xf3ebc8

    const v10, -0x73d1b028

    const v11, -0xd1b028

    const/16 v12, 0x22

    invoke-static {v11, v12}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v11

    move v12, v2

    const/4 v13, 0x0

    const v14, 0x3f8ccccd    # 1.1f

    const/16 v15, 0xc

    invoke-static/range {v7 .. v15}, Lgtandroid/universal/NeonUi;->layeredEx(Landroid/content/Context;IIIIFZFI)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 1214
    move-object v5, v3

    move-object v0, v5

    return-object v0
.end method

.method public static tintTile(Landroid/content/Context;Landroid/widget/Button;I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/Button;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 1247
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v5, v1

    move-object v6, v0

    move v7, v2

    const/4 v8, 0x1

    const/high16 v9, 0x41400000    # 12.0f

    invoke-static {v6, v7, v8, v9}, Lgtandroid/universal/NeonUi;->tabDrawable(Landroid/content/Context;IZF)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 1248
    move-object v5, v1

    const/4 v6, -0x1

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method public static withAlpha(II)I
    .locals 7

    .prologue
    .line 144
    move v0, p0

    move v1, p1

    move v4, v1

    const/16 v5, 0xff

    and-int/lit16 v4, v4, 0xff

    const/16 v5, 0x18

    shl-int/lit8 v4, v4, 0x18

    move v5, v0

    const v6, 0xffffff

    and-int/2addr v5, v6

    or-int/2addr v4, v5

    move v0, v4

    return v0
.end method
