.class public Lgtandroid/universal/AreaSelectorService;
.super Landroid/app/Service;
.source "AreaSelectorService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/AreaSelectorService$100000000;,
        Lgtandroid/universal/AreaSelectorService$100000001;,
        Lgtandroid/universal/AreaSelectorService$100000002;,
        Lgtandroid/universal/AreaSelectorService$100000003;,
        Lgtandroid/universal/AreaSelectorService$100000004;
    }
.end annotation


# static fields
.field private static final BORDER_WIDTH:I = 0x4

.field private static final HANDLE_BOTTOM_LEFT:I = 0x6

.field private static final HANDLE_BOTTOM_RIGHT:I = 0x7

.field private static final HANDLE_MOVE:I = 0x8

.field private static final HANDLE_NONE:I = -0x1

.field private static final HANDLE_SIZE:I = 0x64

.field private static final HANDLE_TOP_LEFT:I = 0x4

.field private static final HANDLE_TOP_RIGHT:I = 0x5

.field private static final MIN_SIZE:I = 0x50


# instance fields
.field private bottomBorder:Landroid/view/View;

.field private bottomLeftHandle:Landroid/view/View;

.field private bottomRightHandle:Landroid/view/View;

.field private btnCancel:Landroid/widget/Button;

.field private btnSave:Landroid/widget/Button;

.field private dragHandle:I

.field private handler:Landroid/os/Handler;

.field private isDragging:Z

.field private leftBorder:Landroid/view/View;

.field private overlayView:Landroid/widget/FrameLayout;

.field private prefs:Landroid/content/SharedPreferences;

.field private rightBorder:Landroid/view/View;

.field private screenHeight:I

.field private screenWidth:I

.field private selectionRect:Landroid/graphics/Rect;

.field private selectionView:Landroid/widget/FrameLayout;

.field private startRect:Landroid/graphics/Rect;

.field private startX:F

.field private startY:F

.field private topBorder:Landroid/view/View;

.field private topLeftHandle:Landroid/view/View;

.field private topRightHandle:Landroid/view/View;

.field private tvSize:Landroid/widget/TextView;

.field private updateRunnable:Ljava/lang/Runnable;

.field private windowManager:Landroid/view/WindowManager;


# direct methods
.method public constructor <init>()V
    .locals 6

    .prologue
    .line 504
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/app/Service;-><init>()V

    move-object v2, v0

    new-instance v3, Landroid/graphics/Rect;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    iput-object v3, v2, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    move-object v2, v0

    const/4 v3, 0x0

    iput-boolean v3, v2, Lgtandroid/universal/AreaSelectorService;->isDragging:Z

    move-object v2, v0

    const/4 v3, -0x1

    iput v3, v2, Lgtandroid/universal/AreaSelectorService;->dragHandle:I

    move-object v2, v0

    new-instance v3, Landroid/graphics/Rect;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    iput-object v3, v2, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    move-object v2, v0

    new-instance v3, Landroid/os/Handler;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Landroid/os/Handler;-><init>()V

    iput-object v3, v2, Lgtandroid/universal/AreaSelectorService;->handler:Landroid/os/Handler;

    return-void
.end method

.method static access$1000045(Lgtandroid/universal/AreaSelectorService;FF)V
    .locals 8

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v5, v0

    move v6, v1

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/AreaSelectorService;->handleDrag(FF)V

    return-void
.end method

.method static access$1000046(Lgtandroid/universal/AreaSelectorService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/AreaSelectorService;->updateSelectionView()V

    return-void
.end method

.method static access$1000048(Lgtandroid/universal/AreaSelectorService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/AreaSelectorService;->saveAreaToPrefs()V

    return-void
.end method

.method static access$1000049(Lgtandroid/universal/AreaSelectorService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/AreaSelectorService;->saveAndStartTracking()V

    return-void
.end method

.method static access$L1000001(Lgtandroid/universal/AreaSelectorService;)Landroid/widget/FrameLayout;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000002(Lgtandroid/universal/AreaSelectorService;)Landroid/widget/FrameLayout;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000016(Lgtandroid/universal/AreaSelectorService;)Landroid/graphics/Rect;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000017(Lgtandroid/universal/AreaSelectorService;)Z
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-boolean v3, v3, Lgtandroid/universal/AreaSelectorService;->isDragging:Z

    move v0, v3

    return v0
.end method

.method static access$L1000018(Lgtandroid/universal/AreaSelectorService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/AreaSelectorService;->dragHandle:I

    move v0, v3

    return v0
.end method

.method static access$L1000019(Lgtandroid/universal/AreaSelectorService;)F
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/AreaSelectorService;->startX:F

    move v0, v3

    return v0
.end method

.method static access$L1000020(Lgtandroid/universal/AreaSelectorService;)F
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/AreaSelectorService;->startY:F

    move v0, v3

    return v0
.end method

.method static access$L1000021(Lgtandroid/universal/AreaSelectorService;)Landroid/graphics/Rect;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000026()I
    .locals 3

    sget v2, Lgtandroid/universal/AreaSelectorService;->HANDLE_NONE:I

    move v0, v2

    return v0
.end method

.method static access$L1000031()I
    .locals 3

    sget v2, Lgtandroid/universal/AreaSelectorService;->HANDLE_MOVE:I

    move v0, v2

    return v0
.end method

.method static access$L1000032(Lgtandroid/universal/AreaSelectorService;)Landroid/os/Handler;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->handler:Landroid/os/Handler;

    move-object v0, v3

    return-object v0
.end method

.method static access$S1000001(Lgtandroid/universal/AreaSelectorService;Landroid/widget/FrameLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    return-void
.end method

.method static access$S1000002(Lgtandroid/universal/AreaSelectorService;Landroid/widget/FrameLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    return-void
.end method

.method static access$S1000016(Lgtandroid/universal/AreaSelectorService;Landroid/graphics/Rect;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    return-void
.end method

.method static access$S1000017(Lgtandroid/universal/AreaSelectorService;Z)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput-boolean v5, v4, Lgtandroid/universal/AreaSelectorService;->isDragging:Z

    return-void
.end method

.method static access$S1000018(Lgtandroid/universal/AreaSelectorService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/AreaSelectorService;->dragHandle:I

    return-void
.end method

.method static access$S1000019(Lgtandroid/universal/AreaSelectorService;F)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/AreaSelectorService;->startX:F

    return-void
.end method

.method static access$S1000020(Lgtandroid/universal/AreaSelectorService;F)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/AreaSelectorService;->startY:F

    return-void
.end method

.method static access$S1000021(Lgtandroid/universal/AreaSelectorService;Landroid/graphics/Rect;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    return-void
.end method

.method static access$S1000026(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/AreaSelectorService;->HANDLE_NONE:I

    return-void
.end method

.method static access$S1000031(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/AreaSelectorService;->HANDLE_MOVE:I

    return-void
.end method

.method static access$S1000032(Lgtandroid/universal/AreaSelectorService;Landroid/os/Handler;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->handler:Landroid/os/Handler;

    return-void
.end method

.method private addBorders()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 130
    move-object v0, p0

    const/high16 v9, -0x10000

    move v2, v9

    .line 131
    const/4 v9, 0x4

    move v3, v9

    .line 133
    move-object v9, v0

    new-instance v10, Landroid/view/View;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v10, v9, Lgtandroid/universal/AreaSelectorService;->topBorder:Landroid/view/View;

    .line 134
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->topBorder:Landroid/view/View;

    move v10, v2

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 135
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, -0x1

    move v12, v3

    invoke-direct {v10, v11, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v4, v9

    .line 138
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->topBorder:Landroid/view/View;

    move-object v11, v4

    invoke-virtual {v9, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 140
    move-object v9, v0

    new-instance v10, Landroid/view/View;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v10, v9, Lgtandroid/universal/AreaSelectorService;->bottomBorder:Landroid/view/View;

    .line 141
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->bottomBorder:Landroid/view/View;

    move v10, v2

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 142
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, -0x1

    move v12, v3

    invoke-direct {v10, v11, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v5, v9

    .line 145
    move-object v9, v5

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v10, v10, Landroid/view/ViewGroup$LayoutParams;->height:I

    move v11, v3

    sub-int/2addr v10, v11

    iput v10, v9, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 146
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->bottomBorder:Landroid/view/View;

    move-object v11, v5

    invoke-virtual {v9, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 148
    move-object v9, v0

    new-instance v10, Landroid/view/View;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v10, v9, Lgtandroid/universal/AreaSelectorService;->leftBorder:Landroid/view/View;

    .line 149
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->leftBorder:Landroid/view/View;

    move v10, v2

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 150
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    move v11, v3

    const/4 v12, -0x1

    invoke-direct {v10, v11, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v6, v9

    .line 153
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->leftBorder:Landroid/view/View;

    move-object v11, v6

    invoke-virtual {v9, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 155
    move-object v9, v0

    new-instance v10, Landroid/view/View;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v10, v9, Lgtandroid/universal/AreaSelectorService;->rightBorder:Landroid/view/View;

    .line 156
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->rightBorder:Landroid/view/View;

    move v10, v2

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 157
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    move v11, v3

    const/4 v12, -0x1

    invoke-direct {v10, v11, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v7, v9

    .line 160
    move-object v9, v7

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    iget v10, v10, Landroid/view/ViewGroup$LayoutParams;->width:I

    move v11, v3

    sub-int/2addr v10, v11

    iput v10, v9, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 161
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->rightBorder:Landroid/view/View;

    move-object v11, v7

    invoke-virtual {v9, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private addControls()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 282
    move-object v0, p0

    new-instance v6, Landroid/widget/LinearLayout;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 283
    move-object v6, v2

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 284
    move-object v6, v2

    const/16 v7, 0x11

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 285
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    const/4 v8, -0x2

    const/4 v9, -0x2

    invoke-direct {v7, v8, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v3, v6

    .line 289
    move-object v6, v3

    const/16 v7, 0x51

    iput v7, v6, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 290
    move-object v6, v3

    move-object v7, v0

    const/16 v8, 0xf

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v7

    iput v7, v6, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 291
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v7, v2

    move-object v8, v3

    invoke-virtual {v6, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 293
    move-object v6, v0

    new-instance v7, Landroid/widget/Button;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    .line 294
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    const-string v7, "\u274c"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 295
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    const/16 v7, 0x1c

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 296
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    const/high16 v7, -0x340000

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 297
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 298
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    move-object v7, v0

    const/16 v8, 0x14

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0xe

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0xe

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 299
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    const/4 v9, -0x2

    const/4 v10, -0x2

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 303
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    new-instance v7, Lgtandroid/universal/AreaSelectorService$100000002;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/AreaSelectorService$100000002;-><init>(Lgtandroid/universal/AreaSelectorService;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 309
    move-object v6, v2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/AreaSelectorService;->btnCancel:Landroid/widget/Button;

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 311
    new-instance v6, Landroid/view/View;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 312
    move-object v6, v4

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    const/16 v10, 0x1e

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v9

    move-object v10, v0

    const/4 v11, 0x1

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v10

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 313
    move-object v6, v2

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 315
    move-object v6, v0

    new-instance v7, Landroid/widget/Button;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    .line 316
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    const-string v7, "\u2705"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 317
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    const/16 v7, 0x1c

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 318
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    const v7, -0xff5600

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 319
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 320
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    move-object v7, v0

    const/16 v8, 0x14

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0xe

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0xe

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 321
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    const/4 v9, -0x2

    const/4 v10, -0x2

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 325
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    new-instance v7, Lgtandroid/universal/AreaSelectorService$100000003;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/AreaSelectorService$100000003;-><init>(Lgtandroid/universal/AreaSelectorService;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 331
    move-object v6, v2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/AreaSelectorService;->btnSave:Landroid/widget/Button;

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private addHandles()V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 165
    move-object/from16 v1, p0

    const/16 v12, 0x64

    move v3, v12

    .line 166
    const/4 v12, -0x1

    move v4, v12

    .line 168
    move-object v12, v1

    move-object v13, v1

    move v14, v4

    move v15, v3

    const/16 v16, 0x4

    invoke-direct/range {v13 .. v16}, Lgtandroid/universal/AreaSelectorService;->createHandleView(III)Landroid/view/View;

    move-result-object v13

    iput-object v13, v12, Lgtandroid/universal/AreaSelectorService;->topLeftHandle:Landroid/view/View;

    .line 169
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v3

    move v15, v3

    invoke-direct {v13, v14, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v5, v12

    .line 170
    move-object v12, v5

    move v13, v3

    neg-int v13, v13

    const/4 v14, 0x2

    div-int/lit8 v13, v13, 0x2

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 171
    move-object v12, v5

    move v13, v3

    neg-int v13, v13

    const/4 v14, 0x2

    div-int/lit8 v13, v13, 0x2

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 172
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topLeftHandle:Landroid/view/View;

    move-object v14, v5

    invoke-virtual {v12, v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 174
    move-object v12, v1

    move-object v13, v1

    move v14, v4

    move v15, v3

    const/16 v16, 0x5

    invoke-direct/range {v13 .. v16}, Lgtandroid/universal/AreaSelectorService;->createHandleView(III)Landroid/view/View;

    move-result-object v13

    iput-object v13, v12, Lgtandroid/universal/AreaSelectorService;->topRightHandle:Landroid/view/View;

    .line 175
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v3

    move v15, v3

    invoke-direct {v13, v14, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v6, v12

    .line 176
    move-object v12, v6

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    iget v13, v13, Landroid/view/ViewGroup$LayoutParams;->width:I

    move v14, v3

    const/4 v15, 0x2

    div-int/lit8 v14, v14, 0x2

    sub-int/2addr v13, v14

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 177
    move-object v12, v6

    move v13, v3

    neg-int v13, v13

    const/4 v14, 0x2

    div-int/lit8 v13, v13, 0x2

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 178
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topRightHandle:Landroid/view/View;

    move-object v14, v6

    invoke-virtual {v12, v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 180
    move-object v12, v1

    move-object v13, v1

    move v14, v4

    move v15, v3

    const/16 v16, 0x6

    invoke-direct/range {v13 .. v16}, Lgtandroid/universal/AreaSelectorService;->createHandleView(III)Landroid/view/View;

    move-result-object v13

    iput-object v13, v12, Lgtandroid/universal/AreaSelectorService;->bottomLeftHandle:Landroid/view/View;

    .line 181
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v3

    move v15, v3

    invoke-direct {v13, v14, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v7, v12

    .line 182
    move-object v12, v7

    move v13, v3

    neg-int v13, v13

    const/4 v14, 0x2

    div-int/lit8 v13, v13, 0x2

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 183
    move-object v12, v7

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    iget v13, v13, Landroid/view/ViewGroup$LayoutParams;->height:I

    move v14, v3

    const/4 v15, 0x2

    div-int/lit8 v14, v14, 0x2

    sub-int/2addr v13, v14

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 184
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomLeftHandle:Landroid/view/View;

    move-object v14, v7

    invoke-virtual {v12, v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 186
    move-object v12, v1

    move-object v13, v1

    move v14, v4

    move v15, v3

    const/16 v16, 0x7

    invoke-direct/range {v13 .. v16}, Lgtandroid/universal/AreaSelectorService;->createHandleView(III)Landroid/view/View;

    move-result-object v13

    iput-object v13, v12, Lgtandroid/universal/AreaSelectorService;->bottomRightHandle:Landroid/view/View;

    .line 187
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move v14, v3

    move v15, v3

    invoke-direct {v13, v14, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v8, v12

    .line 188
    move-object v12, v8

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    iget v13, v13, Landroid/view/ViewGroup$LayoutParams;->width:I

    move v14, v3

    const/4 v15, 0x2

    div-int/lit8 v14, v14, 0x2

    sub-int/2addr v13, v14

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 189
    move-object v12, v8

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    iget v13, v13, Landroid/view/ViewGroup$LayoutParams;->height:I

    move v14, v3

    const/4 v15, 0x2

    div-int/lit8 v14, v14, 0x2

    sub-int/2addr v13, v14

    iput v13, v12, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 190
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomRightHandle:Landroid/view/View;

    move-object v14, v8

    invoke-virtual {v12, v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 192
    new-instance v12, Landroid/view/View;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move-object v14, v1

    invoke-direct {v13, v14}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v9, v12

    .line 193
    move-object v12, v9

    const v13, 0xffffff

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 194
    move-object v12, v9

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/view/View;->setClickable(Z)V

    .line 195
    move-object v12, v9

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/view/View;->setFocusable(Z)V

    .line 196
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    const/4 v14, -0x1

    const/4 v15, -0x1

    invoke-direct {v13, v14, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v10, v12

    .line 200
    move-object v12, v10

    move-object v13, v1

    const/16 v14, 0x14

    int-to-float v14, v14

    invoke-direct {v13, v14}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v13

    move-object v14, v1

    const/16 v15, 0x14

    int-to-float v15, v15

    invoke-direct {v14, v15}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v14

    move-object v15, v1

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v15

    move-object/from16 v16, v1

    const/16 v17, 0x14

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v16

    invoke-virtual/range {v12 .. v16}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 201
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v13, v9

    move-object v14, v10

    invoke-virtual {v12, v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 202
    move-object v12, v9

    new-instance v13, Lgtandroid/universal/AreaSelectorService$100000000;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    move-object v15, v1

    invoke-direct {v14, v15}, Lgtandroid/universal/AreaSelectorService$100000000;-><init>(Lgtandroid/universal/AreaSelectorService;)V

    invoke-virtual {v12, v13}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method private addSizeText()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 335
    move-object v0, p0

    move-object v4, v0

    new-instance v5, Landroid/widget/TextView;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    .line 336
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    const/4 v5, -0x1

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 337
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    const/16 v5, 0x10

    int-to-float v5, v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 338
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    const/high16 v5, -0x34000000    # -3.3554432E7f

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 339
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    move-object v5, v0

    const/16 v6, 0xe

    int-to-float v6, v6

    invoke-direct {v5, v6}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v5

    move-object v6, v0

    const/16 v7, 0x8

    int-to-float v7, v7

    invoke-direct {v6, v7}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v6

    move-object v7, v0

    const/16 v8, 0xe

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0x8

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v8

    invoke-virtual {v4, v5, v6, v7, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 340
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, -0x2

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v2, v4

    .line 344
    move-object v4, v2

    const/16 v5, 0x31

    iput v5, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 345
    move-object v4, v2

    move-object v5, v0

    const/16 v6, 0xa

    int-to-float v6, v6

    invoke-direct {v5, v6}, Lgtandroid/universal/AreaSelectorService;->dpToPx(F)I

    move-result v5

    iput v5, v4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 346
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    move-object v6, v2

    invoke-virtual {v4, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 347
    move-object v4, v0

    invoke-direct {v4}, Lgtandroid/universal/AreaSelectorService;->updateSizeText()V

    return-void
.end method

.method private createHandleView(III)Landroid/view/View;
    .locals 14

    .prologue
    .line 237
    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    new-instance v8, Landroid/view/View;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v5, v8

    .line 238
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v6, v8

    .line 239
    move-object v8, v6

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 240
    move-object v8, v6

    move v9, v1

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 241
    move-object v8, v6

    const/4 v9, 0x3

    const/high16 v10, -0x10000

    invoke-virtual {v8, v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 242
    move-object v8, v5

    move-object v9, v6

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 243
    move-object v8, v5

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/view/View;->setClickable(Z)V

    .line 244
    move-object v8, v5

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/view/View;->setFocusable(Z)V

    .line 246
    move-object v8, v5

    new-instance v9, Lgtandroid/universal/AreaSelectorService$100000001;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    move-object v11, v0

    move v12, v3

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/AreaSelectorService$100000001;-><init>(Lgtandroid/universal/AreaSelectorService;I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 278
    move-object v8, v5

    move-object v0, v8

    return-object v0
.end method

.method private createOverlay()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 87
    move-object v0, p0

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x1a

    if-lt v5, v6, :cond_0

    .line 89
    const/16 v5, 0x7f6

    move v2, v5

    .line 94
    :goto_0
    new-instance v5, Landroid/view/WindowManager$LayoutParams;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    move-result v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v8

    move v9, v2

    const/16 v10, 0x88

    const/4 v11, -0x3

    invoke-direct/range {v6 .. v11}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    move-object v3, v5

    .line 102
    move-object v5, v3

    const v6, 0x800033

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 103
    move-object v5, v3

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v6, v6, Landroid/graphics/Rect;->left:I

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 104
    move-object v5, v3

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v6, v6, Landroid/graphics/Rect;->top:I

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 106
    move-object v5, v0

    new-instance v6, Landroid/widget/FrameLayout;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v6, v5, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    .line 107
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    const v6, 0x4400ff00    # 515.9844f

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 109
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/AreaSelectorService;->createSelectionView()V

    .line 110
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 112
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    move-object v7, v3

    invoke-interface {v5, v6, v7}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void

    .line 91
    :cond_0
    const/16 v5, 0x7d2

    move v2, v5

    goto :goto_0
.end method

.method private createSelectionView()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 116
    move-object v0, p0

    move-object v2, v0

    new-instance v3, Landroid/widget/FrameLayout;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    move-object v5, v0

    invoke-direct {v4, v5}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v2, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    .line 117
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    const/4 v5, -0x1

    const/4 v6, -0x1

    invoke-direct {v4, v5, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 122
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/AreaSelectorService;->addBorders()V

    .line 123
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/AreaSelectorService;->addHandles()V

    .line 124
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/AreaSelectorService;->addControls()V

    .line 125
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/AreaSelectorService;->addSizeText()V

    return-void
.end method

.method private dpToPx(F)I
    .locals 6

    .prologue
    .line 487
    move-object v0, p0

    move v1, p1

    const/4 v3, 0x1

    move v4, v1

    move-object v5, v0

    invoke-virtual {v5}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    invoke-static {v3, v4, v5}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v3

    float-to-int v3, v3

    move v0, v3

    return v0
.end method

.method private handleDrag(FF)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FF)V"
        }
    .end annotation

    .prologue
    .line 351
    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    move v4, v9

    .line 352
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->top:I

    move v5, v9

    .line 353
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->right:I

    move v6, v9

    .line 354
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    move v7, v9

    .line 356
    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/AreaSelectorService;->dragHandle:I

    packed-switch v9, :pswitch_data_0

    .line 389
    :goto_0
    return-void

    .line 358
    :pswitch_0
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v4, v9

    .line 359
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->top:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v5, v9

    .line 360
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->right:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v6, v9

    .line 361
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v7, v9

    .line 383
    :goto_1
    const/4 v9, 0x0

    move v10, v4

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/AreaSelectorService;->screenWidth:I

    const/16 v12, 0x50

    add-int/lit8 v11, v11, -0x50

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v4, v9

    .line 384
    const/4 v9, 0x0

    move v10, v5

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/AreaSelectorService;->screenHeight:I

    const/16 v12, 0x50

    add-int/lit8 v11, v11, -0x50

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v5, v9

    .line 385
    move v9, v4

    const/16 v10, 0x50

    add-int/lit8 v9, v9, 0x50

    move v10, v6

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/AreaSelectorService;->screenWidth:I

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v6, v9

    .line 386
    move v9, v5

    const/16 v10, 0x50

    add-int/lit8 v9, v9, 0x50

    move v10, v7

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/AreaSelectorService;->screenHeight:I

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v7, v9

    .line 388
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    move v10, v4

    move v11, v5

    move v12, v6

    move v13, v7

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/graphics/Rect;->set(IIII)V

    .line 389
    move-object v9, v0

    invoke-direct {v9}, Lgtandroid/universal/AreaSelectorService;->updateSelectionView()V

    goto :goto_0

    .line 364
    :pswitch_1
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v4, v9

    .line 365
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->top:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v5, v9

    .line 366
    goto :goto_1

    .line 368
    :pswitch_2
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->right:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v6, v9

    .line 369
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->top:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v5, v9

    .line 370
    goto :goto_1

    .line 372
    :pswitch_3
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v4, v9

    .line 373
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v7, v9

    .line 374
    goto/16 :goto_1

    .line 376
    :pswitch_4
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->right:I

    int-to-float v9, v9

    move v10, v1

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v6, v9

    .line 377
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->startRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    move v10, v2

    add-float/2addr v9, v10

    float-to-int v9, v9

    move v7, v9

    .line 378
    goto/16 :goto_1

    .line 356
    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_0
    .end packed-switch
.end method

.method private saveAndStartTracking()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 459
    move-object v0, p0

    move-object v4, v0

    invoke-direct {v4}, Lgtandroid/universal/AreaSelectorService;->saveAreaToPrefs()V

    .line 460
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "tracking_enabled"

    const/4 v6, 0x1

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 461
    move-object v4, v0

    const-string v5, "\u2705 \u041e\u0431\u043b\u0430\u0441\u0442\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0430! \u041e\u0442\u0441\u043b\u0435\u0436\u0438\u0432\u0430\u043d\u0438\u0435 \u0437\u0430\u043f\u0443\u0449\u0435\u043d\u043e"

    const/4 v6, 0x1

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 463
    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "AREA_SELECTED"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 464
    move-object v4, v2

    const-string v5, "x"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v6, v6, Landroid/graphics/Rect;->left:I

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v4

    .line 465
    move-object v4, v2

    const-string v5, "y"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v6, v6, Landroid/graphics/Rect;->top:I

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v4

    .line 466
    move-object v4, v2

    const-string v5, "width"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->width()I

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v4

    .line 467
    move-object v4, v2

    const-string v5, "height"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v4

    .line 468
    move-object v4, v0

    move-object v5, v2

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    .line 470
    move-object v4, v0

    invoke-virtual {v4}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method private saveAreaToPrefs()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 450
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "area_x"

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->left:I

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "area_y"

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->top:I

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "area_width"

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "area_height"

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->height()I

    move-result v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private startUpdate()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 474
    move-object v0, p0

    move-object v2, v0

    new-instance v3, Lgtandroid/universal/AreaSelectorService$100000004;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/AreaSelectorService$100000004;-><init>(Lgtandroid/universal/AreaSelectorService;)V

    iput-object v3, v2, Lgtandroid/universal/AreaSelectorService;->updateRunnable:Ljava/lang/Runnable;

    .line 483
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/AreaSelectorService;->handler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService;->updateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v2

    return-void
.end method

.method private updateSelectionView()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 393
    move-object/from16 v0, p0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/view/WindowManager$LayoutParams;

    move-object v2, v13

    .line 394
    move-object v13, v2

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v14, v14, Landroid/graphics/Rect;->left:I

    iput v14, v13, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 395
    move-object v13, v2

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    iget v14, v14, Landroid/graphics/Rect;->top:I

    iput v14, v13, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 396
    move-object v13, v2

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 397
    move-object v13, v2

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 398
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    move-object v15, v2

    invoke-interface {v13, v14, v15}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 400
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topBorder:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v3, v13

    .line 401
    move-object v13, v3

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 402
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topBorder:Landroid/view/View;

    move-object v14, v3

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 404
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomBorder:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v4, v13

    .line 405
    move-object v13, v4

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 406
    move-object v13, v4

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    const/4 v15, 0x4

    add-int/lit8 v14, v14, -0x4

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 407
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomBorder:Landroid/view/View;

    move-object v14, v4

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 409
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->leftBorder:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v5, v13

    .line 410
    move-object v13, v5

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 411
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->leftBorder:Landroid/view/View;

    move-object v14, v5

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 413
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->rightBorder:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v6, v13

    .line 414
    move-object v13, v6

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    iput v14, v13, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 415
    move-object v13, v6

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    const/4 v15, 0x4

    add-int/lit8 v14, v14, -0x4

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 416
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->rightBorder:Landroid/view/View;

    move-object v14, v6

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 418
    const/16 v13, 0x32

    move v7, v13

    .line 419
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topLeftHandle:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v8, v13

    .line 420
    move-object v13, v8

    move v14, v7

    neg-int v14, v14

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 421
    move-object v13, v8

    move v14, v7

    neg-int v14, v14

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 422
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topLeftHandle:Landroid/view/View;

    move-object v14, v8

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 424
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topRightHandle:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v9, v13

    .line 425
    move-object v13, v9

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    move v15, v7

    sub-int/2addr v14, v15

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 426
    move-object v13, v9

    move v14, v7

    neg-int v14, v14

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 427
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->topRightHandle:Landroid/view/View;

    move-object v14, v9

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 429
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomLeftHandle:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v10, v13

    .line 430
    move-object v13, v10

    move v14, v7

    neg-int v14, v14

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 431
    move-object v13, v10

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    move v15, v7

    sub-int/2addr v14, v15

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 432
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomLeftHandle:Landroid/view/View;

    move-object v14, v10

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 434
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomRightHandle:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroid/widget/FrameLayout$LayoutParams;

    move-object v11, v13

    .line 435
    move-object v13, v11

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v14

    move v15, v7

    sub-int/2addr v14, v15

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 436
    move-object v13, v11

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v14

    move v15, v7

    sub-int/2addr v14, v15

    iput v14, v13, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 437
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->bottomRightHandle:Landroid/view/View;

    move-object v14, v11

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 439
    move-object v13, v0

    invoke-direct {v13}, Lgtandroid/universal/AreaSelectorService;->updateSizeText()V

    .line 440
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/AreaSelectorService;->selectionView:Landroid/widget/FrameLayout;

    invoke-virtual {v13}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method private updateSizeText()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 444
    move-object v0, p0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    move v2, v5

    .line 445
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v5

    move v3, v5

    .line 446
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->tvSize:Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\ud83d\udcd0 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move v9, v2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "x"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move v7, v3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 4
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 57
    move-object v0, p0

    move-object v1, p1

    const/4 v3, 0x0

    check-cast v3, Landroid/os/IBinder;

    move-object v0, v3

    return-object v0
.end method

.method public onCreate()V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 62
    move-object v0, p0

    move-object v7, v0

    invoke-super {v7}, Landroid/app/Service;->onCreate()V

    .line 63
    move-object v7, v0

    const-string v8, "AreaSelectorService"

    invoke-static {v7, v8}, Lgtandroid/universal/AppLogger;->installCrashHandler(Landroid/content/Context;Ljava/lang/String;)V

    .line 64
    move-object v7, v0

    move-object v8, v0

    const-string v9, "GTAndroidData"

    const/4 v10, 0x0

    invoke-virtual {v8, v9, v10}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v8

    iput-object v8, v7, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    .line 65
    move-object v7, v0

    move-object v8, v0

    const-string v9, "window"

    invoke-virtual {v8, v9}, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/view/WindowManager;

    iput-object v8, v7, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    .line 67
    move-object v7, v0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v8}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/Display;->getWidth()I

    move-result v8

    iput v8, v7, Lgtandroid/universal/AreaSelectorService;->screenWidth:I

    .line 68
    move-object v7, v0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v8}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/Display;->getHeight()I

    move-result v8

    iput v8, v7, Lgtandroid/universal/AreaSelectorService;->screenHeight:I

    .line 70
    const/16 v7, 0x168

    move v2, v7

    .line 71
    const/16 v7, 0x1e0

    move v3, v7

    .line 72
    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/AreaSelectorService;->screenWidth:I

    move v8, v2

    sub-int/2addr v7, v8

    const/4 v8, 0x2

    div-int/lit8 v7, v7, 0x2

    move v4, v7

    .line 73
    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/AreaSelectorService;->screenHeight:I

    move v8, v3

    sub-int/2addr v7, v8

    const/4 v8, 0x2

    div-int/lit8 v7, v7, 0x2

    move v5, v7

    .line 75
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/AreaSelectorService;->selectionRect:Landroid/graphics/Rect;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v9, "area_x"

    move v10, v4

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "area_y"

    move v11, v5

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v9

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "area_x"

    move v12, v4

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v10

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "area_width"

    move v13, v2

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v11

    add-int/2addr v10, v11

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "area_y"

    move v13, v5

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v11

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/AreaSelectorService;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "area_height"

    move v14, v3

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v12

    add-int/2addr v11, v12

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Rect;->set(IIII)V

    .line 82
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/AreaSelectorService;->createOverlay()V

    .line 83
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/AreaSelectorService;->startUpdate()V

    return-void
.end method

.method public onDestroy()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 495
    move-object v0, p0

    move-object v4, v0

    invoke-super {v4}, Landroid/app/Service;->onDestroy()V

    .line 496
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->updateRunnable:Ljava/lang/Runnable;

    if-eqz v4, :cond_0

    .line 497
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->handler:Landroid/os/Handler;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->updateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 499
    :cond_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    if-eqz v4, :cond_1

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    if-eqz v4, :cond_1

    .line 501
    move-object v4, v0

    :try_start_0
    iget-object v4, v4, Lgtandroid/universal/AreaSelectorService;->windowManager:Landroid/view/WindowManager;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/AreaSelectorService;->overlayView:Landroid/widget/FrameLayout;

    invoke-interface {v4, v5}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :goto_0
    return-void

    :catch_0
    move-exception v4

    move-object v2, v4

    goto :goto_0
.end method
