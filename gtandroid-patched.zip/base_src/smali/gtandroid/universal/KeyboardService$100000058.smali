.class Lgtandroid/universal/KeyboardService$100000058;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000058"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000058$100000057;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000058;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000058;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000058;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2605
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000058;->this$0:Lgtandroid/universal/KeyboardService;

    const-string v4, "\u0422\u041f \u0422\u0421 \u041a \u0421\u0415\u0411\u0415"

    const-string v5, "ID \u0442\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u0430"

    new-instance v6, Lgtandroid/universal/KeyboardService$100000058$100000057;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/KeyboardService$100000058$100000057;-><init>(Lgtandroid/universal/KeyboardService$100000058;)V

    invoke-static {v3, v4, v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000222(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Lgtandroid/universal/KeyboardService$CommandCallback;)V

    return-void
.end method
