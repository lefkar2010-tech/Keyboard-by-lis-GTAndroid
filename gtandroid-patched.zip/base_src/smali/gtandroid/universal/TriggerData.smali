.class public final Lgtandroid/universal/TriggerData;
.super Ljava/lang/Object;
.source "TriggerData.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/TriggerData$Trigger;
    }
.end annotation


# static fields
.field public static final ANS_QUEUE_KEY:Ljava/lang/String; = "a_followup_queue"

.field public static final FILE_NAME:Ljava/lang/String; = "triggers.cfg"

.field public static final FOLLOW_QUEUE_KEY:Ljava/lang/String; = "trigger_follow_queue"

.field public static final PENDING_KEY:Ljava/lang/String; = "trigger_pending"

.field public static final PREF_KEY:Ljava/lang/String; = "trigger_words"


# direct methods
.method constructor <init>()V
    .locals 3

    .prologue
    .line 14
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static clearPending(Landroid/content/SharedPreferences;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            ")V"
        }
    .end annotation

    .prologue
    .line 174
    move-object v0, p0

    move-object v3, v0

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "trigger_pending"

    invoke-interface {v3, v4}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static exists(Landroid/content/SharedPreferences;Ljava/lang/String;)Z
    .locals 6

    .prologue
    .line 127
    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    invoke-static {v4}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v4

    move-object v5, v1

    invoke-static {v4, v5}, Lgtandroid/universal/TriggerData;->findAny(Ljava/util/List;Ljava/lang/String;)Lgtandroid/universal/TriggerData$Trigger;

    move-result-object v4

    if-nez v4, :cond_0

    const/4 v4, 0x0

    :goto_0
    move v0, v4

    return v0

    :cond_0
    const/4 v4, 0x1

    goto :goto_0
.end method

.method public static find(Ljava/util/List;Ljava/lang/String;)Lgtandroid/universal/TriggerData$Trigger;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lgtandroid/universal/TriggerData$Trigger;"
        }
    .end annotation

    .prologue
    .line 109
    move-object v0, p0

    move-object v1, p1

    move-object v8, v1

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v3, v8

    .line 110
    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x0

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v0, v8

    .line 114
    :goto_0
    return-object v0

    .line 111
    :cond_0
    move-object v8, v0

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v4, v8

    .line 112
    :cond_1
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_2

    .line 114
    const/4 v8, 0x0

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v0, v8

    goto :goto_0

    .line 111
    :cond_2
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v6, v8

    .line 112
    move-object v8, v6

    iget-boolean v8, v8, Lgtandroid/universal/TriggerData$Trigger;->enabled:Z

    if-eqz v8, :cond_1

    move-object v8, v6

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v9, v3

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    move-object v8, v6

    move-object v0, v8

    goto :goto_0
.end method

.method public static findAny(Ljava/util/List;Ljava/lang/String;)Lgtandroid/universal/TriggerData$Trigger;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Lgtandroid/universal/TriggerData$Trigger;"
        }
    .end annotation

    .prologue
    .line 118
    move-object v0, p0

    move-object v1, p1

    move-object v8, v1

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v3, v8

    .line 119
    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x0

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v0, v8

    .line 123
    :goto_0
    return-object v0

    .line 120
    :cond_0
    move-object v8, v0

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v4, v8

    .line 121
    :cond_1
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_2

    .line 123
    const/4 v8, 0x0

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v0, v8

    goto :goto_0

    .line 120
    :cond_2
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v6, v8

    .line 121
    move-object v8, v6

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v9, v3

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    move-object v8, v6

    move-object v0, v8

    goto :goto_0
.end method

.method public static getPending(Landroid/content/SharedPreferences;)[Ljava/lang/String;
    .locals 11

    .prologue
    .line 165
    move-object v0, p0

    move-object v5, v0

    if-nez v5, :cond_0

    const/4 v5, 0x0

    check-cast v5, [Ljava/lang/String;

    move-object v0, v5

    .line 170
    :goto_0
    return-object v0

    .line 166
    :cond_0
    move-object v5, v0

    const-string v6, "trigger_pending"

    const-string v7, ""

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v2, v5

    .line 167
    move-object v5, v2

    if-eqz v5, :cond_1

    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_2

    :cond_1
    const/4 v5, 0x0

    check-cast v5, [Ljava/lang/String;

    move-object v0, v5

    goto :goto_0

    .line 168
    :cond_2
    move-object v5, v2

    const-string v6, "\n"

    const/4 v7, 0x3

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 169
    move-object v5, v3

    array-length v5, v5

    const/4 v6, 0x2

    if-ge v5, v6, :cond_3

    const/4 v5, 0x0

    check-cast v5, [Ljava/lang/String;

    move-object v0, v5

    goto :goto_0

    .line 170
    :cond_3
    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/String;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const/4 v7, 0x0

    move-object v8, v3

    const/4 v9, 0x0

    aget-object v8, v8, v9

    aput-object v8, v6, v7

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const/4 v7, 0x1

    move-object v8, v3

    const/4 v9, 0x1

    aget-object v8, v8, v9

    aput-object v8, v6, v7

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const/4 v7, 0x2

    move-object v8, v3

    array-length v8, v8

    const/4 v9, 0x2

    if-le v8, v9, :cond_4

    move-object v8, v3

    const/4 v9, 0x2

    aget-object v8, v8, v9

    :goto_1
    aput-object v8, v6, v7

    move-object v0, v5

    goto :goto_0

    :cond_4
    const-string v8, ""

    goto :goto_1
.end method

.method public static hasAny(Landroid/content/SharedPreferences;)Z
    .locals 7

    .prologue
    .line 103
    move-object v0, p0

    move-object v4, v0

    if-nez v4, :cond_0

    const/4 v4, 0x0

    move v0, v4

    .line 105
    :goto_0
    return v0

    .line 104
    :cond_0
    move-object v4, v0

    const-string v5, "trigger_words"

    const-string v6, "[]"

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v2, v4

    .line 105
    move-object v4, v2

    if-eqz v4, :cond_1

    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x2

    if-gt v4, v5, :cond_2

    :cond_1
    const/4 v4, 0x0

    :goto_1
    move v0, v4

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    goto :goto_1
.end method

.method public static load(Landroid/content/SharedPreferences;)Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            ")",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;"
        }
    .end annotation

    .prologue
    .line 94
    move-object v0, p0

    move-object v3, v0

    if-nez v3, :cond_0

    new-instance v3, Ljava/util/ArrayList;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    move-object v0, v3

    .line 95
    :goto_0
    return-object v0

    :cond_0
    move-object v3, v0

    const-string v4, "trigger_words"

    const-string v5, "[]"

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lgtandroid/universal/TriggerData;->parseJson(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    move-object v0, v3

    goto :goto_0
.end method

.method public static norm(Ljava/lang/String;)Ljava/lang/String;
    .locals 12

    .prologue
    .line 37
    move-object v0, p0

    move-object v8, v0

    if-nez v8, :cond_0

    const-string v8, ""

    move-object v0, v8

    .line 51
    :goto_0
    return-object v0

    .line 38
    :cond_0
    move-object v8, v0

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    const/16 v9, 0x451

    const/16 v10, 0x435

    invoke-virtual {v8, v9, v10}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v8

    move-object v2, v8

    .line 39
    new-instance v8, Ljava/lang/StringBuilder;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    move-object v10, v2

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(I)V

    move-object v3, v8

    .line 40
    const/4 v8, 0x1

    move v4, v8

    .line 41
    const/4 v8, 0x0

    move v5, v8

    :goto_1
    move v8, v5

    move-object v9, v2

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    if-lt v8, v9, :cond_1

    .line 51
    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v0, v8

    goto :goto_0

    .line 42
    :cond_1
    move-object v8, v2

    move v9, v5

    invoke-virtual {v8, v9}, Ljava/lang/String;->charAt(I)C

    move-result v8

    move v6, v8

    .line 43
    move v8, v6

    invoke-static {v8}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v8

    if-eqz v8, :cond_3

    .line 44
    move-object v8, v3

    move v9, v6

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 45
    const/4 v8, 0x0

    move v4, v8

    .line 41
    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 46
    :cond_3
    move v8, v4

    if-nez v8, :cond_2

    .line 47
    move-object v8, v3

    const/16 v9, 0x20

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 48
    const/4 v8, 0x1

    move v4, v8

    goto :goto_2
.end method

.method public static parseJson(Ljava/lang/String;)Ljava/util/List;
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;"
        }
    .end annotation

    .prologue
    .line 55
    move-object/from16 v0, p0

    new-instance v9, Ljava/util/ArrayList;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v9

    .line 56
    move-object v9, v0

    if-nez v9, :cond_0

    move-object v9, v2

    move-object v0, v9

    .line 72
    :goto_0
    return-object v0

    .line 58
    :cond_0
    :try_start_0
    new-instance v9, Lorg/json/JSONArray;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v0

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    invoke-direct {v10, v11}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v9

    .line 59
    const/4 v9, 0x0

    move v4, v9

    :goto_1
    move v9, v4

    move-object v10, v3

    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-lt v9, v10, :cond_1

    .line 72
    :goto_2
    move-object v9, v2

    move-object v0, v9

    goto :goto_0

    .line 60
    :cond_1
    move-object v9, v3

    move v10, v4

    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    move-object v5, v9

    .line 61
    move-object v9, v5

    if-nez v9, :cond_2

    .line 59
    :goto_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 62
    :cond_2
    move-object v9, v5

    const-string v10, "word"

    const-string v11, ""

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    move-object v6, v9

    .line 63
    move-object v9, v6

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_3

    goto :goto_3

    .line 64
    :cond_3
    new-instance v9, Lgtandroid/universal/TriggerData$Trigger;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v6

    move-object v12, v5

    const-string v13, "follow"

    const/4 v14, 0x0

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v12

    move-object v13, v5

    const-string v14, "answerName"

    const-string v15, ""

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object v14, v5

    const-string v15, "answerText"

    const-string v16, ""

    invoke-virtual/range {v14 .. v16}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-direct {v10, v11, v12, v13, v14}, Lgtandroid/universal/TriggerData$Trigger;-><init>(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V

    move-object v7, v9

    .line 66
    move-object v9, v7

    move-object v10, v5

    const-string v11, "enabled"

    const/4 v12, 0x1

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v9, Lgtandroid/universal/TriggerData$Trigger;->enabled:Z

    .line 67
    move-object v9, v2

    move-object v10, v7

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v9

    goto :goto_3

    .line 59
    :catch_0
    move-exception v9

    move-object v3, v9

    goto :goto_2
.end method

.method public static popFollow(Landroid/content/SharedPreferences;)Ljava/lang/String;
    .locals 13

    .prologue
    .line 221
    move-object v0, p0

    :try_start_0
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    const-string v10, "trigger_follow_queue"

    const-string v11, "[]"

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v2, v7

    .line 222
    move-object v7, v2

    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v7

    const/4 v8, 0x0

    if-ne v7, v8, :cond_0

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    .line 229
    :goto_0
    return-object v0

    .line 223
    :cond_0
    move-object v7, v2

    const/4 v8, 0x0

    const-string v9, ""

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v3, v7

    .line 224
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Lorg/json/JSONArray;-><init>()V

    move-object v4, v7

    .line 225
    const/4 v7, 0x1

    move v5, v7

    :goto_1
    move v7, v5

    move-object v8, v2

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-lt v7, v8, :cond_1

    .line 226
    move-object v7, v0

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "trigger_follow_queue"

    move-object v9, v4

    invoke-virtual {v9}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 227
    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_2

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    :goto_2
    move-object v0, v7

    goto :goto_0

    .line 225
    :cond_1
    move-object v7, v4

    move-object v8, v2

    move v9, v5

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v7

    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 227
    :cond_2
    move-object v7, v3

    goto :goto_2

    :catch_0
    move-exception v7

    move-object v2, v7

    .line 229
    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0
.end method

.method public static popQueue(Landroid/content/SharedPreferences;Ljava/lang/String;)Ljava/lang/String;
    .locals 14

    .prologue
    .line 194
    move-object v0, p0

    move-object v1, p1

    :try_start_0
    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    move-object v10, v0

    move-object v11, v1

    const-string v12, "[]"

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v8

    .line 195
    move-object v8, v3

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    const/4 v9, 0x0

    if-ne v8, v9, :cond_0

    const/4 v8, 0x0

    check-cast v8, Ljava/lang/String;

    move-object v0, v8

    .line 202
    :goto_0
    return-object v0

    .line 196
    :cond_0
    move-object v8, v3

    const/4 v9, 0x0

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v4, v8

    .line 197
    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    move-object v5, v8

    .line 198
    const/4 v8, 0x1

    move v6, v8

    :goto_1
    move v8, v6

    move-object v9, v3

    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-lt v8, v9, :cond_1

    .line 199
    move-object v8, v0

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    move-object v9, v1

    move-object v10, v5

    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 200
    move-object v8, v4

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2

    const/4 v8, 0x0

    check-cast v8, Ljava/lang/String;

    :goto_2
    move-object v0, v8

    goto :goto_0

    .line 198
    :cond_1
    move-object v8, v5

    move-object v9, v3

    move v10, v6

    const-string v11, ""

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v8

    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    .line 200
    :cond_2
    move-object v8, v4

    goto :goto_2

    :catch_0
    move-exception v8

    move-object v3, v8

    .line 202
    const/4 v8, 0x0

    check-cast v8, Ljava/lang/String;

    move-object v0, v8

    goto :goto_0
.end method

.method public static pushFollow(Landroid/content/SharedPreferences;Ljava/lang/String;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 208
    move-object v0, p0

    move-object v1, p1

    :try_start_0
    new-instance v6, Lorg/json/JSONArray;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    const-string v9, "trigger_follow_queue"

    const-string v10, "[]"

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v6

    .line 209
    const/4 v6, 0x0

    move v4, v6

    :goto_0
    move v6, v4

    move-object v7, v3

    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-lt v6, v7, :cond_0

    .line 212
    move-object v6, v3

    move-object v7, v1

    invoke-virtual {v6, v7}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v6

    .line 213
    move-object v6, v0

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "trigger_follow_queue"

    move-object v8, v3

    invoke-virtual {v8}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_1
    return-void

    .line 210
    :cond_0
    move-object v6, v1

    move-object v7, v3

    move v8, v4

    const-string v9, ""

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v6

    if-eqz v6, :cond_1

    goto :goto_1

    .line 209
    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 213
    :catch_0
    move-exception v6

    move-object v3, v6

    goto :goto_1
.end method

.method public static pushQueue(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/String;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 181
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    :try_start_0
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    move-object v10, v1

    const-string v11, "[]"

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v4, v7

    .line 182
    const/4 v7, 0x0

    move v5, v7

    :goto_0
    move v7, v5

    move-object v8, v4

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-lt v7, v8, :cond_0

    .line 185
    move-object v7, v4

    move-object v8, v2

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v7

    .line 186
    move-object v7, v0

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    move-object v8, v1

    move-object v9, v4

    invoke-virtual {v9}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_1
    return-void

    .line 183
    :cond_0
    move-object v7, v2

    move-object v8, v4

    move v9, v5

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_1

    .line 182
    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 186
    :catch_0
    move-exception v7

    move-object v4, v7

    goto :goto_1
.end method

.method public static resolveAnswer(Landroid/content/SharedPreferences;Lgtandroid/universal/TriggerData$Trigger;)Ljava/lang/String;
    .locals 14

    .prologue
    .line 144
    move-object v0, p0

    move-object v1, p1

    :try_start_0
    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    move-object v10, v0

    const-string v11, "quick_answers"

    const-string v12, "[]"

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v8

    .line 145
    const/4 v8, 0x0

    move v4, v8

    :goto_0
    move v8, v4

    move-object v9, v3

    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v9

    if-lt v8, v9, :cond_0

    .line 155
    :goto_1
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;

    if-nez v8, :cond_2

    const-string v8, ""

    :goto_2
    move-object v0, v8

    :goto_3
    return-object v0

    .line 146
    :cond_0
    move-object v8, v3

    move v9, v4

    :try_start_1
    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v8

    move-object v5, v8

    .line 147
    move-object v8, v5

    if-eqz v8, :cond_1

    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    if-eqz v8, :cond_1

    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    move-object v9, v5

    const-string v10, "name"

    const-string v11, ""

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    .line 148
    move-object v8, v5

    const-string v9, "answer"

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v6, v8

    .line 149
    move-object v8, v6

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result v8

    if-nez v8, :cond_1

    move-object v8, v6

    move-object v0, v8

    goto :goto_3

    .line 145
    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :catch_0
    move-exception v8

    move-object v3, v8

    goto :goto_1

    .line 155
    :cond_2
    move-object v8, v1

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;

    goto :goto_2
.end method

.method public static save(Landroid/content/SharedPreferences;Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 99
    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "trigger_words"

    move-object v6, v1

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->toJson(Ljava/util/List;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static setPending(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 161
    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object v6, v0

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "trigger_pending"

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v13, v11

    move-object v11, v13

    move-object v12, v13

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    move-object v12, v1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "\n"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v2

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "\n"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v3

    if-nez v9, :cond_0

    const-string v9, ""

    :goto_0
    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_0
    move-object v9, v3

    goto :goto_0
.end method

.method public static toJson(Ljava/util/List;)Ljava/lang/String;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .prologue
    .line 76
    move-object v0, p0

    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    move-object v2, v8

    .line 78
    move-object v8, v0

    :try_start_0
    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v3, v8

    .line 85
    :goto_0
    move-object v8, v3

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v8

    if-nez v8, :cond_0

    .line 90
    :goto_1
    move-object v8, v2

    invoke-virtual {v8}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v0, v8

    return-object v0

    .line 78
    :cond_0
    move-object v8, v3

    :try_start_1
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v5, v8

    .line 79
    new-instance v8, Lorg/json/JSONObject;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    move-object v6, v8

    .line 80
    move-object v8, v6

    const-string v9, "word"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 81
    move-object v8, v6

    const-string v9, "follow"

    move-object v10, v5

    iget-boolean v10, v10, Lgtandroid/universal/TriggerData$Trigger;->follow:Z

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v8

    .line 82
    move-object v8, v6

    const-string v9, "enabled"

    move-object v10, v5

    iget-boolean v10, v10, Lgtandroid/universal/TriggerData$Trigger;->enabled:Z

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v8

    .line 83
    move-object v8, v6

    const-string v9, "answerName"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    if-nez v10, :cond_1

    const-string v10, ""

    :goto_2
    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 84
    move-object v8, v6

    const-string v9, "answerText"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;

    if-nez v10, :cond_2

    const-string v10, ""

    :goto_3
    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 85
    move-object v8, v2

    move-object v9, v6

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v8

    goto :goto_0

    .line 83
    :cond_1
    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    goto :goto_2

    .line 84
    :cond_2
    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_3

    .line 85
    :catch_0
    move-exception v8

    move-object v3, v8

    goto :goto_1
.end method

.method public static upsert(Ljava/util/List;Lgtandroid/universal/TriggerData$Trigger;)Z
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ">;",
            "Lgtandroid/universal/TriggerData$Trigger;",
            ")Z"
        }
    .end annotation

    .prologue
    .line 131
    move-object v0, p0

    move-object v1, p1

    move-object v6, v1

    iget-object v6, v6, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object v3, v6

    .line 132
    const/4 v6, 0x0

    move v4, v6

    :goto_0
    move v6, v4

    move-object v7, v0

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-lt v6, v7, :cond_0

    .line 138
    move-object v6, v0

    move-object v7, v1

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v6

    .line 139
    const/4 v6, 0x0

    move v0, v6

    :goto_1
    return v0

    .line 133
    :cond_0
    move-object v6, v0

    move v7, v4

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lgtandroid/universal/TriggerData$Trigger;

    iget-object v6, v6, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 134
    move-object v6, v0

    move v7, v4

    move-object v8, v1

    invoke-interface {v6, v7, v8}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 135
    const/4 v6, 0x1

    move v0, v6

    goto :goto_1

    .line 132
    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0
.end method
