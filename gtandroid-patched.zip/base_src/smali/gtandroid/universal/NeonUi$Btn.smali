.class public Lgtandroid/universal/NeonUi$Btn;
.super Landroid/graphics/drawable/StateListDrawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Btn"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 133
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    return-void
.end method
