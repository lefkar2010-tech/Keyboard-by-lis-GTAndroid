.class Lgtandroid/universal/FloatingService$100000012;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000012"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$sizeNames:[Ljava/lang/String;

.field private final val$sizeValue:Landroid/widget/TextView;

.field private final val$sizeValues:[I


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;Landroid/widget/TextView;[Ljava/lang/String;[I)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/FloatingService$100000012;->val$sizeValue:Landroid/widget/TextView;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/FloatingService$100000012;->val$sizeNames:[Ljava/lang/String;

    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/FloatingService$100000012;->val$sizeValues:[I

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000012;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/SeekBar;",
            "IZ)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 808
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService$100000012;->val$sizeValue:Landroid/widget/TextView;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000012;->val$sizeNames:[Ljava/lang/String;

    move v7, v2

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/SeekBar;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/SeekBar;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 816
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000012;->val$sizeValues:[I

    move-object v7, v1

    invoke-virtual {v7}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v7

    aget v6, v6, v7

    invoke-static {v5, v6}, Lgtandroid/universal/FloatingService;->access$S1000016(Lgtandroid/universal/FloatingService;I)V

    .line 817
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v5}, Lgtandroid/universal/FloatingService;->access$L1000013(Lgtandroid/universal/FloatingService;)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v6, "keyboard_size"

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v7}, Lgtandroid/universal/FloatingService;->access$L1000016(Lgtandroid/universal/FloatingService;)I

    move-result v7

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 819
    new-instance v5, Landroid/content/Intent;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    const-string v7, "KEYBOARD_SIZE_CHANGED"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 820
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    .line 821
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService$100000012;->this$0:Lgtandroid/universal/FloatingService;

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "\u0420\u0430\u0437\u043c\u0435\u0440: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService$100000012;->val$sizeNames:[Ljava/lang/String;

    move-object v8, v1

    invoke-virtual {v8}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v8

    aget-object v7, v7, v8

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    return-void
.end method
