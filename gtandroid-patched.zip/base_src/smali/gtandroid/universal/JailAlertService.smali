.class public Lgtandroid/universal/JailAlertService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "JailAlertService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/JailAlertService$100000000;,
        Lgtandroid/universal/JailAlertService$100000001;,
        Lgtandroid/universal/JailAlertService$100000002;,
        Lgtandroid/universal/JailAlertService$100000003;,
        Lgtandroid/universal/JailAlertService$100000004;,
        Lgtandroid/universal/JailAlertService$100000005;,
        Lgtandroid/universal/JailAlertService$100000006;,
        Lgtandroid/universal/JailAlertService$100000007;,
        Lgtandroid/universal/JailAlertService$100000010;,
        Lgtandroid/universal/JailAlertService$100000011;,
        Lgtandroid/universal/JailAlertService$100000009;
    }
.end annotation


# static fields
.field private static final ADM_CHAT_PATTERN:Ljava/util/regex/Pattern;

.field private static final ADM_PREFIX_PATTERN:Ljava/util/regex/Pattern;

.field private static final ANSWER_TOLERANCE_MS:J = 0x5dcL

.field private static final AUTO_FORM_COOLDOWN:J = 0xea60L

.field private static final AUTO_FORM_QUEUE_CAP:I = 0x19

.field private static final AUTO_FORM_TIMEOUT:J = 0x7530L

.field private static final DEBUG:Z = false

.field private static final GAME_LINE_PATTERN:Ljava/util/regex/Pattern;

.field private static final HELP_TIMEOUT:J = 0x7530L

.field private static final HIDE_DURATION:J = 0xea60L

.field private static final IGNORED_NICKS:[Ljava/lang/String;

.field private static final JAIL_PATTERN:Ljava/util/regex/Pattern;

.field private static final LEADING_TIME_PATTERN:Ljava/util/regex/Pattern;

.field private static final LEVEL_2_COMMANDS:[Ljava/lang/String;

.field private static final LEVEL_3_COMMANDS:[Ljava/lang/String;

.field private static final LEVEL_4_COMMANDS:[Ljava/lang/String;

.field private static final NO_INITIALS_COMMANDS:[Ljava/lang/String;

.field private static final PATTERN_CACHE:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/util/regex/Pattern;",
            ">;"
        }
    .end annotation
.end field

.field private static final PREFS_AUTO_FORM_QUEUE:Ljava/lang/String; = "auto_form_queue"

.field private static final PREFS_HANDLED_DATE:Ljava/lang/String; = "handled_reports_date"

.field private static final PREFS_HANDLED_SET:Ljava/lang/String; = "handled_reports_set"

.field private static final PREFS_HOT_PACKAGES:Ljava/lang/String; = "hot_scan_packages"

.field private static final PREFS_SEEN_LINES:Ljava/lang/String; = "seen_chat_lines"

.field private static final REPORT_DEDUP_WINDOW_MS:J = 0x5265c00L

.field private static final REPORT_NODE_PATTERN:Ljava/util/regex/Pattern;

.field private static final SCAN_INTERVAL_COLD_MS:J = 0xbb8L

.field private static final SCAN_INTERVAL_HOT_MS:J = 0x96L

.field private static final SCAN_MAX_NODES:I = 0xfa0

.field private static final SEEN_NO_TIME_WINDOW_MS:J = 0x1d4c0L

.field private static final SEEN_WINDOW_MS:J = 0x52571a0L

.field private static final STANDALONE_NUMBER_PATTERN:Ljava/util/regex/Pattern;

.field private static final TIME_ONLY_PATTERN:Ljava/util/regex/Pattern;

.field public static isRunning:Z


# instance fields
.field private answerCounts:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final answerSeenAt:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private areaHeight:I

.field private areaSelectedReceiver:Landroid/content/BroadcastReceiver;

.field private areaWidth:I

.field private areaX:I

.field private areaY:I

.field private autoFormActionReceiver:Landroid/content/BroadcastReceiver;

.field private autoFormEnabled:Z

.field private autoFormTimeoutHandler:Landroid/os/Handler;

.field private autoFormTimeoutRunnable:Ljava/lang/Runnable;

.field private clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

.field private collectPendingTime:Ljava/lang/String;

.field private currentReports:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/ReportData;",
            ">;"
        }
    .end annotation
.end field

.field private floatingMenuEnabled:Z

.field private handler:Landroid/os/Handler;

.field private helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

.field private helpPlayerEnabled:Z

.field private helpTimeoutHandler:Landroid/os/Handler;

.field private helpTimeoutRunnable:Ljava/lang/Runnable;

.field private hiddenReports:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Lgtandroid/universal/ReportData;",
            ">;"
        }
    .end annotation
.end field

.field private final hotPackages:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private lastAutoFormCommand:Ljava/lang/String;

.field private lastAutoFormTime:J

.field private lastCheckedText:Ljava/lang/String;

.field private lastDetectedText:Ljava/lang/String;

.field private volatile lastScanHot:Z

.field private lastScanStartMs:J

.field private prefs:Landroid/content/SharedPreferences;

.field private removeReportReceiver:Landroid/content/BroadcastReceiver;

.field private scanHandler:Landroid/os/Handler;

.field private final scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final scanRunnable:Ljava/lang/Runnable;

.field private scanThread:Landroid/os/HandlerThread;

.field private final seenLines:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private seenLinesLoaded:Z

.field private trackingEnabled:Z

.field private userLevel:I


# direct methods
.method static final constructor <clinit>()V
    .locals 7

    const/4 v2, 0x0

    sput-boolean v2, Lgtandroid/universal/JailAlertService;->isRunning:Z

    new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    invoke-direct {v3}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v2, Lgtandroid/universal/JailAlertService;->PATTERN_CACHE:Ljava/util/Map;

    const-string v2, "^(?:\\d{1,2}:\\d{2}\\s+)?([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[(\\d+)\\]:\\s*(.*)$"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->REPORT_NODE_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "^\\d{1,2}:\\d{2}$"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->TIME_ONLY_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "^\\d{1,2}:\\d{2}\\s"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->LEADING_TIME_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "(?m)^\\s*(?:\\d{1,2}:\\d{2}\\s*)?(?:[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]|<ADM>)"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->GAME_LINE_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "<ADM>\\s*\\((\\d+)\\)\\s*([^\\[]+)\\[(\\d+)]:\\s*(.+)$"

    const/4 v3, 0x2

    invoke-static {v2, v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->JAIL_PATTERN:Ljava/util/regex/Pattern;

    const/16 v2, 0xc

    new-array v2, v2, [Ljava/lang/String;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    const-string v5, "/jail"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x1

    const-string v5, "/mute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x2

    const-string v5, "/spawn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x3

    const-string v5, "/freeze"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x4

    const-string v5, "/slap"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x5

    const-string v5, "/kick"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x6

    const-string v5, "/unmute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x7

    const-string v5, "/offmute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0x8

    const-string v5, "/offunmute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0x9

    const-string v5, "/offunjail"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0xa

    const-string v5, "/offjail"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0xb

    const-string v5, "/rmute"

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/JailAlertService;->LEVEL_2_COMMANDS:[Ljava/lang/String;

    const/4 v2, 0x7

    new-array v2, v2, [Ljava/lang/String;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    const-string v5, "/ban"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x1

    const-string v5, "/warn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x2

    const-string v5, "/offwarn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x3

    const-string v5, "/unwarn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x4

    const-string v5, "/offunwarn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x5

    const-string v5, "/skick"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x6

    const-string v5, "/uncuff"

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/JailAlertService;->LEVEL_3_COMMANDS:[Ljava/lang/String;

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/String;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    const-string v5, "/unban"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x1

    const-string v5, "/sban"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x2

    const-string v5, "/offban"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x3

    const-string v5, "/rgun"

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/JailAlertService;->LEVEL_4_COMMANDS:[Ljava/lang/String;

    const/16 v2, 0xb

    new-array v2, v2, [Ljava/lang/String;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    const-string v5, "/spawn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x1

    const-string v5, "/freeze"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x2

    const-string v5, "/slap"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x3

    const-string v5, "/unmute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x4

    const-string v5, "/offunmute"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x5

    const-string v5, "/offunjail"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x6

    const-string v5, "/unwarn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x7

    const-string v5, "/offunwarn"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0x8

    const-string v5, "/uncuff"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0x9

    const-string v5, "/unban"

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/16 v4, 0xa

    const-string v5, "/rgun"

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/JailAlertService;->NO_INITIALS_COMMANDS:[Ljava/lang/String;

    const-string v2, "^\\s*(?:(\\d{1,2}:\\d{2})\\s*)?<ADM>"

    const/4 v3, 0x2

    invoke-static {v2, v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->ADM_PREFIX_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "^\\s*(?:(\\d{1,2}:\\d{2})\\s*)?<ADM>\\s*\\((\\d+)\\)\\s*([^\\[\\]]+?)\\s*\\[(\\d+)\\]:\\s*(.+)$"

    const/4 v3, 0x2

    invoke-static {v2, v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->ADM_CHAT_PATTERN:Ljava/util/regex/Pattern;

    const-string v2, "(?<![\\p{L}\\p{N}_])(?<!\\d[.,])(\\d{1,4})(?![\\p{L}\\p{N}_])(?![.,]\\d)"

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lgtandroid/universal/JailAlertService;->STANDALONE_NUMBER_PATTERN:Ljava/util/regex/Pattern;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    const-string v5, "Grnd_Bot"

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/JailAlertService;->IGNORED_NICKS:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 8

    .prologue
    .line 1546
    move-object v1, p0

    move-object v3, v1

    invoke-direct {v3}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    move-object v3, v1

    const-string v4, ""

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->lastDetectedText:Ljava/lang/String;

    move-object v3, v1

    const/4 v4, 0x1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    move-object v3, v1

    const/4 v4, 0x1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    move-object v3, v1

    const/4 v4, 0x0

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    move-object v3, v1

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/JailAlertService;->userLevel:I

    move-object v3, v1

    new-instance v4, Ljava/util/ArrayList;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object v3, v1

    new-instance v4, Ljava/util/ArrayList;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->hiddenReports:Ljava/util/List;

    move-object v3, v1

    const-string v4, ""

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    move-object v3, v1

    const/4 v4, 0x0

    check-cast v4, Ljava/lang/String;

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    move-object v3, v1

    new-instance v4, Ljava/util/HashMap;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->answerCounts:Ljava/util/HashMap;

    move-object v3, v1

    new-instance v4, Ljava/util/HashMap;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object v3, v1

    new-instance v4, Ljava/util/concurrent/atomic/AtomicBoolean;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const/4 v6, 0x0

    invoke-direct {v5, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    move-object v3, v1

    const/4 v4, 0x0

    int-to-long v4, v4

    iput-wide v4, v3, Lgtandroid/universal/JailAlertService;->lastScanStartMs:J

    move-object v3, v1

    const/4 v4, 0x1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->lastScanHot:Z

    move-object v3, v1

    new-instance v4, Ljava/util/HashSet;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->hotPackages:Ljava/util/Set;

    move-object v3, v1

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/JailAlertService;->areaX:I

    move-object v3, v1

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/JailAlertService;->areaY:I

    move-object v3, v1

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/JailAlertService;->areaWidth:I

    move-object v3, v1

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/JailAlertService;->areaHeight:I

    move-object v3, v1

    const/4 v4, 0x0

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    move-object v3, v1

    const/4 v4, 0x0

    int-to-long v4, v4

    iput-wide v4, v3, Lgtandroid/universal/JailAlertService;->lastAutoFormTime:J

    move-object v3, v1

    const-string v4, ""

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->lastAutoFormCommand:Ljava/lang/String;

    move-object v3, v1

    new-instance v4, Landroid/os/Handler;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->autoFormTimeoutHandler:Landroid/os/Handler;

    move-object v3, v1

    new-instance v4, Ljava/util/HashMap;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object v3, v1

    const/4 v4, 0x0

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->seenLinesLoaded:Z

    move-object v3, v1

    new-instance v4, Landroid/os/Handler;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->helpTimeoutHandler:Landroid/os/Handler;

    move-object v3, v1

    new-instance v4, Lgtandroid/universal/JailAlertService$100000009;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    move-object v6, v1

    invoke-direct {v5, v6}, Lgtandroid/universal/JailAlertService$100000009;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v4, v3, Lgtandroid/universal/JailAlertService;->scanRunnable:Ljava/lang/Runnable;

    return-void
.end method

.method static access$1000017(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-static {v4, v5}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000083(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->syncSettingsFromPrefs()V

    return-void
.end method

.method static access$1000087(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->cleanOldRecords()V

    return-void
.end method

.method static access$1000090(Lgtandroid/universal/JailAlertService;Z)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService;->requestScan(Z)V

    return-void
.end method

.method static access$1000094(Lgtandroid/universal/JailAlertService;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/JailAlertService;->onScanResult(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000095(Lgtandroid/universal/JailAlertService;Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/StringBuilder;IIII[I)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object/from16 v7, p7

    move-object v10, v0

    move-object v11, v1

    move-object v12, v2

    move v13, v3

    move v14, v4

    move v15, v5

    move/from16 v16, v6

    move-object/from16 v17, v7

    invoke-direct/range {v10 .. v17}, Lgtandroid/universal/JailAlertService;->collectTextsInArea(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/StringBuilder;IIII[I)V

    return-void
.end method

.method static access$1000096(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->loadAreaSettings()V

    return-void
.end method

.method static access$1000100(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->saveReportsToPrefs()V

    return-void
.end method

.method static access$1000101(Lgtandroid/universal/JailAlertService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v6, v0

    move-object v7, v1

    move-object v8, v2

    move-object v9, v3

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/JailAlertService;->removeReport(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000124(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->clearAutoForm()V

    return-void
.end method

.method static access$1000130(Lgtandroid/universal/JailAlertService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->clearHelpPlayer()V

    return-void
.end method

.method static access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000015(Lgtandroid/universal/JailAlertService;)Ljava/lang/String;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000024(Lgtandroid/universal/JailAlertService;)Ljava/lang/String;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000031()I
    .locals 3

    sget v2, Lgtandroid/universal/JailAlertService;->SCAN_MAX_NODES:I

    move v0, v2

    return v0
.end method

.method static access$L1000035(Lgtandroid/universal/JailAlertService;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000041(Lgtandroid/universal/JailAlertService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/JailAlertService;->areaX:I

    move v0, v3

    return v0
.end method

.method static access$L1000042(Lgtandroid/universal/JailAlertService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/JailAlertService;->areaY:I

    move v0, v3

    return v0
.end method

.method static access$L1000043(Lgtandroid/universal/JailAlertService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/JailAlertService;->areaWidth:I

    move v0, v3

    return v0
.end method

.method static access$L1000044(Lgtandroid/universal/JailAlertService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/JailAlertService;->areaHeight:I

    move v0, v3

    return v0
.end method

.method static access$L1000046(Lgtandroid/universal/JailAlertService;)J
    .locals 5

    move-object v0, p0

    move-object v3, v0

    iget-wide v3, v3, Lgtandroid/universal/JailAlertService;->lastAutoFormTime:J

    move-wide v0, v3

    return-wide v0
.end method

.method static access$L1000047(Lgtandroid/universal/JailAlertService;)Ljava/lang/String;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->lastAutoFormCommand:Ljava/lang/String;

    move-object v0, v3

    return-object v0
.end method

.method static access$S1000000(Lgtandroid/universal/JailAlertService;Landroid/os/Handler;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    return-void
.end method

.method static access$S1000015(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    return-void
.end method

.method static access$S1000024(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    return-void
.end method

.method static access$S1000031(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/JailAlertService;->SCAN_MAX_NODES:I

    return-void
.end method

.method static access$S1000035(Lgtandroid/universal/JailAlertService;Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method static access$S1000041(Lgtandroid/universal/JailAlertService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/JailAlertService;->areaX:I

    return-void
.end method

.method static access$S1000042(Lgtandroid/universal/JailAlertService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/JailAlertService;->areaY:I

    return-void
.end method

.method static access$S1000043(Lgtandroid/universal/JailAlertService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/JailAlertService;->areaWidth:I

    return-void
.end method

.method static access$S1000044(Lgtandroid/universal/JailAlertService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/JailAlertService;->areaHeight:I

    return-void
.end method

.method static access$S1000046(Lgtandroid/universal/JailAlertService;J)V
    .locals 9

    move-object v0, p0

    move-wide v1, p1

    move-object v5, v0

    move-wide v6, v1

    iput-wide v6, v5, Lgtandroid/universal/JailAlertService;->lastAutoFormTime:J

    return-void
.end method

.method static access$S1000047(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->lastAutoFormCommand:Ljava/lang/String;

    return-void
.end method

.method private buildInitials(Ljava/lang/String;)Ljava/lang/String;
    .locals 13

    .prologue
    .line 1257
    move-object v0, p0

    move-object v1, p1

    move-object v9, v1

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    const-string v10, "\\s+"

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    move-object v3, v9

    .line 1258
    move-object v9, v3

    array-length v9, v9

    const/4 v10, 0x0

    if-ne v9, v10, :cond_0

    move-object v9, v1

    move-object v0, v9

    .line 1282
    :goto_0
    return-object v0

    .line 1259
    :cond_0
    move-object v9, v3

    array-length v9, v9

    const/4 v10, 0x1

    if-ne v9, v10, :cond_6

    .line 1260
    move-object v9, v3

    const/4 v10, 0x0

    aget-object v9, v9, v10

    move-object v4, v9

    .line 1261
    move-object v9, v4

    const-string v10, "_"

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_4

    .line 1262
    move-object v9, v4

    const-string v10, "_"

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    move-object v5, v9

    .line 1263
    new-instance v9, Ljava/lang/StringBuilder;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object v6, v9

    .line 1264
    const/4 v9, 0x0

    move v7, v9

    :goto_1
    move v9, v7

    move-object v10, v5

    array-length v10, v10

    if-lt v9, v10, :cond_1

    .line 1273
    move-object v9, v6

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    goto :goto_0

    .line 1265
    :cond_1
    move v9, v7

    const/4 v10, 0x0

    if-ne v9, v10, :cond_3

    .line 1266
    move-object v9, v5

    move v10, v7

    aget-object v9, v9, v10

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v10, 0x0

    if-le v9, v10, :cond_2

    .line 1267
    move-object v9, v6

    move-object v10, v5

    move v11, v7

    aget-object v10, v10, v11

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/String;->charAt(I)C

    move-result v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 1264
    :cond_2
    :goto_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 1270
    :cond_3
    move-object v9, v6

    const-string v10, "."

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    move-object v10, v5

    move v11, v7

    aget-object v10, v10, v11

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    goto :goto_2

    .line 1275
    :cond_4
    move-object v9, v4

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v10, 0x0

    if-le v9, v10, :cond_5

    .line 1276
    move-object v9, v4

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    goto :goto_0

    .line 1278
    :cond_5
    move-object v9, v4

    move-object v0, v9

    goto :goto_0

    .line 1280
    :cond_6
    move-object v9, v3

    const/4 v10, 0x0

    aget-object v9, v9, v10

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 1281
    move-object v9, v3

    move-object v10, v3

    array-length v10, v10

    const/4 v11, 0x1

    add-int/lit8 v10, v10, -0x1

    aget-object v9, v9, v10

    move-object v5, v9

    .line 1282
    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v12, v10

    move-object v10, v12

    move-object v11, v12

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    move-object v11, v4

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "."

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v5

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    goto/16 :goto_0
.end method

.method private checkAutoForms([Ljava/lang/String;Ljava/lang/String;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1152
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v12, :cond_0

    .line 1165
    :goto_0
    return-void

    .line 1154
    :cond_0
    move-object v12, v1

    move-object v4, v12

    const/4 v12, 0x0

    move v5, v12

    .line 1165
    :goto_1
    move v12, v5

    move-object v13, v4

    array-length v13, v13

    if-lt v12, v13, :cond_1

    goto :goto_0

    .line 1154
    :cond_1
    move-object v12, v4

    move v13, v5

    aget-object v12, v12, v13

    move-object v6, v12

    .line 1155
    move-object v12, v6

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    move-object v7, v12

    .line 1156
    sget-object v12, Lgtandroid/universal/JailAlertService;->ADM_PREFIX_PATTERN:Ljava/util/regex/Pattern;

    move-object v13, v7

    invoke-virtual {v12, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v12

    move-object v8, v12

    .line 1157
    move-object v12, v8

    invoke-virtual {v12}, Ljava/util/regex/Matcher;->find()Z

    move-result v12

    if-nez v12, :cond_3

    .line 1165
    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 1158
    :cond_3
    move-object v12, v7

    const-string v13, "/"

    invoke-virtual {v12, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_4

    goto :goto_2

    .line 1160
    :cond_4
    move-object v12, v0

    move-object v13, v7

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->extractCommand(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v9, v12

    .line 1161
    move-object v12, v9

    if-eqz v12, :cond_5

    move-object v12, v0

    move-object v13, v9

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->isCommandAllowed(Ljava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_6

    :cond_5
    goto :goto_2

    .line 1163
    :cond_6
    move-object v12, v8

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    if-nez v12, :cond_7

    const-string v12, ""

    :goto_3
    move-object v10, v12

    .line 1164
    move-object v12, v0

    move-object v13, v7

    move-object v14, v9

    move-object v15, v10

    invoke-direct {v12, v13, v14, v15}, Lgtandroid/universal/JailAlertService;->processLine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_2

    .line 1165
    const-string v12, "AutoReport"

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "\ud83d\udd14 \u041d\u0430\u0439\u0434\u0435\u043d\u0430 \u0430\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v9

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v12, v13}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    .line 1163
    :cond_7
    move-object v12, v8

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    goto :goto_3
.end method

.method private checkGNews([Ljava/lang/String;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1002
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v10, :cond_0

    .line 1020
    :goto_0
    return-void

    .line 1003
    :cond_0
    const/4 v10, 0x0

    move v4, v10

    :goto_1
    move v10, v4

    move-object v11, v2

    array-length v11, v11

    if-lt v10, v11, :cond_1

    goto :goto_0

    .line 1004
    :cond_1
    move-object v10, v2

    move v11, v4

    aget-object v10, v10, v11

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v5, v10

    .line 1005
    move-object v10, v5

    const-string v11, "/acceptgnews"

    invoke-virtual {v10, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_2

    .line 1003
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 1006
    :cond_2
    const-string v10, ""

    move-object v6, v10

    .line 1007
    const-string v10, "^(\\d{1,2}:\\d{2})\\s*"

    invoke-static {v10}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v10

    move-object v11, v5

    invoke-virtual {v10, v11}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    move-object v7, v10

    .line 1008
    move-object v10, v7

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v10

    if-eqz v10, :cond_4

    .line 1009
    move-object v10, v7

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    move-object v6, v10

    .line 1013
    :cond_3
    :goto_3
    move-object v10, v6

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    const/4 v11, 0x0

    if-ne v10, v11, :cond_5

    goto :goto_2

    .line 1010
    :cond_4
    move v10, v4

    const/4 v11, 0x0

    if-le v10, v11, :cond_3

    sget-object v10, Lgtandroid/universal/JailAlertService;->TIME_ONLY_PATTERN:Ljava/util/regex/Pattern;

    move-object v11, v2

    move v12, v4

    const/4 v13, 0x1

    add-int/lit8 v12, v12, -0x1

    aget-object v11, v11, v12

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->matches()Z

    move-result v10

    if-eqz v10, :cond_3

    .line 1011
    move-object v10, v2

    move v11, v4

    const/4 v12, 0x1

    add-int/lit8 v11, v11, -0x1

    aget-object v10, v10, v11

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v6, v10

    goto :goto_3

    .line 1014
    :cond_5
    move-object v10, v1

    const-string v11, "gn"

    move-object v12, v6

    const-string v13, "gn"

    const-string v14, "0"

    const-string v15, ""

    invoke-direct/range {v10 .. v15}, Lgtandroid/universal/JailAlertService;->seenKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object v8, v10

    .line 1015
    move-object v10, v1

    move-object v11, v8

    const/4 v12, 0x1

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/JailAlertService;->isLineSeen(Ljava/lang/String;Z)Z

    move-result v10

    if-eqz v10, :cond_6

    goto :goto_2

    .line 1016
    :cond_6
    move-object v10, v1

    move-object v11, v8

    invoke-direct {v10, v11}, Lgtandroid/universal/JailAlertService;->markLineSeen(Ljava/lang/String;)V

    .line 1017
    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "gnews_pending"

    const/4 v12, 0x1

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "gnews_time"

    move-object v12, v6

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "gnews_ts"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-interface {v10, v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1020
    goto/16 :goto_0
.end method

.method private checkHelpRequests([Ljava/lang/String;)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1391
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v17, v0

    if-nez v17, :cond_0

    .line 1416
    :goto_0
    return-void

    .line 1392
    :cond_0
    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v17, v0

    const-string v18, "help_player_pending"

    const/16 v19, 0x0

    invoke-interface/range {v17 .. v19}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v17

    if-eqz v17, :cond_1

    goto :goto_0

    .line 1393
    :cond_1
    move-object/from16 v17, v2

    invoke-direct/range {v17 .. v17}, Lgtandroid/universal/JailAlertService;->isKeyboardVisible()Z

    move-result v17

    if-nez v17, :cond_2

    goto :goto_0

    .line 1395
    :cond_2
    move-object/from16 v17, v3

    move-object/from16 v5, v17

    const/16 v17, 0x0

    move/from16 v6, v17

    .line 1416
    :goto_1
    move/from16 v17, v6

    move-object/from16 v18, v5

    move-object/from16 v0, v18

    array-length v0, v0

    move/from16 v18, v0

    move/from16 v0, v17

    move/from16 v1, v18

    if-lt v0, v1, :cond_3

    goto :goto_0

    .line 1395
    :cond_3
    move-object/from16 v17, v5

    move/from16 v18, v6

    aget-object v17, v17, v18

    move-object/from16 v7, v17

    .line 1396
    move-object/from16 v17, v7

    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v8, v17

    .line 1397
    sget-object v17, Lgtandroid/universal/JailAlertService;->ADM_CHAT_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v18, v8

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v17

    move-object/from16 v9, v17

    .line 1398
    move-object/from16 v17, v9

    invoke-virtual/range {v17 .. v17}, Ljava/util/regex/Matcher;->find()Z

    move-result v17

    if-nez v17, :cond_4

    .line 1416
    :goto_2
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    .line 1400
    :cond_4
    move-object/from16 v17, v9

    const/16 v18, 0x1

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v17

    if-nez v17, :cond_5

    const-string v17, ""

    :goto_3
    move-object/from16 v10, v17

    .line 1401
    move-object/from16 v17, v9

    const/16 v18, 0x3

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v11, v17

    .line 1402
    move-object/from16 v17, v9

    const/16 v18, 0x4

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v12, v17

    .line 1403
    move-object/from16 v17, v9

    const/16 v18, 0x5

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v13, v17

    .line 1405
    move-object/from16 v17, v2

    move-object/from16 v18, v11

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/JailAlertService;->isIgnoredNick(Ljava/lang/String;)Z

    move-result v17

    if-eqz v17, :cond_6

    goto :goto_2

    .line 1400
    :cond_5
    move-object/from16 v17, v9

    const/16 v18, 0x1

    invoke-virtual/range {v17 .. v18}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v17

    goto :goto_3

    .line 1407
    :cond_6
    move-object/from16 v17, v2

    move-object/from16 v18, v13

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/JailAlertService;->extractHelpPlayerId(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v14, v17

    .line 1408
    move-object/from16 v17, v14

    if-nez v17, :cond_7

    goto :goto_2

    .line 1410
    :cond_7
    move-object/from16 v17, v2

    const-string v18, "help"

    move-object/from16 v19, v10

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    move-object/from16 v22, v13

    invoke-direct/range {v17 .. v22}, Lgtandroid/universal/JailAlertService;->seenKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v15, v17

    .line 1411
    move-object/from16 v17, v2

    move-object/from16 v18, v15

    move-object/from16 v19, v10

    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->length()I

    move-result v19

    const/16 v20, 0x0

    move/from16 v0, v19

    move/from16 v1, v20

    if-gt v0, v1, :cond_8

    const/16 v19, 0x0

    :goto_4
    invoke-direct/range {v17 .. v19}, Lgtandroid/universal/JailAlertService;->isLineSeen(Ljava/lang/String;Z)Z

    move-result v17

    if-eqz v17, :cond_9

    goto/16 :goto_2

    :cond_8
    const/16 v19, 0x1

    goto :goto_4

    .line 1413
    :cond_9
    move-object/from16 v17, v2

    move-object/from16 v18, v15

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/JailAlertService;->markLineSeen(Ljava/lang/String;)V

    .line 1414
    move-object/from16 v17, v2

    move-object/from16 v18, v11

    move-object/from16 v19, v12

    move-object/from16 v20, v14

    move-object/from16 v21, v13

    move-object/from16 v22, v10

    invoke-direct/range {v17 .. v22}, Lgtandroid/universal/JailAlertService;->saveHelpToPrefs(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1415
    const-string v17, "AutoReport"

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v26, v18

    move-object/from16 v18, v26

    move-object/from16 v19, v26

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v22, Ljava/lang/StringBuffer;

    move-object/from16 v26, v22

    move-object/from16 v22, v26

    move-object/from16 v23, v26

    invoke-direct/range {v23 .. v23}, Ljava/lang/StringBuffer;-><init>()V

    const-string v23, "\ud83c\udd98 \u041f\u043e\u043c\u043e\u0449\u044c \u0438\u0433\u0440\u043e\u043a\u0443: "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    move-object/from16 v23, v11

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    const-string v22, "["

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move-object/from16 v21, v12

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    const-string v20, "] -> "

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    move-object/from16 v19, v14

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-static/range {v17 .. v18}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1416
    goto/16 :goto_0
.end method

.method private checkReports([Ljava/lang/String;)V
    .locals 53
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 773
    move-object/from16 v3, p0

    move-object/from16 v4, p1

    new-instance v36, Ljava/util/ArrayList;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v6, v36

    .line 775
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v36

    move-wide/from16 v7, v36

    .line 776
    const/16 v36, 0x0

    move/from16 v9, v36

    .line 777
    new-instance v36, Ljava/util/ArrayList;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v10, v36

    .line 778
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object/from16 v36, v0

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v11, v36

    .line 782
    :goto_0
    move-object/from16 v36, v11

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_8

    .line 785
    move/from16 v36, v9

    if-eqz v36, :cond_0

    move-object/from16 v36, v3

    move-object/from16 v37, v10

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    .line 787
    :cond_0
    new-instance v36, Ljava/util/HashMap;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/util/HashMap;-><init>()V

    move-object/from16 v13, v36

    .line 788
    const/16 v36, 0x0

    move/from16 v14, v36

    :goto_1
    move/from16 v36, v14

    move-object/from16 v37, v4

    move-object/from16 v0, v37

    array-length v0, v0

    move/from16 v37, v0

    move/from16 v0, v36

    move/from16 v1, v37

    if-lt v0, v1, :cond_b

    .line 801
    move-object/from16 v36, v13

    invoke-virtual/range {v36 .. v36}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v36

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v14, v36

    .line 805
    :cond_1
    :goto_2
    move-object/from16 v36, v14

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_f

    .line 808
    move-object/from16 v36, v3

    move-object/from16 v37, v13

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/JailAlertService;->answerCounts:Ljava/util/HashMap;

    .line 809
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    invoke-virtual/range {v36 .. v36}, Ljava/util/HashMap;->size()I

    move-result v36

    const/16 v37, 0x12c

    move/from16 v0, v36

    move/from16 v1, v37

    if-le v0, v1, :cond_3

    .line 810
    new-instance v36, Ljava/util/ArrayList;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v16, v36

    .line 811
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    invoke-virtual/range {v36 .. v36}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v36

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v17, v36

    .line 812
    :cond_2
    :goto_3
    move-object/from16 v36, v17

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_11

    .line 814
    move-object/from16 v36, v16

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v19, v36

    :goto_4
    move-object/from16 v36, v19

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_12

    .line 817
    :cond_3
    const/16 v36, 0x0

    move/from16 v16, v36

    :goto_5
    move/from16 v36, v16

    move-object/from16 v37, v4

    move-object/from16 v0, v37

    array-length v0, v0

    move/from16 v37, v0

    move/from16 v0, v36

    move/from16 v1, v37

    if-lt v0, v1, :cond_13

    .line 937
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v36

    move-wide/from16 v16, v36

    .line 939
    move-object/from16 v36, v6

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v18, v36

    .line 981
    :cond_4
    :goto_6
    move-object/from16 v36, v18

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_2b

    .line 985
    move/from16 v36, v9

    move/from16 v20, v36

    .line 986
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object/from16 v36, v0

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v21, v36

    .line 992
    :cond_5
    :goto_7
    move-object/from16 v36, v21

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_35

    .line 996
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object/from16 v36, v0

    invoke-interface/range {v36 .. v36}, Ljava/util/List;->isEmpty()Z

    move-result v36

    if-eqz v36, :cond_6

    move/from16 v36, v20

    if-eqz v36, :cond_7

    .line 997
    :cond_6
    move-object/from16 v36, v3

    invoke-direct/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->saveReportsToPrefs()V

    :cond_7
    return-void

    .line 778
    :cond_8
    move-object/from16 v36, v11

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Lgtandroid/universal/ReportData;

    move-object/from16 v13, v36

    .line 779
    move-object/from16 v36, v13

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v36, v0

    if-eqz v36, :cond_9

    move-object/from16 v36, v13

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v36, v0

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->length()I

    move-result v36

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-ne v0, v1, :cond_a

    .line 780
    :cond_9
    const/16 v36, 0x1

    move/from16 v9, v36

    goto/16 :goto_0

    .line 782
    :cond_a
    move-object/from16 v36, v10

    move-object/from16 v37, v13

    invoke-interface/range {v36 .. v37}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v36

    goto/16 :goto_0

    .line 789
    :cond_b
    const-string v36, "^\\d{1,2}:\\d{2}\\s*"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v4

    move/from16 v38, v14

    aget-object v37, v37, v38

    invoke-virtual/range {v37 .. v37}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v15, v36

    .line 791
    const-string v36, "^\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\\s+([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[\\d+\\]\\s+\u0434\u043b\u044f\\s+([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[(\\d+)\\]:.*$"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v15

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    move-object/from16 v16, v36

    .line 792
    move-object/from16 v36, v16

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-nez v36, :cond_c

    .line 793
    const-string v36, "^<ADM>\\s+([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[\\d+\\]\\s+\u043e\u0442\u0432\u0435\u0442\u0438\u043b\\s+([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[(\\d+)\\]:.*$"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v15

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    move-object/from16 v16, v36

    .line 794
    move-object/from16 v36, v16

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-nez v36, :cond_c

    .line 788
    :goto_8
    add-int/lit8 v14, v14, 0x1

    goto/16 :goto_1

    .line 796
    :cond_c
    move-object/from16 v36, v3

    move-object/from16 v37, v16

    const/16 v38, 0x1

    invoke-virtual/range {v37 .. v38}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v37

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->isIgnoredNick(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_d

    goto :goto_8

    .line 797
    :cond_d
    new-instance v36, Ljava/lang/StringBuffer;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v52, v38

    move-object/from16 v38, v52

    move-object/from16 v39, v52

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v39, Ljava/lang/StringBuffer;

    move-object/from16 v52, v39

    move-object/from16 v39, v52

    move-object/from16 v40, v52

    invoke-direct/range {v40 .. v40}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v40, v16

    const/16 v41, 0x2

    invoke-virtual/range {v40 .. v41}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v40

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    const-string v40, "|"

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    invoke-virtual/range {v39 .. v39}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v39

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    move-object/from16 v39, v16

    const/16 v40, 0x3

    invoke-virtual/range {v39 .. v40}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v39

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    const-string v38, "\n"

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v36

    move-object/from16 v37, v15

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v17, v36

    .line 798
    move-object/from16 v36, v13

    move-object/from16 v37, v17

    invoke-virtual/range {v36 .. v37}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/Integer;

    move-object/from16 v18, v36

    .line 799
    move-object/from16 v36, v13

    move-object/from16 v37, v17

    move-object/from16 v38, v18

    if-nez v38, :cond_e

    const/16 v38, 0x1

    :goto_9
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v38

    invoke-virtual/range {v36 .. v38}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    goto/16 :goto_8

    :cond_e
    move-object/from16 v38, v18

    invoke-virtual/range {v38 .. v38}, Ljava/lang/Integer;->intValue()I

    move-result v38

    const/16 v39, 0x1

    add-int/lit8 v38, v38, 0x1

    goto :goto_9

    .line 801
    :cond_f
    move-object/from16 v36, v14

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/util/Map$Entry;

    move-object/from16 v16, v36

    .line 802
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerCounts:Ljava/util/HashMap;

    move-object/from16 v36, v0

    move-object/from16 v37, v16

    invoke-interface/range {v37 .. v37}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v37

    check-cast v37, Ljava/lang/String;

    invoke-virtual/range {v36 .. v37}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/Integer;

    move-object/from16 v17, v36

    .line 803
    move-object/from16 v36, v16

    invoke-interface/range {v36 .. v36}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/Integer;

    invoke-virtual/range {v36 .. v36}, Ljava/lang/Integer;->intValue()I

    move-result v36

    move-object/from16 v37, v17

    if-nez v37, :cond_10

    const/16 v37, 0x0

    :goto_a
    move/from16 v0, v36

    move/from16 v1, v37

    if-le v0, v1, :cond_1

    .line 804
    move-object/from16 v36, v16

    invoke-interface/range {v36 .. v36}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/String;

    const/16 v37, 0x0

    move-object/from16 v38, v16

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v38

    check-cast v38, Ljava/lang/String;

    const/16 v39, 0xa

    invoke-virtual/range {v38 .. v39}, Ljava/lang/String;->indexOf(I)I

    move-result v38

    invoke-virtual/range {v36 .. v38}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v36

    move-object/from16 v18, v36

    .line 805
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    move-object/from16 v37, v18

    move-wide/from16 v38, v7

    invoke-static/range {v38 .. v39}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v38

    invoke-virtual/range {v36 .. v38}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    goto/16 :goto_2

    .line 803
    :cond_10
    move-object/from16 v37, v17

    invoke-virtual/range {v37 .. v37}, Ljava/lang/Integer;->intValue()I

    move-result v37

    goto :goto_a

    .line 811
    :cond_11
    move-object/from16 v36, v17

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/util/Map$Entry;

    move-object/from16 v19, v36

    .line 812
    move-wide/from16 v36, v7

    move-object/from16 v38, v19

    invoke-interface/range {v38 .. v38}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v38

    check-cast v38, Ljava/lang/Long;

    invoke-virtual/range {v38 .. v38}, Ljava/lang/Long;->longValue()J

    move-result-wide v38

    sub-long v36, v36, v38

    const-wide/32 v38, 0x36ee80

    cmp-long v36, v36, v38

    if-lez v36, :cond_2

    move-object/from16 v36, v16

    move-object/from16 v37, v19

    invoke-interface/range {v37 .. v37}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v37

    check-cast v37, Ljava/lang/String;

    invoke-interface/range {v36 .. v37}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v36

    goto/16 :goto_3

    .line 814
    :cond_12
    move-object/from16 v36, v19

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/String;

    move-object/from16 v21, v36

    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    move-object/from16 v37, v21

    invoke-virtual/range {v36 .. v37}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    goto/16 :goto_4

    .line 818
    :cond_13
    move-object/from16 v36, v4

    move/from16 v37, v16

    aget-object v36, v36, v37

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v17, v36

    .line 819
    move-object/from16 v36, v17

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->isEmpty()Z

    move-result v36

    if-eqz v36, :cond_15

    .line 817
    :cond_14
    :goto_b
    add-int/lit8 v16, v16, 0x1

    goto/16 :goto_5

    .line 821
    :cond_15
    const-string v36, ""

    move-object/from16 v18, v36

    .line 822
    const-string v36, "^(\\d{1,2}:\\d{2})\\s*"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v17

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    move-object/from16 v19, v36

    .line 823
    move-object/from16 v36, v19

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-eqz v36, :cond_16

    .line 824
    move-object/from16 v36, v19

    const/16 v37, 0x1

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v36

    move-object/from16 v18, v36

    .line 826
    :cond_16
    move-object/from16 v36, v18

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->length()I

    move-result v36

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-ne v0, v1, :cond_17

    move/from16 v36, v16

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-le v0, v1, :cond_17

    .line 827
    move-object/from16 v36, v4

    move/from16 v37, v16

    const/16 v38, 0x1

    add-int/lit8 v37, v37, -0x1

    aget-object v36, v36, v37

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v20, v36

    .line 828
    sget-object v36, Lgtandroid/universal/JailAlertService;->TIME_ONLY_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v37, v20

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->matches()Z

    move-result v36

    if-eqz v36, :cond_17

    move-object/from16 v36, v20

    move-object/from16 v18, v36

    .line 830
    :cond_17
    const-string v36, "^\\d{1,2}:\\d{2}\\s*[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v4

    move/from16 v38, v16

    aget-object v37, v37, v38

    invoke-virtual/range {v37 .. v37}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-nez v36, :cond_18

    const-string v36, "^[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v4

    move/from16 v38, v16

    aget-object v37, v37, v38

    invoke-virtual/range {v37 .. v37}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-nez v36, :cond_18

    const/16 v36, 0x0

    :goto_c
    move/from16 v20, v36

    .line 832
    move/from16 v36, v20

    if-eqz v36, :cond_19

    move-object/from16 v36, v18

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->length()I

    move-result v36

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-ne v0, v1, :cond_19

    .line 833
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    const-string v38, "skip report without time: "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v4

    move/from16 v39, v16

    aget-object v38, v38, v39

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 834
    goto/16 :goto_b

    .line 830
    :cond_18
    const/16 v36, 0x1

    goto :goto_c

    .line 837
    :cond_19
    const-string v36, "^\\d{1,2}:\\d{2}\\s*"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v17

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v17, v36

    .line 839
    move-object/from16 v36, v3

    move-object/from16 v37, v17

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->shouldIgnoreLine(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_1a

    .line 840
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    const-string v38, "\u23ed\ufe0f \u0418\u0433\u043d\u043e\u0440\u0438\u0440\u0443\u0435\u043c \u0441\u0442\u0440\u043e\u043a\u0443: "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v17

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 841
    goto/16 :goto_b

    .line 844
    :cond_1a
    const-string v36, "^([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[(\\d+)\\][\\s:.]*\\s*(.*)$"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v21, v36

    .line 845
    move-object/from16 v36, v21

    move-object/from16 v37, v17

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    move-object/from16 v22, v36

    .line 847
    move-object/from16 v36, v22

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-eqz v36, :cond_14

    .line 848
    move-object/from16 v36, v22

    const/16 v37, 0x1

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v23, v36

    .line 849
    move-object/from16 v36, v22

    const/16 v37, 0x2

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v36

    move-object/from16 v24, v36

    .line 850
    move-object/from16 v36, v22

    const/16 v37, 0x3

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v25, v36

    .line 852
    new-instance v36, Ljava/lang/StringBuilder;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    move-object/from16 v38, v25

    invoke-direct/range {v37 .. v38}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v26, v36

    .line 854
    move/from16 v36, v16

    const/16 v37, 0x1

    add-int/lit8 v36, v36, 0x1

    move/from16 v27, v36

    :goto_d
    move/from16 v36, v27

    move-object/from16 v37, v4

    move-object/from16 v0, v37

    array-length v0, v0

    move/from16 v37, v0

    move/from16 v0, v36

    move/from16 v1, v37

    if-lt v0, v1, :cond_1b

    .line 895
    :goto_e
    move-object/from16 v36, v3

    move-object/from16 v37, v26

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v37

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->cleanReportText(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 897
    const-string v36, "\\[\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430\\s*\\d+\\s*\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 898
    const-string v36, "\\[\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430\\s*\\d+\\s*\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 899
    const-string v36, "\\[\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430:\\s*\\d+\\s*\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 900
    const-string v36, "\\[\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430:\\s*\\d+\\s*\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 902
    const-string v36, "\\s+\\d{1,2}:\\d{2}\\s*$"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 903
    const-string v36, "\\d{1,2}:\\d{2}\\s+\\d{1,2}:\\d{2}"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 904
    const-string v36, "\\s+\\d{1,2}\\.\\d{1,2}\\s*"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, " "

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 906
    const-string v36, "(?i)\u0412\u044b \u0438\u0441\u0442\u043e\u0449\u0435\u043d\u044b!\\s*\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e!"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 907
    const-string v36, "(?i)\u0412\u044b \u0438\u0441\u0442\u043e\u0449\u0435\u043d\u044b!"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 908
    const-string v36, "(?i)\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e!"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 910
    const-string v36, "\\s+"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, " "

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v27, v36

    .line 912
    move-object/from16 v36, v3

    move-object/from16 v37, v18

    move-object/from16 v38, v23

    move-object/from16 v39, v24

    move-object/from16 v40, v27

    invoke-direct/range {v36 .. v40}, Lgtandroid/universal/JailAlertService;->isReportSeen(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_25

    .line 913
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v52, v38

    move-object/from16 v38, v52

    move-object/from16 v39, v52

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v39, Ljava/lang/StringBuffer;

    move-object/from16 v52, v39

    move-object/from16 v39, v52

    move-object/from16 v40, v52

    invoke-direct/range {v40 .. v40}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v40, Ljava/lang/StringBuffer;

    move-object/from16 v52, v40

    move-object/from16 v40, v52

    move-object/from16 v41, v52

    invoke-direct/range {v41 .. v41}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v41, Ljava/lang/StringBuffer;

    move-object/from16 v52, v41

    move-object/from16 v41, v52

    move-object/from16 v42, v52

    invoke-direct/range {v42 .. v42}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v42, Ljava/lang/StringBuffer;

    move-object/from16 v52, v42

    move-object/from16 v42, v52

    move-object/from16 v43, v52

    invoke-direct/range {v43 .. v43}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v43, Ljava/lang/StringBuffer;

    move-object/from16 v52, v43

    move-object/from16 v43, v52

    move-object/from16 v44, v52

    invoke-direct/range {v44 .. v44}, Ljava/lang/StringBuffer;-><init>()V

    const-string v44, "\u23ed\ufe0f \u0423\u0436\u0435 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u0430\u043d\u043e: "

    invoke-virtual/range {v43 .. v44}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v43

    move-object/from16 v44, v18

    invoke-virtual/range {v43 .. v44}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v43

    invoke-virtual/range {v43 .. v43}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v43

    invoke-virtual/range {v42 .. v43}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v42

    const-string v43, " "

    invoke-virtual/range {v42 .. v43}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v42

    invoke-virtual/range {v42 .. v42}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v42

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    move-object/from16 v42, v23

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    invoke-virtual/range {v41 .. v41}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v41

    invoke-virtual/range {v40 .. v41}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v40

    const-string v41, "["

    invoke-virtual/range {v40 .. v41}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v40

    invoke-virtual/range {v40 .. v40}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v40

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    move-object/from16 v40, v24

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    invoke-virtual/range {v39 .. v39}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v39

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    const-string v39, "] "

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v27

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 914
    goto/16 :goto_b

    .line 855
    :cond_1b
    move-object/from16 v36, v4

    move/from16 v37, v27

    aget-object v36, v36, v37

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v28, v36

    .line 856
    move-object/from16 v36, v28

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->isEmpty()Z

    move-result v36

    if-eqz v36, :cond_1c

    .line 854
    :goto_f
    add-int/lit8 v27, v27, 0x1

    goto/16 :goto_d

    .line 858
    :cond_1c
    const-string v36, "^\\d{1,2}:\\d{2}\\s*"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v37, v28

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    const-string v37, ""

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v28, v36

    .line 860
    move-object/from16 v36, v3

    move-object/from16 v37, v28

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->shouldIgnoreLine(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_1d

    .line 861
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    const-string v38, "\u23ed\ufe0f \u0418\u0433\u043d\u043e\u0440\u0438\u0440\u0443\u0435\u043c \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0435\u043d\u0438\u0435: "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v28

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 862
    goto/16 :goto_e

    .line 865
    :cond_1d
    const-string v36, "^([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+)\\[(\\d+)\\]"

    invoke-static/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    move-object/from16 v29, v36

    .line 866
    move-object/from16 v36, v29

    move-object/from16 v37, v28

    invoke-virtual/range {v36 .. v37}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/util/regex/Matcher;->find()Z

    move-result v36

    if-eqz v36, :cond_1e

    .line 867
    goto/16 :goto_e

    .line 870
    :cond_1e
    move-object/from16 v36, v28

    const-string v37, "[\u0410\u0440\u0437\u0430\u043c\u0430\u0441"

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_1f

    .line 871
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    const-string v38, "\u23ed\ufe0f \u041e\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u043c \u0441\u0431\u043e\u0440 (\u0410\u0440\u0437\u0430\u043c\u0430\u0441): "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v28

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 872
    goto/16 :goto_e

    .line 875
    :cond_1f
    const-string v36, "^\\(\\([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+:\\s*.*\\)\\)$"

    move-object/from16 v37, v28

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_20

    .line 876
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    const-string v38, "\u23ed\ufe0f \u041e\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u043c \u0441\u0431\u043e\u0440 (OOC): "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v28

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 877
    goto/16 :goto_e

    .line 880
    :cond_20
    move-object/from16 v36, v28

    const-string v37, "<ADM>"

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_21

    .line 881
    goto/16 :goto_e

    .line 884
    :cond_21
    move-object/from16 v36, v28

    const-string v37, "\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v36

    if-nez v36, :cond_22

    move-object/from16 v36, v28

    const-string v37, "\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v36

    if-eqz v36, :cond_23

    .line 885
    :cond_22
    goto/16 :goto_e

    .line 888
    :cond_23
    move-object/from16 v36, v26

    invoke-virtual/range {v36 .. v36}, Ljava/lang/StringBuilder;->length()I

    move-result v36

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-le v0, v1, :cond_24

    .line 889
    move-object/from16 v36, v26

    const-string v37, " "

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v36

    move-object/from16 v37, v28

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v36

    goto/16 :goto_f

    .line 891
    :cond_24
    move-object/from16 v36, v26

    move-object/from16 v37, v28

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v36

    goto/16 :goto_f

    .line 917
    :cond_25
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v52, v38

    move-object/from16 v38, v52

    move-object/from16 v39, v52

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v39, v23

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    const-string v39, "|"

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v24

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/Long;

    move-object/from16 v28, v36

    .line 918
    move-object/from16 v36, v28

    if-eqz v36, :cond_26

    move-object/from16 v36, v28

    invoke-virtual/range {v36 .. v36}, Ljava/lang/Long;->longValue()J

    move-result-wide v36

    move-wide/from16 v38, v7

    const-wide/16 v40, 0x5dc

    sub-long v38, v38, v40

    cmp-long v36, v36, v38

    if-gez v36, :cond_27

    :cond_26
    const/16 v36, 0x0

    :goto_10
    move/from16 v29, v36

    .line 920
    move/from16 v36, v29

    if-eqz v36, :cond_28

    const-string v36, "\ud83d\udfe2"

    :goto_11
    move-object/from16 v30, v36

    .line 922
    move-object/from16 v36, v18

    if-eqz v36, :cond_29

    move-object/from16 v36, v18

    invoke-virtual/range {v36 .. v36}, Ljava/lang/String;->length()I

    move-result v36

    const/16 v37, 0x0

    move/from16 v0, v36

    move/from16 v1, v37

    if-le v0, v1, :cond_29

    move-object/from16 v36, v18

    :goto_12
    move-object/from16 v31, v36

    .line 923
    new-instance v36, Ljava/lang/StringBuffer;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    invoke-direct/range {v37 .. v37}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v38, v30

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    const-string v38, " "

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v36

    move-object/from16 v37, v31

    invoke-virtual/range {v36 .. v37}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v36

    invoke-virtual/range {v36 .. v36}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v36

    move-object/from16 v32, v36

    .line 925
    move-object/from16 v36, v3

    move-object/from16 v37, v4

    move/from16 v38, v16

    invoke-direct/range {v36 .. v38}, Lgtandroid/universal/JailAlertService;->extractReportCount([Ljava/lang/String;I)I

    move-result v36

    move/from16 v33, v36

    .line 927
    new-instance v36, Lgtandroid/universal/ReportData;

    move-object/from16 v52, v36

    move-object/from16 v36, v52

    move-object/from16 v37, v52

    move-object/from16 v38, v32

    move-object/from16 v39, v23

    move-object/from16 v40, v24

    move-object/from16 v41, v27

    move/from16 v42, v33

    move-object/from16 v43, v17

    invoke-direct/range {v37 .. v43}, Lgtandroid/universal/ReportData;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    move-object/from16 v34, v36

    .line 928
    move-object/from16 v36, v34

    move/from16 v37, v29

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isAnswered:Z

    .line 929
    move-object/from16 v36, v34

    move-wide/from16 v37, v7

    move-wide/from16 v0, v37

    move-object/from16 v2, v36

    iput-wide v0, v2, Lgtandroid/universal/ReportData;->firstSeenMs:J

    .line 930
    move-object/from16 v36, v34

    move-object/from16 v37, v18

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    .line 931
    move-object/from16 v36, v34

    move-object/from16 v37, v3

    move-object/from16 v38, v27

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/JailAlertService;->matchesActiveEvent(Ljava/lang/String;)Z

    move-result v37

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isEvent:Z

    .line 932
    move-object/from16 v36, v6

    move-object/from16 v37, v34

    invoke-interface/range {v36 .. v37}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v36

    .line 933
    const-string v36, "AutoReport"

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v52, v38

    move-object/from16 v38, v52

    move-object/from16 v39, v52

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v39, Ljava/lang/StringBuffer;

    move-object/from16 v52, v39

    move-object/from16 v39, v52

    move-object/from16 v40, v52

    invoke-direct/range {v40 .. v40}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v40, Ljava/lang/StringBuffer;

    move-object/from16 v52, v40

    move-object/from16 v40, v52

    move-object/from16 v41, v52

    invoke-direct/range {v41 .. v41}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v41, Ljava/lang/StringBuffer;

    move-object/from16 v52, v41

    move-object/from16 v41, v52

    move-object/from16 v42, v52

    invoke-direct/range {v42 .. v42}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v42, Ljava/lang/StringBuffer;

    move-object/from16 v52, v42

    move-object/from16 v42, v52

    move-object/from16 v43, v52

    invoke-direct/range {v43 .. v43}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v43, Ljava/lang/StringBuffer;

    move-object/from16 v52, v43

    move-object/from16 v43, v52

    move-object/from16 v44, v52

    invoke-direct/range {v44 .. v44}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v44, Ljava/lang/StringBuffer;

    move-object/from16 v52, v44

    move-object/from16 v44, v52

    move-object/from16 v45, v52

    invoke-direct/range {v45 .. v45}, Ljava/lang/StringBuffer;-><init>()V

    const-string v45, "\u2705 \u041d\u0430\u0439\u0434\u0435\u043d \u0440\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual/range {v44 .. v45}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v44

    move-object/from16 v45, v23

    invoke-virtual/range {v44 .. v45}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v44

    invoke-virtual/range {v44 .. v44}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v44

    invoke-virtual/range {v43 .. v44}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v43

    const-string v44, "["

    invoke-virtual/range {v43 .. v44}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v43

    invoke-virtual/range {v43 .. v43}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v43

    invoke-virtual/range {v42 .. v43}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v42

    move-object/from16 v43, v24

    invoke-virtual/range {v42 .. v43}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v42

    invoke-virtual/range {v42 .. v42}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v42

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    const-string v42, "] - "

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    invoke-virtual/range {v41 .. v41}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v41

    invoke-virtual/range {v40 .. v41}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v40

    move-object/from16 v41, v27

    invoke-virtual/range {v40 .. v41}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v40

    invoke-virtual/range {v40 .. v40}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v40

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    const-string v40, " (\u043e\u0442\u0432\u0435\u0442: "

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    invoke-virtual/range {v39 .. v39}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v39

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    move/from16 v39, v29

    if-eqz v39, :cond_2a

    const-string v39, "\u2705"

    :goto_13
    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    const-string v38, ")"

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-static/range {v36 .. v37}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_b

    .line 918
    :cond_27
    const/16 v36, 0x1

    goto/16 :goto_10

    .line 920
    :cond_28
    const-string v36, "\ud83d\udd34"

    goto/16 :goto_11

    .line 922
    :cond_29
    move-object/from16 v36, v3

    invoke-direct/range {v36 .. v36}, Lgtandroid/universal/JailAlertService;->getCurrentTimeMSK()Ljava/lang/String;

    move-result-object v36

    goto/16 :goto_12

    .line 933
    :cond_2a
    const-string v39, "\u274c"

    goto :goto_13

    .line 939
    :cond_2b
    move-object/from16 v36, v18

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Lgtandroid/universal/ReportData;

    move-object/from16 v20, v36

    .line 940
    const/16 v36, 0x0

    move/from16 v21, v36

    .line 941
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->hiddenReports:Ljava/util/List;

    move-object/from16 v36, v0

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v22, v36

    .line 945
    :cond_2c
    move-object/from16 v36, v22

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_2d

    .line 949
    :goto_14
    move/from16 v36, v21

    if-eqz v36, :cond_2e

    goto/16 :goto_6

    .line 941
    :cond_2d
    move-object/from16 v36, v22

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Lgtandroid/universal/ReportData;

    move-object/from16 v24, v36

    .line 942
    move-object/from16 v36, v24

    move-object/from16 v37, v20

    invoke-virtual/range {v36 .. v37}, Lgtandroid/universal/ReportData;->equals(Ljava/lang/Object;)Z

    move-result v36

    if-eqz v36, :cond_2c

    .line 943
    move-wide/from16 v36, v16

    move-object/from16 v38, v24

    move-object/from16 v0, v38

    iget-wide v0, v0, Lgtandroid/universal/ReportData;->hiddenUntil:J

    move-wide/from16 v38, v0

    cmp-long v36, v36, v38

    if-gez v36, :cond_2c

    .line 944
    const/16 v36, 0x1

    move/from16 v21, v36

    .line 945
    goto :goto_14

    .line 951
    :cond_2e
    const/16 v36, 0x0

    move/from16 v24, v36

    .line 952
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object/from16 v36, v0

    check-cast v36, Ljava/util/Collection;

    invoke-interface/range {v36 .. v36}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v36

    move-object/from16 v25, v36

    .line 976
    :cond_2f
    move-object/from16 v36, v25

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-nez v36, :cond_30

    .line 980
    :goto_15
    move/from16 v36, v24

    if-nez v36, :cond_4

    .line 981
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    move-object/from16 v36, v0

    move-object/from16 v37, v20

    invoke-interface/range {v36 .. v37}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v36

    goto/16 :goto_6

    .line 952
    :cond_30
    move-object/from16 v36, v25

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Lgtandroid/universal/ReportData;

    move-object/from16 v27, v36

    .line 953
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    invoke-virtual/range {v36 .. v37}, Lgtandroid/universal/ReportData;->equals(Ljava/lang/Object;)Z

    move-result v36

    if-eqz v36, :cond_2f

    .line 954
    move-object/from16 v36, v20

    move-object/from16 v0, v36

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isAnswered:Z

    move/from16 v36, v0

    if-eqz v36, :cond_31

    move-object/from16 v36, v27

    move-object/from16 v0, v36

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isAnswered:Z

    move/from16 v36, v0

    if-nez v36, :cond_31

    .line 955
    move-object/from16 v36, v27

    const/16 v37, 0x1

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isAnswered:Z

    .line 956
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    .line 958
    :cond_31
    move-object/from16 v36, v3

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v38, v27

    move-object/from16 v0, v38

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v38, v0

    invoke-direct/range {v36 .. v38}, Lgtandroid/universal/JailAlertService;->isNewerSourceTime(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_33

    .line 960
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    .line 961
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    .line 962
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    .line 963
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget v0, v0, Lgtandroid/universal/ReportData;->count:I

    move/from16 v37, v0

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput v0, v1, Lgtandroid/universal/ReportData;->count:I

    .line 964
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->fullLine:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->fullLine:Ljava/lang/String;

    .line 965
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isAnswered:Z

    move/from16 v37, v0

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isAnswered:Z

    .line 966
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-wide v0, v0, Lgtandroid/universal/ReportData;->firstSeenMs:J

    move-wide/from16 v37, v0

    move-wide/from16 v0, v37

    move-object/from16 v2, v36

    iput-wide v0, v2, Lgtandroid/universal/ReportData;->firstSeenMs:J

    .line 967
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isEvent:Z

    move/from16 v37, v0

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isEvent:Z

    .line 975
    :cond_32
    :goto_16
    const/16 v36, 0x1

    move/from16 v24, v36

    .line 976
    goto/16 :goto_15

    .line 968
    :cond_33
    move-object/from16 v36, v27

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    move-object/from16 v36, v0

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    move-object/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v36

    if-nez v36, :cond_32

    move-object/from16 v36, v20

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v36, v0

    if-eqz v36, :cond_34

    move-object/from16 v36, v27

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v36, v0

    if-eqz v36, :cond_34

    move-object/from16 v36, v20

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v36, v0

    move-object/from16 v37, v27

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v36

    if-eqz v36, :cond_32

    .line 972
    :cond_34
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    move-object/from16 v37, v0

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    .line 973
    move-object/from16 v36, v27

    move-object/from16 v37, v20

    move-object/from16 v0, v37

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isEvent:Z

    move/from16 v37, v0

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isEvent:Z

    goto :goto_16

    .line 986
    :cond_35
    move-object/from16 v36, v21

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Lgtandroid/universal/ReportData;

    move-object/from16 v23, v36

    .line 987
    move-object/from16 v36, v23

    move-object/from16 v0, v36

    iget-boolean v0, v0, Lgtandroid/universal/ReportData;->isAnswered:Z

    move/from16 v36, v0

    if-eqz v36, :cond_36

    goto/16 :goto_7

    .line 988
    :cond_36
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->answerSeenAt:Ljava/util/HashMap;

    move-object/from16 v36, v0

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v52, v37

    move-object/from16 v37, v52

    move-object/from16 v38, v52

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v52, v38

    move-object/from16 v38, v52

    move-object/from16 v39, v52

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v39, v23

    move-object/from16 v0, v39

    iget-object v0, v0, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    move-object/from16 v39, v0

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    const-string v39, "|"

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    move-object/from16 v38, v23

    move-object/from16 v0, v38

    iget-object v0, v0, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    move-object/from16 v38, v0

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v36

    check-cast v36, Ljava/lang/Long;

    move-object/from16 v24, v36

    .line 989
    move-object/from16 v36, v24

    if-eqz v36, :cond_5

    move-object/from16 v36, v24

    invoke-virtual/range {v36 .. v36}, Ljava/lang/Long;->longValue()J

    move-result-wide v36

    move-object/from16 v38, v23

    move-object/from16 v0, v38

    iget-wide v0, v0, Lgtandroid/universal/ReportData;->firstSeenMs:J

    move-wide/from16 v38, v0

    const-wide/16 v40, 0x5dc

    sub-long v38, v38, v40

    cmp-long v36, v36, v38

    if-ltz v36, :cond_5

    .line 990
    move-object/from16 v36, v23

    const/16 v37, 0x1

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput-boolean v0, v1, Lgtandroid/universal/ReportData;->isAnswered:Z

    .line 991
    move-object/from16 v36, v23

    move-object/from16 v37, v23

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    move-object/from16 v37, v0

    const-string v38, "\ud83d\udd34"

    const-string v39, "\ud83d\udfe2"

    invoke-virtual/range {v37 .. v39}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v37

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    .line 992
    const/16 v36, 0x1

    move/from16 v20, v36

    goto/16 :goto_7
.end method

.method private cleanOldRecords()V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 559
    move-object v1, p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    move-wide v3, v10

    .line 561
    new-instance v10, Ljava/util/ArrayList;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    move-object v5, v10

    .line 562
    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->hiddenReports:Ljava/util/List;

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v10

    move-object v6, v10

    .line 564
    :cond_0
    :goto_0
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_1

    .line 567
    move-object v10, v1

    move-object v11, v5

    iput-object v11, v10, Lgtandroid/universal/JailAlertService;->hiddenReports:Ljava/util/List;

    return-void

    .line 562
    :cond_1
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lgtandroid/universal/ReportData;

    move-object v8, v10

    .line 563
    move-wide v10, v3

    move-object v12, v8

    iget-wide v12, v12, Lgtandroid/universal/ReportData;->hiddenUntil:J

    cmp-long v10, v10, v12

    if-gez v10, :cond_0

    .line 564
    move-object v10, v5

    move-object v11, v8

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    goto :goto_0
.end method

.method private cleanReportText(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .prologue
    .line 750
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    if-nez v3, :cond_0

    const-string v3, ""

    move-object v0, v3

    .line 769
    :goto_0
    return-object v0

    .line 752
    :cond_0
    const-string v3, "\\[\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430:\\s*\\d+\\]"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 753
    const-string v3, "\\[\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430\\s*\\d+\\]"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 754
    const-string v3, "\\[\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430:\\s*\\d+\\]"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 755
    const-string v3, "\\[\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430\\s*\\d+\\]"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 757
    const-string v3, "(?i)\u0412\u044b \u0438\u0441\u0442\u043e\u0449\u0435\u043d\u044b!\\s*\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e!"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 758
    const-string v3, "(?i)\u0412\u044b \u0438\u0441\u0442\u043e\u0449\u0435\u043d\u044b!\\s*\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 759
    const-string v3, "(?i)\u0412\u044b \u0438\u0441\u0442\u043e\u0449\u0435\u043d\u044b!"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 760
    const-string v3, "(?i)\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e!"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 761
    const-string v3, "(?i)\u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435 \u0437\u0430\u043a\u0443\u0441\u043e\u0447\u043d\u0443\u044e"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 763
    const-string v3, "\\b\\d{1,2}:\\d{2}\\b"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 764
    const-string v3, "\\b\\d{1,2}\\.\\d{1,2}\\b"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 765
    const-string v3, "ID:\\s*\\d+"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 766
    const-string v3, "\\s*:\\s*$"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 767
    const-string v3, "\\s+"

    invoke-static {v3}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    move-object v4, v1

    invoke-virtual {v3, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 769
    move-object v3, v1

    move-object v0, v3

    goto/16 :goto_0
.end method

.method private clearAutoForm()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1360
    move-object v0, p0

    move-object v2, v0

    const-string v3, ""

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    .line 1361
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v2, :cond_0

    .line 1362
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "auto_form_pending"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1363
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "auto_form_data"

    invoke-interface {v2, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1365
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_1

    .line 1366
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1367
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Ljava/lang/Runnable;

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    .line 1370
    :cond_1
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/JailAlertService;->promoteQueueIfIdle()V

    return-void
.end method

.method private clearHelpPlayer()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1453
    move-object v0, p0

    move-object v2, v0

    const-string v3, ""

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    .line 1454
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v2, :cond_0

    .line 1455
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "help_player_pending"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "help_player_data"

    invoke-interface {v2, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1457
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_1

    .line 1458
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1459
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Ljava/lang/Runnable;

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    :cond_1
    return-void
.end method

.method private collectTextsInArea(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/StringBuilder;IIII[I)V
    .locals 26
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/accessibility/AccessibilityNodeInfo;",
            "Ljava/lang/StringBuilder;",
            "IIII[I)V"
        }
    .end annotation

    .prologue
    .line 675
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move-object/from16 v8, p7

    move-object v15, v2

    if-eqz v15, :cond_0

    move-object v15, v8

    const/16 v16, 0x0

    aget v15, v15, v16

    const/16 v16, 0x0

    move/from16 v0, v16

    if-gt v15, v0, :cond_1

    .line 722
    :cond_0
    :goto_0
    return-void

    .line 676
    :cond_1
    move-object v15, v8

    const/16 v16, 0x0

    move-object/from16 v24, v15

    move/from16 v25, v16

    move-object/from16 v15, v24

    move/from16 v16, v25

    move-object/from16 v17, v24

    move/from16 v18, v25

    aget v17, v17, v18

    const/16 v18, -0x1

    add-int/lit8 v17, v17, -0x1

    aput v17, v15, v16

    .line 678
    new-instance v15, Landroid/graphics/Rect;

    move-object/from16 v24, v15

    move-object/from16 v15, v24

    move-object/from16 v16, v24

    invoke-direct/range {v16 .. v16}, Landroid/graphics/Rect;-><init>()V

    move-object v10, v15

    .line 679
    move-object v15, v2

    move-object/from16 v16, v10

    invoke-virtual/range {v15 .. v16}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    .line 680
    move-object v15, v10

    invoke-virtual {v15}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_5

    const/4 v15, 0x0

    :goto_1
    move v11, v15

    .line 682
    move-object v15, v10

    move/from16 v16, v4

    move/from16 v17, v5

    move/from16 v18, v6

    move/from16 v19, v7

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Rect;->intersect(IIII)Z

    move-result v15

    if-eqz v15, :cond_b

    .line 683
    move-object v15, v2

    invoke-virtual {v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v15

    move-object v12, v15

    .line 684
    move-object v15, v12

    if-eqz v15, :cond_3

    move-object v15, v12

    invoke-interface {v15}, Ljava/lang/CharSequence;->length()I

    move-result v15

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_3

    .line 685
    move-object v15, v12

    invoke-interface {v15}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15

    move-object v13, v15

    .line 687
    move-object v15, v13

    const-string v16, "/acceptgnews"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v15

    if-eqz v15, :cond_6

    .line 688
    move-object v15, v1

    iget-object v15, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    if-eqz v15, :cond_2

    sget-object v15, Lgtandroid/universal/JailAlertService;->LEADING_TIME_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/regex/Matcher;->find()Z

    move-result v15

    if-nez v15, :cond_2

    .line 689
    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v24, v15

    move-object/from16 v15, v24

    move-object/from16 v16, v24

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v24, v16

    move-object/from16 v16, v24

    move-object/from16 v17, v24

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v17, v1

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    move-object/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    move-object v13, v15

    .line 691
    :cond_2
    move-object v15, v1

    const/16 v16, 0x0

    check-cast v16, Ljava/lang/String;

    move-object/from16 v0, v16

    iput-object v0, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    .line 692
    move-object v15, v3

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    .line 712
    :cond_3
    :goto_2
    move-object v15, v2

    invoke-virtual {v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v15

    move-object v13, v15

    .line 713
    move-object v15, v13

    if-eqz v15, :cond_4

    move-object v15, v13

    invoke-interface {v15}, Ljava/lang/CharSequence;->length()I

    move-result v15

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_4

    .line 714
    move-object v15, v3

    move-object/from16 v16, v13

    invoke-interface/range {v16 .. v16}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    .line 721
    :cond_4
    const/4 v15, 0x0

    move v12, v15

    :goto_3
    move v15, v12

    move-object/from16 v16, v2

    invoke-virtual/range {v16 .. v16}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v16

    move/from16 v0, v16

    if-lt v15, v0, :cond_c

    goto/16 :goto_0

    .line 680
    :cond_5
    const/4 v15, 0x1

    goto/16 :goto_1

    .line 693
    :cond_6
    sget-object v15, Lgtandroid/universal/JailAlertService;->TIME_ONLY_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/regex/Matcher;->matches()Z

    move-result v15

    if-eqz v15, :cond_8

    .line 694
    move-object v15, v1

    move-object/from16 v16, v13

    move-object/from16 v0, v16

    iput-object v0, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    .line 695
    move-object v15, v3

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->length()I

    move-result v15

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_7

    move-object v15, v3

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    :cond_7
    goto :goto_2

    .line 696
    :cond_8
    sget-object v15, Lgtandroid/universal/JailAlertService;->REPORT_NODE_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/regex/Matcher;->find()Z

    move-result v15

    if-eqz v15, :cond_a

    .line 697
    move-object v15, v1

    iget-object v15, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    if-eqz v15, :cond_9

    sget-object v15, Lgtandroid/universal/JailAlertService;->LEADING_TIME_PATTERN:Ljava/util/regex/Pattern;

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v15

    invoke-virtual {v15}, Ljava/util/regex/Matcher;->find()Z

    move-result v15

    if-nez v15, :cond_9

    .line 698
    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v24, v15

    move-object/from16 v15, v24

    move-object/from16 v16, v24

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v24, v16

    move-object/from16 v16, v24

    move-object/from16 v17, v24

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v17, v1

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    move-object/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    move-object v13, v15

    .line 700
    :cond_9
    move-object v15, v1

    const/16 v16, 0x0

    check-cast v16, Ljava/lang/String;

    move-object/from16 v0, v16

    iput-object v0, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    .line 701
    move-object v15, v3

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    goto/16 :goto_2

    .line 703
    :cond_a
    move-object v15, v1

    const/16 v16, 0x0

    check-cast v16, Ljava/lang/String;

    move-object/from16 v0, v16

    iput-object v0, v15, Lgtandroid/universal/JailAlertService;->collectPendingTime:Ljava/lang/String;

    .line 704
    move-object v15, v3

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->length()I

    move-result v15

    const/16 v16, 0x0

    move/from16 v0, v16

    if-le v15, v0, :cond_3

    .line 705
    move-object v15, v1

    move-object/from16 v16, v13

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/JailAlertService;->shouldIgnoreLine(Ljava/lang/String;)Z

    move-result v15

    if-nez v15, :cond_3

    .line 706
    move-object v15, v3

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, "\n"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    goto/16 :goto_2

    .line 716
    :cond_b
    move v15, v11

    if-eqz v15, :cond_4

    .line 718
    goto/16 :goto_0

    .line 722
    :cond_c
    move-object v15, v8

    const/16 v16, 0x0

    aget v15, v15, v16

    const/16 v16, 0x0

    move/from16 v0, v16

    if-gt v15, v0, :cond_d

    goto/16 :goto_0

    .line 723
    :cond_d
    move-object v15, v2

    move/from16 v16, v12

    invoke-virtual/range {v15 .. v16}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v15

    move-object v13, v15

    .line 724
    move-object v15, v13

    if-eqz v15, :cond_e

    .line 725
    move-object v15, v1

    move-object/from16 v16, v13

    move-object/from16 v17, v3

    move/from16 v18, v4

    move/from16 v19, v5

    move/from16 v20, v6

    move/from16 v21, v7

    move-object/from16 v22, v8

    invoke-direct/range {v15 .. v22}, Lgtandroid/universal/JailAlertService;->collectTextsInArea(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/StringBuilder;IIII[I)V

    .line 726
    move-object v15, v13

    invoke-virtual {v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    .line 721
    :cond_e
    add-int/lit8 v12, v12, 0x1

    goto/16 :goto_3
.end method

.method private containsCommand([Ljava/lang/String;Ljava/lang/String;)Z
    .locals 10

    .prologue
    .line 1202
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v8, v1

    move-object v4, v8

    const/4 v8, 0x0

    move v5, v8

    .line 1204
    :goto_0
    move v8, v5

    move-object v9, v4

    array-length v9, v9

    if-lt v8, v9, :cond_0

    .line 1207
    const/4 v8, 0x0

    move v0, v8

    :goto_1
    return v0

    .line 1202
    :cond_0
    move-object v8, v4

    move v9, v5

    aget-object v8, v8, v9

    move-object v6, v8

    .line 1203
    move-object v8, v6

    move-object v9, v2

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    .line 1204
    const/4 v8, 0x1

    move v0, v8

    goto :goto_1

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0
.end method

.method private static dbg(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    return-void
.end method

.method private enqueueAutoForm(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1289
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v10, :cond_0

    .line 1311
    :goto_0
    return-void

    .line 1291
    :cond_0
    :try_start_0
    new-instance v10, Lorg/json/JSONArray;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "auto_form_queue"

    const-string v14, "[]"

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v7, v10

    .line 1292
    move-object v10, v7

    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v10

    const/16 v11, 0x19

    if-lt v10, v11, :cond_1

    .line 1293
    const-string v10, "AutoReport"

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u26a0\ufe0f \u041e\u0447\u0435\u0440\u0435\u0434\u044c \u0430\u0432\u0442\u043e\u0444\u043e\u0440\u043c \u043f\u0435\u0440\u0435\u043f\u043e\u043b\u043d\u0435\u043d\u0430, \u043f\u0440\u043e\u043f\u0443\u0441\u043a\u0430\u0435\u043c: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v3

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1294
    goto :goto_0

    .line 1297
    :cond_1
    new-instance v10, Lorg/json/JSONObject;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    move-object v8, v10

    .line 1298
    move-object v10, v8

    const-string v11, "nick"

    move-object v12, v1

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1299
    move-object v10, v8

    const-string v11, "adminId"

    move-object v12, v2

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1300
    move-object v10, v8

    const-string v11, "command"

    move-object v12, v3

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1301
    move-object v10, v8

    const-string v11, "initials"

    move-object v12, v4

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1302
    move-object v10, v8

    const-string v11, "time"

    move-object v12, v5

    if-eqz v12, :cond_2

    move-object v12, v5

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v13, 0x0

    if-le v12, v13, :cond_2

    move-object v12, v5

    :goto_1
    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1303
    move-object v10, v8

    const-string v11, "timestamp"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-virtual {v10, v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v10

    .line 1304
    move-object v10, v7

    move-object v11, v8

    invoke-virtual {v10, v11}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v10

    .line 1305
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "auto_form_queue"

    move-object v12, v7

    invoke-virtual {v12}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1307
    const-string v10, "AutoReport"

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u2705 \u0412 \u043e\u0447\u0435\u0440\u0435\u0434\u044c \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430 \u0430\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v3

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1308
    move-object v10, v0

    invoke-direct {v10}, Lgtandroid/universal/JailAlertService;->promoteQueueIfIdle()V

    .line 1311
    :goto_2
    goto/16 :goto_0

    .line 1302
    :cond_2
    move-object v12, v0

    invoke-direct {v12}, Lgtandroid/universal/JailAlertService;->getCurrentTimeMSK()Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v12

    goto :goto_1

    .line 1308
    :catch_0
    move-exception v10

    move-object v7, v10

    .line 1311
    move-object v10, v7

    invoke-virtual {v10}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private extractCommand(Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    .prologue
    .line 1177
    move-object v0, p0

    move-object v1, p1

    const-string v6, "/(\\w+)"

    invoke-static {v6}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v6

    move-object v3, v6

    .line 1178
    move-object v6, v3

    move-object v7, v1

    invoke-virtual {v6, v7}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v6

    move-object v4, v6

    .line 1179
    move-object v6, v4

    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-eqz v6, :cond_0

    .line 1180
    new-instance v6, Ljava/lang/StringBuffer;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v4

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    move-object v0, v6

    .line 1182
    :goto_0
    return-object v0

    :cond_0
    const/4 v6, 0x0

    check-cast v6, Ljava/lang/String;

    move-object v0, v6

    goto :goto_0
.end method

.method private extractHelpPlayerId(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    .prologue
    .line 1374
    move-object v0, p0

    move-object v1, p1

    move-object v7, v1

    if-nez v7, :cond_0

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    .line 1387
    :goto_0
    return-object v0

    .line 1375
    :cond_0
    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v1, v7

    .line 1376
    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_1

    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    const/16 v8, 0x3c

    if-le v7, v8, :cond_2

    :cond_1
    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0

    .line 1378
    :cond_2
    move-object v7, v1

    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0

    .line 1380
    :cond_3
    move-object v7, v1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    move-object v3, v7

    .line 1382
    move-object v7, v3

    const-string v8, "[tools]"

    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_4

    move-object v7, v3

    const-string v8, "[atools]"

    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_4

    move-object v7, v3

    const-string v8, "\u043f\u044b\u0442\u0430\u044e\u0441\u044c \u043f\u043e\u043c\u043e\u0447\u044c"

    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_5

    :cond_4
    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0

    .line 1384
    :cond_5
    const-string v7, "\\d{1,2}:\\d{2}"

    invoke-static {v7}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v7

    move-object v8, v1

    invoke-virtual {v7, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 1385
    sget-object v7, Lgtandroid/universal/JailAlertService;->STANDALONE_NUMBER_PATTERN:Ljava/util/regex/Pattern;

    move-object v8, v4

    invoke-virtual {v7, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    move-object v5, v7

    .line 1386
    move-object v7, v5

    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    if-eqz v7, :cond_6

    move-object v7, v5

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    move-object v0, v7

    goto :goto_0

    .line 1387
    :cond_6
    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto/16 :goto_0
.end method

.method private extractReportCount([Ljava/lang/String;I)I
    .locals 14

    .prologue
    .line 1116
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move-object v11, v1

    move v12, v2

    aget-object v11, v11, v12

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v4, v11

    .line 1117
    const-string v11, "^\\d{1,2}:\\d{2}\\s*"

    invoke-static {v11}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v11

    move-object v12, v4

    invoke-virtual {v11, v12}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v11

    const-string v12, ""

    invoke-virtual {v11, v12}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v4, v11

    .line 1119
    const-string v11, "(\\d+)"

    invoke-static {v11}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v11

    move-object v5, v11

    .line 1121
    move-object v11, v4

    const-string v12, "\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual {v11, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_0

    move-object v11, v4

    const-string v12, "\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual {v11, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_1

    .line 1122
    :cond_0
    move-object v11, v5

    move-object v12, v4

    invoke-virtual {v11, v12}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v11

    move-object v6, v11

    .line 1123
    move-object v11, v6

    invoke-virtual {v11}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_1

    .line 1125
    move-object v11, v6

    const/4 v12, 0x1

    :try_start_0
    invoke-virtual {v11, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v11

    move v0, v11

    .line 1148
    :goto_0
    return v0

    .line 1125
    :catch_0
    move-exception v11

    move-object v7, v11

    .line 1127
    const/4 v11, 0x1

    move v0, v11

    goto :goto_0

    .line 1132
    :cond_1
    move v11, v2

    const/4 v12, 0x1

    add-int/lit8 v11, v11, 0x1

    move v6, v11

    :goto_1
    move v11, v6

    move v12, v2

    const/16 v13, 0xa

    add-int/lit8 v12, v12, 0xa

    move-object v13, v1

    array-length v13, v13

    invoke-static {v12, v13}, Ljava/lang/Math;->min(II)I

    move-result v12

    if-lt v11, v12, :cond_2

    .line 1148
    :goto_2
    const/4 v11, 0x1

    move v0, v11

    goto :goto_0

    .line 1133
    :cond_2
    move-object v11, v1

    move v12, v6

    aget-object v11, v11, v12

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 1134
    const-string v11, "^\\d{1,2}:\\d{2}\\s*"

    invoke-static {v11}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v11

    move-object v12, v7

    invoke-virtual {v11, v12}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v11

    const-string v12, ""

    invoke-virtual {v11, v12}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 1136
    move-object v11, v7

    const-string v12, "\u041a\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual {v11, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_3

    move-object v11, v7

    const-string v12, "\u041a-\u0432\u043e \u0440\u0435\u043f\u043e\u0440\u0442\u0430"

    invoke-virtual {v11, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_5

    .line 1137
    :cond_3
    move-object v11, v5

    move-object v12, v7

    invoke-virtual {v11, v12}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v11

    move-object v8, v11

    .line 1138
    move-object v11, v8

    invoke-virtual {v11}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_4

    .line 1140
    move-object v11, v8

    const/4 v12, 0x1

    :try_start_1
    invoke-virtual {v11, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    move-result v11

    move v0, v11

    goto :goto_0

    :catch_1
    move-exception v11

    move-object v9, v11

    .line 1142
    const/4 v11, 0x1

    move v0, v11

    goto :goto_0

    .line 1145
    :cond_4
    goto :goto_2

    .line 1132
    :cond_5
    add-int/lit8 v6, v6, 0x1

    goto :goto_1
.end method

.method private getCurrentTimeMSK()Ljava/lang/String;
    .locals 9

    .prologue
    .line 1110
    move-object v0, p0

    new-instance v4, Ljava/text/SimpleDateFormat;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    const-string v6, "HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v7

    invoke-direct {v5, v6, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    move-object v2, v4

    .line 1111
    move-object v4, v2

    const-string v5, "Europe/Moscow"

    invoke-static {v5}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 1112
    move-object v4, v2

    new-instance v5, Ljava/util/Date;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/util/Date;-><init>()V

    invoke-virtual {v4, v5}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    move-object v0, v4

    return-object v0
.end method

.method private initPrefs()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 135
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v2, :cond_0

    .line 136
    move-object v2, v0

    move-object v3, v0

    const-string v4, "GTAndroidData"

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    :cond_0
    return-void
.end method

.method private isCommandAllowed(Ljava/lang/String;)Z
    .locals 6

    .prologue
    .line 1186
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/JailAlertService;->userLevel:I

    packed-switch v3, :pswitch_data_0

    .line 1197
    const/4 v3, 0x0

    move v0, v3

    :goto_0
    return v0

    .line 1188
    :pswitch_0
    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_2_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    move v0, v3

    goto :goto_0

    .line 1190
    :pswitch_1
    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_2_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_0

    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_3_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_0

    const/4 v3, 0x0

    :goto_1
    move v0, v3

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    goto :goto_1

    .line 1193
    :pswitch_2
    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_2_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_3_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    move-object v3, v0

    sget-object v4, Lgtandroid/universal/JailAlertService;->LEVEL_4_COMMANDS:[Ljava/lang/String;

    move-object v5, v1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/JailAlertService;->containsCommand([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    const/4 v3, 0x0

    :goto_2
    move v0, v3

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    goto :goto_2

    .line 1186
    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method private isIgnoredNick(Ljava/lang/String;)Z
    .locals 9

    .prologue
    .line 1222
    move-object v0, p0

    move-object v1, p1

    move-object v7, v1

    if-nez v7, :cond_0

    const/4 v7, 0x0

    move v0, v7

    .line 1226
    :goto_0
    return v0

    .line 1223
    :cond_0
    sget-object v7, Lgtandroid/universal/JailAlertService;->IGNORED_NICKS:[Ljava/lang/String;

    move-object v3, v7

    const/4 v7, 0x0

    move v4, v7

    .line 1224
    :goto_1
    move v7, v4

    move-object v8, v3

    array-length v8, v8

    if-lt v7, v8, :cond_1

    .line 1226
    const/4 v7, 0x0

    move v0, v7

    goto :goto_0

    .line 1223
    :cond_1
    move-object v7, v3

    move v8, v4

    aget-object v7, v7, v8

    move-object v5, v7

    .line 1224
    move-object v7, v1

    move-object v8, v5

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/4 v7, 0x1

    move v0, v7

    goto :goto_0

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1
.end method

.method private isKeyboardVisible()Z
    .locals 5

    .prologue
    .line 1172
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v2, :cond_0

    const/4 v2, 0x0

    move v0, v2

    .line 1173
    :goto_0
    return v0

    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v3, "keyboard_visible"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    move v0, v2

    goto :goto_0
.end method

.method private isLineSeen(Ljava/lang/String;Z)Z
    .locals 14

    .prologue
    .line 288
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move-object v10, v0

    invoke-direct {v10}, Lgtandroid/universal/JailAlertService;->loadSeenLines()V

    .line 289
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object v11, v1

    invoke-virtual {v10, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Long;

    move-object v4, v10

    .line 290
    move-object v10, v4

    if-nez v10, :cond_0

    const/4 v10, 0x0

    move v0, v10

    .line 293
    :goto_0
    return v0

    .line 291
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    move-object v12, v4

    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    sub-long/2addr v10, v12

    move-wide v5, v10

    .line 292
    move v10, v2

    if-eqz v10, :cond_2

    const-wide/32 v10, 0x52571a0

    :goto_1
    move-wide v7, v10

    .line 293
    move-wide v10, v5

    const/4 v12, 0x0

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-ltz v10, :cond_1

    move-wide v10, v5

    move-wide v12, v7

    cmp-long v10, v10, v12

    if-ltz v10, :cond_3

    :cond_1
    const/4 v10, 0x0

    :goto_2
    move v0, v10

    goto :goto_0

    .line 292
    :cond_2
    const-wide/32 v10, 0x1d4c0

    goto :goto_1

    .line 293
    :cond_3
    const/4 v10, 0x1

    goto :goto_2
.end method

.method private isNewerSourceTime(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 10

    .prologue
    .line 1071
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v8, v0

    move-object v9, v1

    invoke-direct {v8, v9}, Lgtandroid/universal/JailAlertService;->parseMinutes(Ljava/lang/String;)I

    move-result v8

    move v4, v8

    .line 1072
    move-object v8, v0

    move-object v9, v2

    invoke-direct {v8, v9}, Lgtandroid/universal/JailAlertService;->parseMinutes(Ljava/lang/String;)I

    move-result v8

    move v5, v8

    .line 1073
    move v8, v4

    const/4 v9, 0x0

    if-lt v8, v9, :cond_0

    move v8, v5

    const/4 v9, 0x0

    if-lt v8, v9, :cond_0

    move v8, v4

    move v9, v5

    if-ne v8, v9, :cond_1

    :cond_0
    const/4 v8, 0x0

    move v0, v8

    .line 1075
    :goto_0
    return v0

    .line 1074
    :cond_1
    move v8, v4

    move v9, v5

    sub-int/2addr v8, v9

    const/16 v9, 0x5a0

    add-int/lit16 v8, v8, 0x5a0

    const/16 v9, 0x5a0

    rem-int/lit16 v8, v8, 0x5a0

    move v6, v8

    .line 1075
    move v8, v6

    const/4 v9, 0x0

    if-le v8, v9, :cond_2

    move v8, v6

    const/16 v9, 0x2d0

    if-lt v8, v9, :cond_3

    :cond_2
    const/4 v8, 0x0

    :goto_1
    move v0, v8

    goto :goto_0

    :cond_3
    const/4 v8, 0x1

    goto :goto_1
.end method

.method private isReportSeen(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 34

    .prologue
    .line 297
    move-object/from16 v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    move-object/from16 v6, p3

    move-object/from16 v7, p4

    move-object/from16 v24, v3

    invoke-direct/range {v24 .. v24}, Lgtandroid/universal/JailAlertService;->loadSeenLines()V

    .line 298
    new-instance v24, Ljava/lang/StringBuffer;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v25, Ljava/lang/StringBuffer;

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    invoke-direct/range {v26 .. v26}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v26, Ljava/lang/StringBuffer;

    move-object/from16 v33, v26

    move-object/from16 v26, v33

    move-object/from16 v27, v33

    invoke-direct/range {v27 .. v27}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v27, Ljava/lang/StringBuffer;

    move-object/from16 v33, v27

    move-object/from16 v27, v33

    move-object/from16 v28, v33

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v28, Ljava/lang/StringBuffer;

    move-object/from16 v33, v28

    move-object/from16 v28, v33

    move-object/from16 v29, v33

    invoke-direct/range {v29 .. v29}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v29, Ljava/lang/StringBuffer;

    move-object/from16 v33, v29

    move-object/from16 v29, v33

    move-object/from16 v30, v33

    invoke-direct/range {v30 .. v30}, Ljava/lang/StringBuffer;-><init>()V

    const-string v30, "rep|"

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    move-object/from16 v30, v4

    if-nez v30, :cond_2

    const-string v30, ""

    :goto_0
    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    invoke-virtual/range {v29 .. v29}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    const-string v29, "|"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    move-object/from16 v28, v5

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v27

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    const-string v27, "["

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    invoke-virtual/range {v26 .. v26}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    move-object/from16 v26, v6

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    const-string v25, "]|"

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v24

    move-object/from16 v9, v24

    .line 299
    move-object/from16 v24, v7

    if-nez v24, :cond_3

    const-string v24, ""

    :goto_1
    move-object/from16 v10, v24

    .line 300
    move-object/from16 v24, v4

    if-eqz v24, :cond_0

    move-object/from16 v24, v4

    invoke-virtual/range {v24 .. v24}, Ljava/lang/String;->length()I

    move-result v24

    const/16 v25, 0x0

    move/from16 v0, v24

    move/from16 v1, v25

    if-gt v0, v1, :cond_4

    :cond_0
    const/16 v24, 0x0

    :goto_2
    move/from16 v11, v24

    .line 301
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v24

    move-wide/from16 v12, v24

    .line 302
    move/from16 v24, v11

    if-eqz v24, :cond_5

    const-wide/32 v24, 0x52571a0

    :goto_3
    move-wide/from16 v14, v24

    .line 303
    move-object/from16 v24, v3

    move-object/from16 v0, v24

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v24, v0

    invoke-virtual/range {v24 .. v24}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v24

    check-cast v24, Ljava/util/Collection;

    invoke-interface/range {v24 .. v24}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v24

    move-object/from16 v16, v24

    .line 309
    :cond_1
    :goto_4
    move-object/from16 v24, v16

    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->hasNext()Z

    move-result v24

    if-nez v24, :cond_6

    .line 311
    const/16 v24, 0x0

    move/from16 v3, v24

    :goto_5
    return v3

    .line 298
    :cond_2
    move-object/from16 v30, v4

    goto/16 :goto_0

    .line 299
    :cond_3
    move-object/from16 v24, v7

    invoke-virtual/range {v24 .. v24}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v24

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v24

    const-string v25, "\\s+"

    const-string v26, " "

    invoke-virtual/range {v24 .. v26}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    goto :goto_1

    .line 300
    :cond_4
    const/16 v24, 0x1

    goto :goto_2

    .line 302
    :cond_5
    const-wide/32 v24, 0x1d4c0

    goto :goto_3

    .line 303
    :cond_6
    move-object/from16 v24, v16

    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    check-cast v24, Ljava/util/Map$Entry;

    move-object/from16 v18, v24

    .line 304
    move-object/from16 v24, v18

    invoke-interface/range {v24 .. v24}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v24

    check-cast v24, Ljava/lang/String;

    move-object/from16 v19, v24

    .line 305
    move-object/from16 v24, v19

    move-object/from16 v25, v9

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v24

    if-nez v24, :cond_7

    goto :goto_4

    .line 306
    :cond_7
    move-wide/from16 v24, v12

    move-object/from16 v26, v18

    invoke-interface/range {v26 .. v26}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v26

    check-cast v26, Ljava/lang/Long;

    invoke-virtual/range {v26 .. v26}, Ljava/lang/Long;->longValue()J

    move-result-wide v26

    sub-long v24, v24, v26

    move-wide/from16 v20, v24

    .line 307
    move-wide/from16 v24, v20

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-ltz v24, :cond_8

    move-wide/from16 v24, v20

    move-wide/from16 v26, v14

    cmp-long v24, v24, v26

    if-ltz v24, :cond_9

    :cond_8
    goto :goto_4

    .line 308
    :cond_9
    move-object/from16 v24, v19

    move-object/from16 v25, v9

    invoke-virtual/range {v25 .. v25}, Ljava/lang/String;->length()I

    move-result v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v22, v24

    .line 309
    move-object/from16 v24, v22

    move-object/from16 v25, v10

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v24

    if-nez v24, :cond_a

    move-object/from16 v24, v22

    move-object/from16 v25, v10

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v24

    if-nez v24, :cond_a

    move-object/from16 v24, v10

    move-object/from16 v25, v22

    invoke-virtual/range {v24 .. v25}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v24

    if-eqz v24, :cond_1

    :cond_a
    const/16 v24, 0x1

    move/from16 v3, v24

    goto/16 :goto_5
.end method

.method private listenForLevelChanges()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 491
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    new-instance v3, Lgtandroid/universal/JailAlertService$100000005;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService$100000005;-><init>(Lgtandroid/universal/JailAlertService;)V

    const/16 v4, 0x7d0

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method

.method private loadAreaSettings()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 732
    move-object v0, p0

    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "area_x"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/JailAlertService;->areaX:I

    .line 733
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "area_y"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/JailAlertService;->areaY:I

    .line 734
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "area_width"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/JailAlertService;->areaWidth:I

    .line 735
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "area_height"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/JailAlertService;->areaHeight:I

    .line 736
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "tracking_enabled"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    iput-boolean v3, v2, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    .line 738
    const-string v2, "AutoReport"

    new-instance v3, Ljava/lang/StringBuffer;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v11, v4

    move-object v4, v11

    move-object v5, v11

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v5, Ljava/lang/StringBuffer;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    invoke-direct {v6}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "loadAreaSettings: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/JailAlertService;->areaX:I

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, ","

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/JailAlertService;->areaY:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    move-object v6, v0

    iget v6, v6, Lgtandroid/universal/JailAlertService;->areaWidth:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "x"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/JailAlertService;->areaHeight:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 739
    const-string v2, "AutoReport"

    new-instance v3, Ljava/lang/StringBuffer;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    const-string v4, "trackingEnabled = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    move-object v4, v0

    iget-boolean v4, v4, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 741
    move-object v2, v0

    iget-boolean v2, v2, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    if-eqz v2, :cond_1

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/JailAlertService;->areaWidth:I

    const/4 v3, 0x0

    if-eq v2, v3, :cond_0

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/JailAlertService;->areaHeight:I

    const/4 v3, 0x0

    if-ne v2, v3, :cond_1

    .line 742
    :cond_0
    move-object v2, v0

    const/4 v3, 0x0

    iput-boolean v3, v2, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    .line 743
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "tracking_enabled"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 744
    move-object v2, v0

    const-string v3, "\u26a0\ufe0f \u041e\u0431\u043b\u0430\u0441\u0442\u044c \u043e\u0442\u0441\u043b\u0435\u0436\u0438\u0432\u0430\u043d\u0438\u044f \u043d\u0435 \u0437\u0430\u0434\u0430\u043d\u0430!"

    const/4 v4, 0x1

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    :cond_1
    return-void
.end method

.method private loadSeenLines()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 268
    move-object/from16 v0, p0

    move-object v10, v0

    iget-boolean v10, v10, Lgtandroid/universal/JailAlertService;->seenLinesLoaded:Z

    if-eqz v10, :cond_0

    .line 283
    :goto_0
    return-void

    .line 269
    :cond_0
    move-object v10, v0

    const/4 v11, 0x1

    iput-boolean v11, v10, Lgtandroid/universal/JailAlertService;->seenLinesLoaded:Z

    .line 270
    move-object v10, v0

    invoke-direct {v10}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 272
    :try_start_0
    new-instance v10, Lorg/json/JSONObject;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "seen_chat_lines"

    const-string v14, "{}"

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    move-object v2, v10

    .line 273
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    move-wide v3, v10

    .line 274
    move-object v10, v2

    invoke-virtual {v10}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v10

    move-object v5, v10

    .line 275
    :cond_1
    :goto_1
    move-object v10, v5

    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_2

    .line 283
    :goto_2
    goto :goto_0

    .line 276
    :cond_2
    move-object v10, v5

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    move-object v6, v10

    .line 277
    move-object v10, v2

    move-object v11, v6

    const/4 v12, 0x0

    int-to-long v12, v12

    invoke-virtual {v10, v11, v12, v13}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v10

    move-wide v7, v10

    .line 278
    move-wide v10, v3

    move-wide v12, v7

    sub-long/2addr v10, v12

    const-wide/32 v12, 0x52571a0

    cmp-long v10, v10, v12

    if-gez v10, :cond_1

    .line 279
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object v11, v6

    move-wide v12, v7

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    invoke-virtual {v10, v11, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v10

    goto :goto_1

    .line 275
    :catch_0
    move-exception v10

    move-object v2, v10

    .line 283
    move-object v10, v2

    invoke-virtual {v10}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private markLineSeen(Ljava/lang/String;)V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 315
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v16, v1

    invoke-direct/range {v16 .. v16}, Lgtandroid/universal/JailAlertService;->loadSeenLines()V

    .line 316
    move-object/from16 v16, v1

    invoke-direct/range {v16 .. v16}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 317
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    move-wide/from16 v4, v16

    .line 318
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v16, v0

    move-object/from16 v17, v2

    move-wide/from16 v18, v4

    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v18

    invoke-virtual/range {v16 .. v18}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    .line 321
    :try_start_0
    new-instance v16, Ljava/util/ArrayList;

    move-object/from16 v20, v16

    move-object/from16 v16, v20

    move-object/from16 v17, v20

    invoke-direct/range {v17 .. v17}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v6, v16

    .line 322
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v16

    check-cast v16, Ljava/util/Collection;

    invoke-interface/range {v16 .. v16}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v16

    move-object/from16 v7, v16

    .line 325
    :cond_0
    :goto_0
    move-object/from16 v16, v7

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-nez v16, :cond_1

    .line 328
    move-object/from16 v16, v6

    check-cast v16, Ljava/util/Collection;

    invoke-interface/range {v16 .. v16}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v16

    move-object/from16 v9, v16

    .line 329
    :goto_1
    move-object/from16 v16, v9

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-nez v16, :cond_3

    .line 331
    new-instance v16, Lorg/json/JSONObject;

    move-object/from16 v20, v16

    move-object/from16 v16, v20

    move-object/from16 v17, v20

    invoke-direct/range {v17 .. v17}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v11, v16

    .line 332
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v16

    check-cast v16, Ljava/util/Collection;

    invoke-interface/range {v16 .. v16}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v16

    move-object/from16 v12, v16

    .line 333
    :goto_2
    move-object/from16 v16, v12

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-nez v16, :cond_4

    .line 335
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v16, v0

    invoke-interface/range {v16 .. v16}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v16

    const-string v17, "seen_chat_lines"

    move-object/from16 v18, v11

    invoke-virtual/range {v18 .. v18}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-interface/range {v16 .. v18}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 337
    :goto_3
    return-void

    .line 322
    :cond_1
    move-object/from16 v16, v7

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    move-object/from16 v9, v16

    .line 323
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v16, v0

    move-object/from16 v17, v9

    invoke-virtual/range {v16 .. v17}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/Long;

    move-object/from16 v10, v16

    .line 324
    move-object/from16 v16, v10

    if-eqz v16, :cond_2

    move-wide/from16 v16, v4

    move-object/from16 v18, v10

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Long;->longValue()J

    move-result-wide v18

    sub-long v16, v16, v18

    const-wide/32 v18, 0x52571a0

    cmp-long v16, v16, v18

    if-ltz v16, :cond_0

    .line 325
    :cond_2
    move-object/from16 v16, v6

    move-object/from16 v17, v9

    invoke-interface/range {v16 .. v17}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v16

    goto/16 :goto_0

    .line 328
    :cond_3
    move-object/from16 v16, v9

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    move-object/from16 v11, v16

    .line 329
    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v16, v0

    move-object/from16 v17, v11

    invoke-virtual/range {v16 .. v17}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    goto/16 :goto_1

    .line 332
    :cond_4
    move-object/from16 v16, v12

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    move-object/from16 v14, v16

    .line 333
    move-object/from16 v16, v11

    move-object/from16 v17, v14

    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService;->seenLines:Ljava/util/HashMap;

    move-object/from16 v18, v0

    move-object/from16 v19, v14

    invoke-virtual/range {v18 .. v19}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/Long;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Long;->longValue()J

    move-result-wide v18

    invoke-virtual/range {v16 .. v19}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v16

    goto/16 :goto_2

    .line 335
    :catch_0
    move-exception v16

    move-object/from16 v6, v16

    .line 337
    move-object/from16 v16, v6

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Throwable;->printStackTrace()V

    goto/16 :goto_3
.end method

.method private matchesActiveEvent(Ljava/lang/String;)Z
    .locals 20

    .prologue
    .line 1088
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v11, :cond_0

    const/4 v11, 0x0

    move v0, v11

    .line 1106
    :goto_0
    return v0

    .line 1090
    :cond_0
    :try_start_0
    new-instance v11, Lorg/json/JSONArray;

    move-object/from16 v19, v11

    move-object/from16 v11, v19

    move-object/from16 v12, v19

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v14, "events_list"

    const-string v15, "[]"

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-direct {v12, v13}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v11

    .line 1091
    move-object v11, v0

    move-object v12, v0

    invoke-direct {v12}, Lgtandroid/universal/JailAlertService;->getCurrentTimeMSK()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lgtandroid/universal/JailAlertService;->parseMinutes(Ljava/lang/String;)I

    move-result v11

    move v4, v11

    .line 1092
    move v11, v4

    const/4 v12, 0x0

    if-ge v11, v12, :cond_1

    const/4 v11, 0x0

    move v0, v11

    goto :goto_0

    .line 1093
    :cond_1
    const/4 v11, 0x0

    move v5, v11

    :goto_1
    move v11, v5

    move-object v12, v3

    invoke-virtual {v12}, Lorg/json/JSONArray;->length()I

    move-result v12

    if-lt v11, v12, :cond_2

    .line 1106
    :goto_2
    const/4 v11, 0x0

    move v0, v11

    goto :goto_0

    .line 1094
    :cond_2
    move-object v11, v3

    move v12, v5

    invoke-virtual {v11, v12}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    move-object v6, v11

    .line 1095
    move-object v11, v6

    const-string v12, "enabled"

    const/4 v13, 0x0

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v11

    if-nez v11, :cond_3

    .line 1093
    :goto_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 1096
    :cond_3
    move-object v11, v0

    move-object v12, v6

    const-string v13, "from"

    const-string v14, ""

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lgtandroid/universal/JailAlertService;->parseMinutes(Ljava/lang/String;)I

    move-result v11

    move v7, v11

    .line 1097
    move-object v11, v0

    move-object v12, v6

    const-string v13, "to"

    const-string v14, ""

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lgtandroid/universal/JailAlertService;->parseMinutes(Ljava/lang/String;)I

    move-result v11

    move v8, v11

    .line 1098
    move v11, v7

    const/4 v12, 0x0

    if-lt v11, v12, :cond_4

    move v11, v8

    const/4 v12, 0x0

    if-ge v11, v12, :cond_5

    :cond_4
    goto :goto_3

    .line 1099
    :cond_5
    move v11, v7

    move v12, v8

    if-gt v11, v12, :cond_8

    move v11, v4

    move v12, v7

    if-lt v11, v12, :cond_6

    move v11, v4

    move v12, v8

    if-lt v11, v12, :cond_7

    :cond_6
    const/4 v11, 0x0

    :goto_4
    move v9, v11

    .line 1100
    move v11, v9

    if-nez v11, :cond_a

    goto :goto_3

    .line 1099
    :cond_7
    const/4 v11, 0x1

    goto :goto_4

    :cond_8
    move v11, v4

    move v12, v7

    if-ge v11, v12, :cond_9

    move v11, v4

    move v12, v8

    if-lt v11, v12, :cond_9

    const/4 v11, 0x0

    goto :goto_4

    :cond_9
    const/4 v11, 0x1

    goto :goto_4

    .line 1101
    :cond_a
    move-object v11, v0

    move-object v12, v1

    move-object v13, v6

    const-string v14, "keyword"

    const-string v15, ""

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-direct {v11, v12, v13}, Lgtandroid/universal/JailAlertService;->textMatchesEventKeyword(Ljava/lang/String;Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v11

    move v0, v11

    goto/16 :goto_0

    .line 1093
    :catch_0
    move-exception v11

    move-object v3, v11

    .line 1104
    move-object v11, v3

    invoke-virtual {v11}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private needsInitials(Ljava/lang/String;)Z
    .locals 9

    .prologue
    .line 1211
    move-object v0, p0

    move-object v1, p1

    sget-object v7, Lgtandroid/universal/JailAlertService;->NO_INITIALS_COMMANDS:[Ljava/lang/String;

    move-object v3, v7

    const/4 v7, 0x0

    move v4, v7

    .line 1213
    :goto_0
    move v7, v4

    move-object v8, v3

    array-length v8, v8

    if-lt v7, v8, :cond_0

    .line 1216
    const/4 v7, 0x1

    move v0, v7

    :goto_1
    return v0

    .line 1211
    :cond_0
    move-object v7, v3

    move v8, v4

    aget-object v7, v7, v8

    move-object v5, v7

    .line 1212
    move-object v7, v5

    move-object v8, v1

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 1213
    const/4 v7, 0x0

    move v0, v7

    goto :goto_1

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0
.end method

.method private onScanResult(Ljava/lang/String;Ljava/lang/String;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 637
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    sget-boolean v7, Lgtandroid/universal/JailAlertService;->isRunning:Z

    if-eqz v7, :cond_0

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    if-nez v7, :cond_1

    .line 669
    :cond_0
    :goto_0
    return-void

    .line 638
    :cond_1
    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    if-nez v7, :cond_2

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    if-nez v7, :cond_2

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    if-nez v7, :cond_2

    goto :goto_0

    .line 640
    :cond_2
    sget-object v7, Lgtandroid/universal/JailAlertService;->GAME_LINE_PATTERN:Ljava/util/regex/Pattern;

    move-object v8, v2

    invoke-virtual {v7, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    move v4, v7

    .line 641
    move v7, v4

    if-eqz v7, :cond_3

    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v8, 0x0

    if-le v7, v8, :cond_3

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->hotPackages:Ljava/util/Set;

    move-object v8, v1

    invoke-interface {v7, v8}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_3

    .line 642
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v7, :cond_3

    .line 643
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "hot_scan_packages"

    new-instance v9, Ljava/util/HashSet;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/JailAlertService;->hotPackages:Ljava/util/Set;

    invoke-direct {v10, v11}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 646
    :cond_3
    move-object v7, v0

    move v8, v4

    if-nez v8, :cond_4

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->hotPackages:Ljava/util/Set;

    move-object v9, v1

    invoke-interface {v8, v9}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4

    const/4 v8, 0x0

    :goto_1
    iput-boolean v8, v7, Lgtandroid/universal/JailAlertService;->lastScanHot:Z

    .line 648
    move-object v7, v2

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5

    .line 649
    goto :goto_0

    .line 646
    :cond_4
    const/4 v8, 0x1

    goto :goto_1

    .line 651
    :cond_5
    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    .line 654
    move-object v7, v2

    :try_start_0
    const-string v8, "\n"

    invoke-virtual {v7, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 655
    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    if-eqz v7, :cond_6

    .line 656
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService;->checkReports([Ljava/lang/String;)V

    .line 658
    :cond_6
    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    if-eqz v7, :cond_7

    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/JailAlertService;->userLevel:I

    const/4 v8, 0x2

    if-lt v7, v8, :cond_7

    .line 659
    move-object v7, v0

    move-object v8, v5

    move-object v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/JailAlertService;->checkAutoForms([Ljava/lang/String;Ljava/lang/String;)V

    .line 660
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/JailAlertService;->promoteQueueIfIdle()V

    .line 662
    :cond_7
    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    if-eqz v7, :cond_8

    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/JailAlertService;->userLevel:I

    const/4 v8, 0x1

    if-lt v7, v8, :cond_8

    .line 663
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService;->checkHelpRequests([Ljava/lang/String;)V

    .line 665
    :cond_8
    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    if-eqz v7, :cond_9

    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/JailAlertService;->userLevel:I

    const/4 v8, 0x3

    if-lt v7, v8, :cond_9

    .line 666
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService;->checkGNews([Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    .line 669
    :cond_9
    :goto_2
    goto/16 :goto_0

    .line 666
    :catch_0
    move-exception v7

    move-object v5, v7

    .line 669
    move-object v7, v0

    const-string v8, "AutoReport"

    move-object v9, v5

    invoke-static {v7, v8, v9}, Lgtandroid/universal/AppLogger;->logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_2
.end method

.method private parseMinutes(Ljava/lang/String;)I
    .locals 9

    .prologue
    .line 1061
    move-object v0, p0

    move-object v1, p1

    move-object v7, v1

    if-nez v7, :cond_0

    const/4 v7, -0x1

    move v0, v7

    .line 1067
    :goto_0
    return v0

    .line 1062
    :cond_0
    const-string v7, "^\\s*(\\d{1,2}):(\\d{2})\\s*$"

    invoke-static {v7}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v7

    move-object v8, v1

    invoke-virtual {v7, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    move-object v3, v7

    .line 1063
    move-object v7, v3

    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    if-nez v7, :cond_1

    const/4 v7, -0x1

    move v0, v7

    goto :goto_0

    .line 1064
    :cond_1
    move-object v7, v3

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    move v4, v7

    .line 1065
    move-object v7, v3

    const/4 v8, 0x2

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    move v5, v7

    .line 1066
    move v7, v4

    const/16 v8, 0x17

    if-gt v7, v8, :cond_2

    move v7, v5

    const/16 v8, 0x3b

    if-le v7, v8, :cond_3

    :cond_2
    const/4 v7, -0x1

    move v0, v7

    goto :goto_0

    .line 1067
    :cond_3
    move v7, v4

    const/16 v8, 0x3c

    mul-int/lit8 v7, v7, 0x3c

    move v8, v5

    add-int/2addr v7, v8

    move v0, v7

    goto :goto_0
.end method

.method private processLine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 20

    .prologue
    .line 1230
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    sget-object v12, Lgtandroid/universal/JailAlertService;->JAIL_PATTERN:Ljava/util/regex/Pattern;

    move-object v13, v1

    invoke-virtual {v12, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v12

    move-object v5, v12

    .line 1231
    move-object v12, v5

    invoke-virtual {v12}, Ljava/util/regex/Matcher;->find()Z

    move-result v12

    if-nez v12, :cond_0

    const/4 v12, 0x0

    move v0, v12

    .line 1253
    :goto_0
    return v0

    .line 1233
    :cond_0
    move-object v12, v5

    const/4 v13, 0x2

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    move-object v6, v12

    .line 1234
    move-object v12, v5

    const/4 v13, 0x3

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    move-object v7, v12

    .line 1235
    move-object v12, v5

    const/4 v13, 0x4

    invoke-virtual {v12, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    move-object v8, v12

    .line 1237
    move-object v12, v6

    if-eqz v12, :cond_1

    move-object v12, v6

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_1

    move-object v12, v6

    const-string v13, "\u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u044b\u0439"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_2

    :cond_1
    const/4 v12, 0x0

    move v0, v12

    goto :goto_0

    .line 1238
    :cond_2
    move-object v12, v8

    if-eqz v12, :cond_3

    move-object v12, v8

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_4

    :cond_3
    const/4 v12, 0x0

    move v0, v12

    goto :goto_0

    .line 1239
    :cond_4
    move-object v12, v0

    move-object v13, v6

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->isIgnoredNick(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_5

    const/4 v12, 0x0

    move v0, v12

    goto :goto_0

    .line 1241
    :cond_5
    move-object v12, v0

    const-string v13, "af"

    move-object v14, v3

    move-object v15, v6

    move-object/from16 v16, v7

    move-object/from16 v17, v8

    invoke-direct/range {v12 .. v17}, Lgtandroid/universal/JailAlertService;->seenKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v9, v12

    .line 1242
    move-object v12, v0

    move-object v13, v9

    move-object v14, v3

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    const/4 v15, 0x0

    if-gt v14, v15, :cond_6

    const/4 v14, 0x0

    :goto_1
    invoke-direct {v12, v13, v14}, Lgtandroid/universal/JailAlertService;->isLineSeen(Ljava/lang/String;Z)Z

    move-result v12

    if-eqz v12, :cond_7

    const/4 v12, 0x0

    move v0, v12

    goto :goto_0

    :cond_6
    const/4 v14, 0x1

    goto :goto_1

    .line 1244
    :cond_7
    const-string v12, ""

    move-object v10, v12

    .line 1245
    move-object v12, v0

    move-object v13, v2

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->needsInitials(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_8

    .line 1246
    move-object v12, v0

    move-object v13, v6

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->buildInitials(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v10, v12

    .line 1249
    :cond_8
    const-string v12, "AutoReport"

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v19, v14

    move-object/from16 v14, v19

    move-object/from16 v15, v19

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v19, v15

    move-object/from16 v15, v19

    move-object/from16 v16, v19

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    const-string v16, "\ud83d\udcbe \u0421\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u043c \u0430\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0443: "

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move-object/from16 v16, v6

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, " - "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v8

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v12, v13}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1251
    move-object v12, v0

    move-object v13, v9

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->markLineSeen(Ljava/lang/String;)V

    .line 1252
    move-object v12, v0

    move-object v13, v6

    move-object v14, v7

    move-object v15, v8

    move-object/from16 v16, v10

    move-object/from16 v17, v3

    invoke-direct/range {v12 .. v17}, Lgtandroid/universal/JailAlertService;->enqueueAutoForm(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1253
    const/4 v12, 0x1

    move v0, v12

    goto/16 :goto_0
.end method

.method private promoteQueueIfIdle()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1316
    move-object v0, p0

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v7, :cond_0

    .line 1338
    :goto_0
    return-void

    .line 1317
    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v8, "auto_form_pending"

    const/4 v9, 0x0

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_0

    .line 1320
    :cond_1
    :try_start_0
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "auto_form_queue"

    const-string v11, "[]"

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v2, v7

    .line 1321
    move-object v7, v2

    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v7

    const/4 v8, 0x0

    if-ne v7, v8, :cond_2

    goto :goto_0

    .line 1323
    :cond_2
    move-object v7, v2

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    move-object v3, v7

    .line 1324
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Lorg/json/JSONArray;-><init>()V

    move-object v4, v7

    .line 1325
    const/4 v7, 0x1

    move v5, v7

    :goto_1
    move v7, v5

    move-object v8, v2

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-lt v7, v8, :cond_3

    .line 1329
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "auto_form_data"

    move-object v9, v3

    invoke-virtual {v9}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "auto_form_pending"

    const/4 v9, 0x1

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "auto_form_queue"

    move-object v9, v4

    invoke-virtual {v9}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1335
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/JailAlertService;->startAutoFormTimeout()V

    .line 1336
    const-string v7, "AutoReport"

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\ud83d\udce4 \u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u043c \u0438\u0437 \u043e\u0447\u0435\u0440\u0435\u0434\u0438: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v3

    const-string v10, "command"

    const-string v11, ""

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1338
    :goto_2
    goto/16 :goto_0

    .line 1326
    :cond_3
    move-object v7, v4

    move-object v8, v2

    move v9, v5

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v7

    .line 1325
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 1336
    :catch_0
    move-exception v7

    move-object v2, v7

    .line 1338
    move-object v7, v2

    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private removeReport(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1046
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    new-instance v12, Ljava/util/ArrayList;

    move-object/from16 v21, v12

    move-object/from16 v12, v21

    move-object/from16 v13, v21

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    move-object v6, v12

    .line 1047
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    check-cast v12, Ljava/util/Collection;

    invoke-interface {v12}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v12

    move-object v7, v12

    .line 1052
    :goto_0
    move-object v12, v7

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-nez v12, :cond_0

    .line 1055
    move-object v12, v1

    move-object v13, v6

    iput-object v13, v12, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    .line 1057
    move-object v12, v1

    invoke-direct {v12}, Lgtandroid/universal/JailAlertService;->saveReportsToPrefs()V

    return-void

    .line 1047
    :cond_0
    move-object v12, v7

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lgtandroid/universal/ReportData;

    move-object v9, v12

    .line 1048
    move-object v12, v9

    iget-object v12, v12, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    move-object v13, v2

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1

    move-object v12, v9

    iget-object v12, v12, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    move-object v13, v3

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2

    .line 1049
    :cond_1
    move-object v12, v6

    move-object v13, v9

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v12

    goto :goto_0

    .line 1051
    :cond_2
    move-object v12, v9

    iget-object v12, v12, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    if-eqz v12, :cond_3

    move-object v12, v9

    iget-object v12, v12, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v13, 0x0

    if-le v12, v13, :cond_3

    move-object v12, v9

    iget-object v12, v12, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    :goto_1
    move-object v10, v12

    .line 1052
    move-object v12, v1

    move-object v13, v1

    const-string v14, "rep"

    move-object v15, v10

    move-object/from16 v16, v2

    move-object/from16 v17, v3

    move-object/from16 v18, v9

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    move-object/from16 v18, v0

    invoke-direct/range {v13 .. v18}, Lgtandroid/universal/JailAlertService;->seenKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-direct {v12, v13}, Lgtandroid/universal/JailAlertService;->markLineSeen(Ljava/lang/String;)V

    goto :goto_0

    .line 1051
    :cond_3
    move-object v12, v4

    if-nez v12, :cond_4

    const-string v12, ""

    goto :goto_1

    :cond_4
    move-object v12, v4

    goto :goto_1
.end method

.method private requestScan(Z)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .prologue
    .line 587
    move-object v0, p0

    move v1, p1

    sget-boolean v8, Lgtandroid/universal/JailAlertService;->isRunning:Z

    if-eqz v8, :cond_0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    if-eqz v8, :cond_0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->scanHandler:Landroid/os/Handler;

    if-nez v8, :cond_1

    .line 596
    :cond_0
    :goto_0
    return-void

    .line 588
    :cond_1
    move-object v8, v0

    iget-boolean v8, v8, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    if-nez v8, :cond_2

    goto :goto_0

    .line 589
    :cond_2
    move-object v8, v0

    iget-boolean v8, v8, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    if-nez v8, :cond_3

    move-object v8, v0

    iget-boolean v8, v8, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    if-nez v8, :cond_3

    move-object v8, v0

    iget-boolean v8, v8, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    if-nez v8, :cond_3

    goto :goto_0

    .line 591
    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    move-wide v3, v8

    .line 592
    move-object v8, v0

    iget-boolean v8, v8, Lgtandroid/universal/JailAlertService;->lastScanHot:Z

    if-eqz v8, :cond_4

    const-wide/16 v8, 0x96

    :goto_1
    move-wide v5, v8

    .line 593
    move v8, v1

    if-nez v8, :cond_5

    move-wide v8, v3

    move-object v10, v0

    iget-wide v10, v10, Lgtandroid/universal/JailAlertService;->lastScanStartMs:J

    sub-long/2addr v8, v10

    move-wide v10, v5

    cmp-long v8, v8, v10

    if-gez v8, :cond_5

    goto :goto_0

    .line 592
    :cond_4
    const-wide/16 v8, 0xbb8

    goto :goto_1

    .line 594
    :cond_5
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v8, v9, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v8

    if-nez v8, :cond_6

    goto :goto_0

    .line 595
    :cond_6
    move-object v8, v0

    move-wide v9, v3

    iput-wide v9, v8, Lgtandroid/universal/JailAlertService;->lastScanStartMs:J

    .line 596
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->scanHandler:Landroid/os/Handler;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->scanRunnable:Ljava/lang/Runnable;

    invoke-virtual {v8, v9}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v8

    goto :goto_0
.end method

.method private static rx(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    .prologue
    .line 72
    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    invoke-static {v4}, Lgtandroid/universal/JailAlertService;->rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    move-object v5, v1

    invoke-virtual {v4, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/regex/Matcher;->matches()Z

    move-result v4

    move v0, v4

    return v0
.end method

.method private static rxp(Ljava/lang/String;)Ljava/util/regex/Pattern;
    .locals 7

    .prologue
    .line 64
    move-object v0, p0

    sget-object v4, Lgtandroid/universal/JailAlertService;->PATTERN_CACHE:Ljava/util/Map;

    move-object v5, v0

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/regex/Pattern;

    move-object v2, v4

    .line 65
    move-object v4, v2

    if-nez v4, :cond_0

    .line 66
    move-object v4, v0

    invoke-static {v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    move-object v2, v4

    .line 67
    sget-object v4, Lgtandroid/universal/JailAlertService;->PATTERN_CACHE:Ljava/util/Map;

    move-object v5, v0

    move-object v6, v2

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 69
    :cond_0
    move-object v4, v2

    move-object v0, v4

    return-object v0
.end method

.method private saveHelpToPrefs(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1421
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v10, :cond_0

    .line 1434
    :goto_0
    return-void

    .line 1423
    :cond_0
    :try_start_0
    new-instance v10, Lorg/json/JSONObject;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    move-object v8, v10

    .line 1424
    move-object v10, v8

    const-string v11, "nick"

    move-object v12, v2

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1425
    move-object v10, v8

    const-string v11, "adminId"

    move-object v12, v3

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1426
    move-object v10, v8

    const-string v11, "playerId"

    move-object v12, v4

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1427
    move-object v10, v8

    const-string v11, "text"

    move-object v12, v5

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1428
    move-object v10, v8

    const-string v11, "time"

    move-object v12, v6

    if-eqz v12, :cond_1

    move-object v12, v6

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v13, 0x0

    if-le v12, v13, :cond_1

    move-object v12, v6

    :goto_1
    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 1429
    move-object v10, v8

    const-string v11, "timestamp"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-virtual {v10, v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v10

    .line 1430
    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "help_player_data"

    move-object v12, v8

    invoke-virtual {v12}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "help_player_pending"

    const/4 v12, 0x1

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1432
    move-object v10, v1

    invoke-direct {v10}, Lgtandroid/universal/JailAlertService;->startHelpTimeout()V

    .line 1434
    :goto_2
    goto :goto_0

    .line 1428
    :cond_1
    move-object v12, v1

    invoke-direct {v12}, Lgtandroid/universal/JailAlertService;->getCurrentTimeMSK()Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v12

    goto :goto_1

    .line 1432
    :catch_0
    move-exception v10

    move-object v8, v10

    .line 1434
    move-object v10, v8

    invoke-virtual {v10}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private saveReportsToPrefs()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1025
    move-object v0, p0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v8, :cond_0

    .line 1041
    :goto_0
    return-void

    .line 1027
    :cond_0
    :try_start_0
    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    move-object v2, v8

    .line 1028
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->currentReports:Ljava/util/List;

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v3, v8

    .line 1037
    :goto_1
    move-object v8, v3

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_1

    .line 1039
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const-string v9, "auto_reports"

    move-object v10, v2

    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1041
    :goto_2
    goto :goto_0

    .line 1028
    :cond_1
    move-object v8, v3

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/ReportData;

    move-object v5, v8

    .line 1029
    new-instance v8, Lorg/json/JSONObject;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    move-object v6, v8

    .line 1030
    move-object v8, v6

    const-string v9, "time"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 1031
    move-object v8, v6

    const-string v9, "nick"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 1032
    move-object v8, v6

    const-string v9, "id"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 1033
    move-object v8, v6

    const-string v9, "text"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    if-eqz v10, :cond_2

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    :goto_3
    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 1034
    move-object v8, v6

    const-string v9, "isAnswered"

    move-object v10, v5

    iget-boolean v10, v10, Lgtandroid/universal/ReportData;->isAnswered:Z

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v8

    .line 1035
    move-object v8, v6

    const-string v9, "sourceTime"

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    if-eqz v10, :cond_3

    move-object v10, v5

    iget-object v10, v10, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    :goto_4
    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 1036
    move-object v8, v6

    const-string v9, "isEvent"

    move-object v10, v5

    iget-boolean v10, v10, Lgtandroid/universal/ReportData;->isEvent:Z

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v8

    .line 1037
    move-object v8, v2

    move-object v9, v6

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v8

    goto/16 :goto_1

    .line 1033
    :cond_2
    const-string v10, ""

    goto :goto_3

    .line 1035
    :cond_3
    const-string v10, ""
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    .line 1039
    :catch_0
    move-exception v8

    move-object v2, v8

    .line 1041
    move-object v8, v2

    invoke-virtual {v8}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method

.method private seenKey(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 20

    .prologue
    .line 263
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object v9, v5

    if-nez v9, :cond_0

    const-string v9, ""

    :goto_0
    move-object v7, v9

    .line 264
    new-instance v9, Ljava/lang/StringBuffer;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object/from16 v19, v10

    move-object/from16 v10, v19

    move-object/from16 v11, v19

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v19, v11

    move-object/from16 v11, v19

    move-object/from16 v12, v19

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v19, v12

    move-object/from16 v12, v19

    move-object/from16 v13, v19

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v19, v14

    move-object/from16 v14, v19

    move-object/from16 v15, v19

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v19, v15

    move-object/from16 v15, v19

    move-object/from16 v16, v19

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v19, v16

    move-object/from16 v16, v19

    move-object/from16 v17, v19

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v17, v1

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, "|"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move-object/from16 v16, v2

    if-nez v16, :cond_1

    const-string v16, ""

    :goto_1
    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, "|"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v3

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, "["

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v4

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "]|"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v7

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    return-object v0

    .line 263
    :cond_0
    move-object v9, v5

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "\\s+"

    const-string v11, " "

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto/16 :goto_0

    .line 264
    :cond_1
    move-object/from16 v16, v2

    goto :goto_1
.end method

.method private shouldIgnoreLine(Ljava/lang/String;)Z
    .locals 7

    .prologue
    .line 141
    move-object v0, p0

    move-object v1, p1

    move-object v5, v1

    if-eqz v5, :cond_0

    move-object v5, v1

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_1

    :cond_0
    const/4 v5, 0x1

    move v0, v5

    .line 236
    :goto_0
    return v0

    .line 142
    :cond_1
    move-object v5, v1

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 144
    move-object v5, v3

    const-string v6, "/acceptgnews"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/4 v5, 0x0

    move v0, v5

    goto :goto_0

    .line 146
    :cond_2
    move-object v5, v3

    const-string v6, "\u0421\u041a\u0418\u0414\u041a\u0418 \u041d\u0410 \u041a\u0415\u0419\u0421\u042b"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_3

    move-object v5, v3

    const-string v6, "\u0413\u041e\u041d\u041a\u0410 \u0417\u0410 \u0412\u042b\u0413\u041e\u0414\u041e\u0419"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_3

    move-object v5, v3

    const-string v6, "\u041b\u0415\u0422\u041d\u0418\u0419 \u0420\u0410\u0417\u0413\u041e\u041d"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_3

    move-object v5, v3

    const-string v6, "\u0417\u043e\u043b\u043e\u0442\u043e\u0439 \u0431\u0438\u043b\u0435\u0442"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_3

    move-object v5, v3

    const-string v6, "\u041e\u0441\u0442\u0430\u043b\u043e\u0441\u044c:"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_4

    .line 151
    :cond_3
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 154
    :cond_4
    move-object v5, v3

    const-string v6, "[\u0410\u0440\u0437\u0430\u043c\u0430\u0441"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_5

    .line 155
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 158
    :cond_5
    const-string v5, "^\\(\\([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+:\\s*.*\\)\\)$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6

    .line 159
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 162
    :cond_6
    const-string v5, "^[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]\\s*\\|\\s*\\{.*?\\}\\s*\u0443\u0440\u043e\u0432\u0435\u043d\u044c$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_7

    .line 163
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 166
    :cond_7
    const-string v5, "(?iu)^[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]\\s*\\|\\s*\u0443\u0440\u043e\u0432\u0435\u043d\u044c\\s*\\d*\\s*$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_8

    .line 167
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 170
    :cond_8
    const-string v5, "(?iu)^(?:\\d{1,2}:\\d{2}\\s+)?[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\[\\d+\\]:?\\s*\\|\\s*\\d+\\s*\u0443\u0440\u043e\u0432\u0435\u043d\u044c.*$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_9

    .line 171
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 174
    :cond_9
    move-object v5, v3

    const-string v6, "<ADM>"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v5, v3

    const-string v6, "[\u0410] "

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v5, v3

    const-string v6, "\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 "

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v5, v3

    const-string v6, "((\u0410)"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v5, v3

    const-string v6, "(("

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v5, v3

    const-string v6, "(( Admin"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    const-string v5, "^\\d{1,2}:\\d{2}\\s*$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_b

    .line 181
    :cond_a
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 184
    :cond_b
    move-object v5, v3

    const-string v6, "[F]"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_c

    move-object v5, v3

    const-string v6, "[R]"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_d

    .line 185
    :cond_c
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 188
    :cond_d
    const-string v5, "^\\{.*\\}\\s*\\([A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\)$"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_e

    .line 189
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 192
    :cond_e
    move-object v5, v3

    const-string v6, "\u0434\u043e\u0441\u0442\u0430\u043b(\u0430)"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_f

    move-object v5, v3

    const-string v6, "\u0438 \u043f\u043e\u043a\u0430\u0437\u0430\u043b(\u0430)"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_f

    .line 193
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 196
    :cond_f
    move-object v5, v3

    const-string v6, "\u0438\u0437\u043c\u0435\u043d\u0438\u043b \u0438\u043c\u044f \u043d\u0430"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_10

    .line 197
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 200
    :cond_10
    const-string v5, "^[A-Za-z\u0410-\u042f\u0430-\u044f0-9_]+\\s+.*"

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->rx(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_11

    move-object v5, v3

    const-string v6, "["

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_11

    .line 201
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 204
    :cond_11
    move-object v5, v3

    const-string v6, "\u043a\u0440\u0438\u043a\u043d\u0443\u043b:"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_12

    .line 205
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 208
    :cond_12
    move-object v5, v3

    const-string v6, "\u043a\u0440\u0438\u043a\u043d\u0443\u043b"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_13

    .line 209
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 212
    :cond_13
    move-object v5, v3

    const-string v6, "\u0410\u0432\u0442\u043e\u0431\u0443\u0441 \u043f\u043e \u043c\u0430\u0440\u0448\u0440\u0443\u0442\u0443"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_14

    .line 213
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 216
    :cond_14
    move-object v5, v3

    const-string v6, "\u043f\u043e\u0441\u0430\u0436\u0435\u043d \u0432 \u0442\u044e\u0440\u044c\u043c\u0443"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_15

    .line 217
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 220
    :cond_15
    move-object v5, v3

    const-string v6, "\u043d\u0430\u0440\u0443\u0447\u043d\u0438\u043a\u0438"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_16

    .line 221
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 224
    :cond_16
    move-object v5, v3

    const-string v6, "\u043e\u0442\u043a\u0440\u044b\u043b(\u0430) \u0434\u0432\u0435\u0440\u044c \u043c\u0430\u0448\u0438\u043d\u044b"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_17

    .line 225
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 228
    :cond_17
    move-object v5, v3

    const-string v6, "\u043f\u043e\u0441\u0430\u0434\u0438\u043b(\u0430) \u0432 \u043c\u0430\u0448\u0438\u043d\u0443"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_18

    .line 229
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 232
    :cond_18
    move-object v5, v3

    const-string v6, "\u0432\u044b\u0442\u0430\u0449\u0438\u043b(\u0430) \u0438\u0437 \u043c\u0430\u0448\u0438\u043d\u044b"

    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_19

    .line 233
    const/4 v5, 0x1

    move v0, v5

    goto/16 :goto_0

    .line 236
    :cond_19
    const/4 v5, 0x0

    move v0, v5

    goto/16 :goto_0
.end method

.method private startAutoFormTimeout()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1343
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_0

    .line 1344
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1347
    :cond_0
    move-object v2, v0

    new-instance v3, Lgtandroid/universal/JailAlertService$100000010;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService$100000010;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    .line 1356
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    const-wide/16 v4, 0x7530

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method

.method private startCleanupTask()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 542
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    new-instance v3, Lgtandroid/universal/JailAlertService$100000006;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService$100000006;-><init>(Lgtandroid/universal/JailAlertService;)V

    const/16 v4, 0x7530

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method

.method private startHelpTimeout()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1439
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_0

    .line 1440
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1442
    :cond_0
    move-object v2, v0

    new-instance v3, Lgtandroid/universal/JailAlertService$100000011;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService$100000011;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    .line 1449
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->helpTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->helpTimeoutRunnable:Ljava/lang/Runnable;

    const-wide/16 v4, 0x7530

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method

.method private startPeriodicCheck()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 571
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    new-instance v3, Lgtandroid/universal/JailAlertService$100000007;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/JailAlertService$100000007;-><init>(Lgtandroid/universal/JailAlertService;)V

    const/16 v4, 0x12c

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method

.method private syncSettingsFromPrefs()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 507
    move-object v0, p0

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v9, :cond_0

    .line 524
    :goto_0
    return-void

    .line 508
    :cond_0
    move-object v9, v0

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "admin_level"

    const/4 v12, 0x0

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v10

    iput v10, v9, Lgtandroid/universal/JailAlertService;->userLevel:I

    .line 509
    move-object v9, v0

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "auto_form_enabled"

    const/4 v12, 0x1

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v9, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    .line 510
    move-object v9, v0

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "help_player_enabled"

    const/4 v12, 0x1

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v9, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    .line 511
    move-object v9, v0

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "floating_menu_enabled"

    const/4 v12, 0x0

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v9, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    .line 513
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "tracking_enabled"

    const/4 v11, 0x0

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    move v2, v9

    .line 514
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "area_x"

    const/4 v11, 0x0

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v9

    move v3, v9

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "area_y"

    const/4 v11, 0x0

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v9

    move v4, v9

    .line 515
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "area_width"

    const/4 v11, 0x0

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v9

    move v5, v9

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "area_height"

    const/4 v11, 0x0

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v9

    move v6, v9

    .line 516
    move v9, v2

    if-eqz v9, :cond_2

    move v9, v5

    const/4 v10, 0x0

    if-eq v9, v10, :cond_1

    move v9, v6

    const/4 v10, 0x0

    if-ne v9, v10, :cond_2

    .line 517
    :cond_1
    const/4 v9, 0x0

    move v2, v9

    .line 519
    :cond_2
    move v9, v2

    if-nez v9, :cond_5

    move-object v9, v0

    iget-boolean v9, v9, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    if-nez v9, :cond_6

    :cond_3
    move v9, v3

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/JailAlertService;->areaX:I

    if-ne v9, v10, :cond_6

    move v9, v4

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/JailAlertService;->areaY:I

    if-ne v9, v10, :cond_6

    move v9, v5

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/JailAlertService;->areaWidth:I

    if-ne v9, v10, :cond_6

    move v9, v6

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/JailAlertService;->areaHeight:I

    if-ne v9, v10, :cond_6

    const/4 v9, 0x0

    :goto_1
    move v7, v9

    .line 520
    move-object v9, v0

    move v10, v2

    iput-boolean v10, v9, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    .line 521
    move-object v9, v0

    move v10, v3

    iput v10, v9, Lgtandroid/universal/JailAlertService;->areaX:I

    move-object v9, v0

    move v10, v4

    iput v10, v9, Lgtandroid/universal/JailAlertService;->areaY:I

    move-object v9, v0

    move v10, v5

    iput v10, v9, Lgtandroid/universal/JailAlertService;->areaWidth:I

    move-object v9, v0

    move v10, v6

    iput v10, v9, Lgtandroid/universal/JailAlertService;->areaHeight:I

    .line 522
    move v9, v7

    if-eqz v9, :cond_4

    .line 523
    move-object v9, v0

    const-string v10, ""

    iput-object v10, v9, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    .line 524
    move-object v9, v0

    const/4 v10, 0x1

    invoke-direct {v9, v10}, Lgtandroid/universal/JailAlertService;->requestScan(Z)V

    :cond_4
    goto/16 :goto_0

    .line 519
    :cond_5
    move-object v9, v0

    iget-boolean v9, v9, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    if-nez v9, :cond_3

    :cond_6
    const/4 v9, 0x1

    goto :goto_1
.end method

.method private textMatchesEventKeyword(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 9

    .prologue
    .line 1079
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v7, v1

    if-eqz v7, :cond_0

    move-object v7, v2

    if-nez v7, :cond_1

    :cond_0
    const/4 v7, 0x0

    move v0, v7

    .line 1084
    :goto_0
    return v0

    .line 1080
    :cond_1
    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 1081
    move-object v7, v2

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 1082
    move-object v7, v5

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_2

    const/4 v7, 0x0

    move v0, v7

    goto :goto_0

    .line 1084
    :cond_2
    move-object v7, v4

    move-object v8, v5

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    move v0, v7

    goto :goto_0
.end method

.method private unregisterAllReceivers()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 529
    move-object v0, p0

    move-object v4, v0

    :try_start_0
    iget-object v4, v4, Lgtandroid/universal/JailAlertService;->removeReportReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v4, :cond_0

    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->removeReportReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 530
    :cond_0
    :goto_0
    move-object v4, v0

    :try_start_1
    iget-object v4, v4, Lgtandroid/universal/JailAlertService;->clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v4, :cond_1

    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 531
    :cond_1
    :goto_1
    move-object v4, v0

    :try_start_2
    iget-object v4, v4, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v4, :cond_2

    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 532
    :cond_2
    :goto_2
    move-object v4, v0

    :try_start_3
    iget-object v4, v4, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v4, :cond_3

    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 533
    :cond_3
    :goto_3
    move-object v4, v0

    :try_start_4
    iget-object v4, v4, Lgtandroid/universal/JailAlertService;->areaSelectedReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v4, :cond_4

    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->areaSelectedReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 534
    :cond_4
    :goto_4
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/content/BroadcastReceiver;

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->removeReportReceiver:Landroid/content/BroadcastReceiver;

    .line 535
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/content/BroadcastReceiver;

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

    .line 536
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/content/BroadcastReceiver;

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    .line 537
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/content/BroadcastReceiver;

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    .line 538
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/content/BroadcastReceiver;

    iput-object v5, v4, Lgtandroid/universal/JailAlertService;->areaSelectedReceiver:Landroid/content/BroadcastReceiver;

    return-void

    .line 529
    :catch_0
    move-exception v4

    move-object v2, v4

    goto :goto_0

    .line 530
    :catch_1
    move-exception v4

    move-object v2, v4

    goto :goto_1

    .line 531
    :catch_2
    move-exception v4

    move-object v2, v4

    goto :goto_2

    .line 532
    :catch_3
    move-exception v4

    move-object v2, v4

    goto :goto_3

    .line 533
    :catch_4
    move-exception v4

    move-object v2, v4

    goto :goto_4
.end method


# virtual methods
.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/accessibility/AccessibilityEvent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1507
    move-object v0, p0

    move-object v1, p1

    move-object v5, v1

    if-nez v5, :cond_0

    .line 1515
    :goto_0
    return-void

    .line 1508
    :cond_0
    move-object v5, v1

    :try_start_0
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v5

    move v3, v5

    .line 1509
    move v5, v3

    const/16 v6, 0x20

    if-ne v5, v6, :cond_2

    .line 1510
    move-object v5, v0

    const/4 v6, 0x1

    invoke-direct {v5, v6}, Lgtandroid/universal/JailAlertService;->requestScan(Z)V

    .line 1515
    :cond_1
    :goto_1
    goto :goto_0

    .line 1511
    :cond_2
    move v5, v3

    const/16 v6, 0x800

    if-ne v5, v6, :cond_1

    .line 1512
    move-object v5, v0

    const/4 v6, 0x0

    invoke-direct {v5, v6}, Lgtandroid/universal/JailAlertService;->requestScan(Z)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v5

    move-object v3, v5

    .line 1515
    move-object v5, v0

    const-string v6, "AutoReport_event"

    move-object v7, v3

    invoke-static {v5, v6, v7}, Lgtandroid/universal/AppLogger;->logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_1
.end method

.method public onDestroy()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1526
    move-object v0, p0

    move-object v2, v0

    invoke-super {v2}, Landroid/app/Service;->onDestroy()V

    .line 1527
    const/4 v2, 0x0

    sput-boolean v2, Lgtandroid/universal/JailAlertService;->isRunning:Z

    .line 1529
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    if-eqz v2, :cond_0

    .line 1530
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    invoke-virtual {v2}, Landroid/os/HandlerThread;->quit()Z

    move-result v2

    .line 1531
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Landroid/os/HandlerThread;

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    .line 1532
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Landroid/os/Handler;

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->scanHandler:Landroid/os/Handler;

    .line 1535
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_1

    .line 1536
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1537
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Ljava/lang/Runnable;

    iput-object v3, v2, Lgtandroid/universal/JailAlertService;->autoFormTimeoutRunnable:Ljava/lang/Runnable;

    .line 1540
    :cond_1
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    if-eqz v2, :cond_2

    .line 1541
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    const/4 v3, 0x0

    check-cast v3, Ljava/lang/Object;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 1543
    :cond_2
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/JailAlertService;->unregisterAllReceivers()V

    .line 1544
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/JailAlertService;->clearAutoForm()V

    .line 1545
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/JailAlertService;->clearHelpPlayer()V

    return-void
.end method

.method public onInterrupt()V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onServiceConnected()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 343
    move-object v0, p0

    move-object v5, v0

    const-string v6, "JailAlertService"

    invoke-static {v5, v6}, Lgtandroid/universal/AppLogger;->installCrashHandler(Landroid/content/Context;Ljava/lang/String;)V

    .line 344
    move-object v5, v0

    invoke-super {v5}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V

    .line 345
    const/4 v5, 0x1

    sput-boolean v5, Lgtandroid/universal/JailAlertService;->isRunning:Z

    .line 347
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    if-nez v5, :cond_2

    .line 348
    move-object v5, v0

    new-instance v6, Landroid/os/Handler;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Landroid/os/Handler;-><init>()V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    .line 352
    :goto_0
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->unregisterAllReceivers()V

    .line 353
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->scanInFlight:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 354
    move-object v5, v0

    const-string v6, ""

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->lastCheckedText:Ljava/lang/String;

    .line 356
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 358
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "admin_level"

    const/4 v8, 0x0

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v6

    iput v6, v5, Lgtandroid/universal/JailAlertService;->userLevel:I

    .line 359
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "auto_form_enabled"

    const/4 v8, 0x1

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    iput-boolean v6, v5, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    .line 360
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "help_player_enabled"

    const/4 v8, 0x1

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    iput-boolean v6, v5, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    .line 361
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "floating_menu_enabled"

    const/4 v8, 0x0

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    iput-boolean v6, v5, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    .line 363
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->loadAreaSettings()V

    .line 365
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "hot_scan_packages"

    const/4 v7, 0x0

    check-cast v7, Ljava/util/Set;

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v5

    move-object v2, v5

    .line 366
    move-object v5, v2

    if-eqz v5, :cond_0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->hotPackages:Ljava/util/Set;

    move-object v6, v2

    invoke-interface {v5, v6}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    move-result v5

    .line 367
    :cond_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    if-nez v5, :cond_1

    .line 368
    move-object v5, v0

    new-instance v6, Landroid/os/HandlerThread;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    const-string v8, "AutoReportScan"

    invoke-direct {v7, v8}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    .line 369
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    invoke-virtual {v5}, Ljava/lang/Thread;->start()V

    .line 370
    move-object v5, v0

    new-instance v6, Landroid/os/Handler;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService;->scanThread:Landroid/os/HandlerThread;

    invoke-virtual {v8}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v8

    invoke-direct {v7, v8}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->scanHandler:Landroid/os/Handler;

    .line 373
    :cond_1
    new-instance v5, Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    invoke-direct {v6}, Landroid/accessibilityservice/AccessibilityServiceInfo;-><init>()V

    move-object v3, v5

    .line 375
    move-object v5, v3

    const/16 v6, 0x820

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->eventTypes:I

    .line 377
    move-object v5, v3

    const/16 v6, 0x10

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->feedbackType:I

    .line 378
    move-object v5, v3

    const/16 v6, 0x12

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    .line 380
    move-object v5, v3

    const/16 v6, 0x64

    int-to-long v6, v6

    iput-wide v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->notificationTimeout:J

    .line 381
    move-object v5, v0

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    .line 383
    move-object v5, v0

    new-instance v6, Lgtandroid/universal/JailAlertService$100000000;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService$100000000;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->removeReportReceiver:Landroid/content/BroadcastReceiver;

    .line 394
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->removeReportReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "REMOVE_REPORT"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 396
    move-object v5, v0

    new-instance v6, Lgtandroid/universal/JailAlertService$100000001;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService$100000001;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

    .line 402
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->clearAutoFormReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "CLEAR_AUTO_FORM"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 404
    move-object v5, v0

    new-instance v6, Lgtandroid/universal/JailAlertService$100000002;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService$100000002;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    .line 423
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "AUTO_FORM_ACCEPTED"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 424
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->autoFormActionReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "AUTO_FORM_DECLINED"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 426
    move-object v5, v0

    new-instance v6, Lgtandroid/universal/JailAlertService$100000003;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService$100000003;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    .line 433
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "HELP_PLAYER_ACCEPTED"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 434
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "HELP_PLAYER_DECLINED"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 435
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->helpPlayerActionReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "CLEAR_HELP_PLAYER"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 437
    move-object v5, v0

    new-instance v6, Lgtandroid/universal/JailAlertService$100000004;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/JailAlertService$100000004;-><init>(Lgtandroid/universal/JailAlertService;)V

    iput-object v6, v5, Lgtandroid/universal/JailAlertService;->areaSelectedReceiver:Landroid/content/BroadcastReceiver;

    .line 446
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/JailAlertService;->areaSelectedReceiver:Landroid/content/BroadcastReceiver;

    new-instance v7, Landroid/content/IntentFilter;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const-string v9, "AREA_SELECTED"

    invoke-direct {v8, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    .line 448
    const-string v5, "AutoReport"

    const-string v6, "JailAlertService \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d!"

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 449
    const-string v5, "AutoReport"

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "trackingEnabled = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->trackingEnabled:Z

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 450
    const-string v5, "AutoReport"

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "floatingMenuEnabled = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 451
    const-string v5, "AutoReport"

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "autoFormEnabled = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 452
    const-string v5, "AutoReport"

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "helpPlayerEnabled = "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-boolean v7, v7, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 454
    const-string v5, "AutoReport"

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "AutoReporter \u0437\u0430\u043f\u0443\u0449\u0435\u043d (\u0423\u0440\u043e\u0432\u0435\u043d\u044c "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/JailAlertService;->userLevel:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    const-string v7, ")"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 456
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->startPeriodicCheck()V

    .line 457
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->startCleanupTask()V

    .line 459
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/JailAlertService;->listenForLevelChanges()V

    return-void

    .line 350
    :cond_2
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/JailAlertService;->handler:Landroid/os/Handler;

    const/4 v6, 0x0

    check-cast v6, Ljava/lang/Object;

    invoke-virtual {v5, v6}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    goto/16 :goto_0
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 10
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 464
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 466
    move-object v7, v1

    if-eqz v7, :cond_3

    .line 467
    move-object v7, v1

    const-string v8, "autoform"

    invoke-virtual {v7, v8}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_0

    .line 468
    move-object v7, v1

    const-string v8, "autoform"

    const/4 v9, 0x1

    invoke-virtual {v7, v8, v9}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v7

    move v5, v7

    .line 469
    move-object v7, v0

    move v8, v5

    invoke-virtual {v7, v8}, Lgtandroid/universal/JailAlertService;->setAutoFormEnabled(Z)V

    .line 471
    :cond_0
    move-object v7, v1

    const-string v8, "helpplayer"

    invoke-virtual {v7, v8}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 472
    move-object v7, v1

    const-string v8, "helpplayer"

    const/4 v9, 0x1

    invoke-virtual {v7, v8, v9}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v7

    move v5, v7

    .line 473
    move-object v7, v0

    move v8, v5

    invoke-virtual {v7, v8}, Lgtandroid/universal/JailAlertService;->setHelpPlayerEnabled(Z)V

    .line 475
    :cond_1
    move-object v7, v1

    const-string v8, "floatingmenu"

    invoke-virtual {v7, v8}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_2

    .line 476
    move-object v7, v1

    const-string v8, "floatingmenu"

    const/4 v9, 0x0

    invoke-virtual {v7, v8, v9}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v7

    move v5, v7

    .line 477
    move-object v7, v0

    move v8, v5

    invoke-virtual {v7, v8}, Lgtandroid/universal/JailAlertService;->setFloatingMenuEnabled(Z)V

    .line 479
    :cond_2
    move-object v7, v1

    const-string v8, "level"

    invoke-virtual {v7, v8}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    .line 480
    move-object v7, v1

    const-string v8, "level"

    const/4 v9, 0x0

    invoke-virtual {v7, v8, v9}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    move v5, v7

    .line 481
    move-object v7, v0

    move v8, v5

    iput v8, v7, Lgtandroid/universal/JailAlertService;->userLevel:I

    .line 482
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v7, :cond_3

    .line 483
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "admin_level"

    move v9, v5

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 487
    :cond_3
    const/4 v7, 0x1

    move v0, v7

    return v0
.end method

.method public setAutoFormEnabled(Z)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .prologue
    .line 1493
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v3, :cond_0

    .line 1494
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 1497
    :cond_0
    move-object v3, v0

    move v4, v1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->autoFormEnabled:Z

    .line 1498
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v3, :cond_1

    .line 1499
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "auto_form_enabled"

    move v5, v1

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1501
    :cond_1
    move-object v3, v0

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "\u0410\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move v5, v1

    if-eqz v5, :cond_2

    const-string v5, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    const-string v5, "\u0412\u044b\u043a\u043b"

    goto :goto_0
.end method

.method public setFloatingMenuEnabled(Z)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .prologue
    .line 1478
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v3, :cond_0

    .line 1479
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 1482
    :cond_0
    move-object v3, v0

    move v4, v1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->floatingMenuEnabled:Z

    .line 1483
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v3, :cond_1

    .line 1484
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "floating_menu_enabled"

    move v5, v1

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1487
    :cond_1
    const-string v3, "AutoReport"

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "setFloatingMenuEnabled: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move v5, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lgtandroid/universal/JailAlertService;->dbg(Ljava/lang/String;Ljava/lang/String;)V

    .line 1489
    move-object v3, v0

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "\u0410\u0432\u0442\u043e\u0440\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move v5, v1

    if-eqz v5, :cond_2

    const-string v5, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    const-string v5, "\u0412\u044b\u043a\u043b"

    goto :goto_0
.end method

.method public setHelpPlayerEnabled(Z)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .prologue
    .line 1464
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-nez v3, :cond_0

    .line 1465
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->initPrefs()V

    .line 1467
    :cond_0
    move-object v3, v0

    move v4, v1

    iput-boolean v4, v3, Lgtandroid/universal/JailAlertService;->helpPlayerEnabled:Z

    .line 1468
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    if-eqz v3, :cond_1

    .line 1469
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "help_player_enabled"

    move v5, v1

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1471
    :cond_1
    move v3, v1

    if-nez v3, :cond_2

    .line 1472
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/JailAlertService;->clearHelpPlayer()V

    .line 1474
    :cond_2
    move-object v3, v0

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "\u041f\u043e\u043c\u043e\u0449\u044c \u0438\u0433\u0440\u043e\u043a\u0443: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move v5, v1

    if-eqz v5, :cond_3

    const-string v5, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    return-void

    :cond_3
    const-string v5, "\u0412\u044b\u043a\u043b"

    goto :goto_0
.end method
