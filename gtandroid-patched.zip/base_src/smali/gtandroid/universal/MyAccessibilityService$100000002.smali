.class Lgtandroid/universal/MyAccessibilityService$100000002;
.super Ljava/lang/Object;
.source "MyAccessibilityService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MyAccessibilityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final val$svc:Lgtandroid/universal/MyAccessibilityService;

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MyAccessibilityService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MyAccessibilityService$100000002;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MyAccessibilityService$100000002;->val$text:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 136
    move-object v0, p0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MyAccessibilityService$100000002;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    invoke-virtual {v6}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v2, v6

    .line 137
    move-object v6, v2

    if-nez v6, :cond_0

    .line 152
    :goto_0
    return-void

    .line 139
    :cond_0
    move-object v6, v2

    invoke-static {v6}, Lgtandroid/universal/MyAccessibilityService;->access$1000004(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v3, v6

    .line 141
    move-object v6, v3

    if-eqz v6, :cond_1

    .line 142
    move-object v6, v3

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result v6

    .line 145
    const/16 v6, 0x32

    int-to-long v6, v6

    :try_start_0
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 148
    :goto_1
    new-instance v6, Landroid/os/Bundle;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    move-object v4, v6

    .line 149
    move-object v6, v4

    const-string v7, "ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE"

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MyAccessibilityService$100000002;->val$text:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "\n"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v7, v8}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 150
    move-object v6, v3

    const/high16 v7, 0x200000

    move-object v8, v4

    invoke-virtual {v6, v7, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z

    move-result v6

    .line 152
    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_1
    goto :goto_0

    .line 145
    :catch_0
    move-exception v6

    move-object v4, v6

    goto :goto_1
.end method
