.class public Lgtandroid/universal/NeonUi$Icon;
.super Landroid/graphics/drawable/Drawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Icon"
.end annotation


# instance fields
.field private final glyphColor:I

.field private final p:Landroid/graphics/Paint;

.field private final path:Landroid/graphics/Path;

.field private final rf:Landroid/graphics/RectF;

.field private final ringColor:I

.field private final sizePx:I

.field private final type:I


# direct methods
.method public constructor <init>(II)V
    .locals 9

    .prologue
    .line 340
    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, v0

    move v5, v1

    move v6, v2

    const v7, -0x66000001

    const/4 v8, -0x1

    invoke-direct {v4, v5, v6, v7, v8}, Lgtandroid/universal/NeonUi$Icon;-><init>(IIII)V

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 11

    .prologue
    .line 343
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v6, v0

    invoke-direct {v6}, Landroid/graphics/drawable/Drawable;-><init>()V

    move-object v6, v0

    new-instance v7, Landroid/graphics/Paint;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v6, v0

    new-instance v7, Landroid/graphics/RectF;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Landroid/graphics/RectF;-><init>()V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    move-object v6, v0

    new-instance v7, Landroid/graphics/Path;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Landroid/graphics/Path;-><init>()V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    .line 344
    move-object v6, v0

    move v7, v1

    iput v7, v6, Lgtandroid/universal/NeonUi$Icon;->type:I

    .line 345
    move-object v6, v0

    move v7, v2

    iput v7, v6, Lgtandroid/universal/NeonUi$Icon;->sizePx:I

    .line 346
    move-object v6, v0

    move v7, v3

    iput v7, v6, Lgtandroid/universal/NeonUi$Icon;->ringColor:I

    .line 347
    move-object v6, v0

    move v7, v4

    iput v7, v6, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 355
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v8, v0

    invoke-virtual {v8}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v8

    move-object v3, v8

    .line 356
    move-object v8, v3

    invoke-virtual {v8}, Landroid/graphics/Rect;->width()I

    move-result v8

    move-object v9, v3

    invoke-virtual {v9}, Landroid/graphics/Rect;->height()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v8

    int-to-float v8, v8

    move v4, v8

    .line 357
    move v8, v4

    const/4 v9, 0x0

    cmpg-float v8, v8, v9

    if-gtz v8, :cond_0

    .line 552
    :goto_0
    return-void

    .line 358
    :cond_0
    move-object v8, v3

    invoke-virtual {v8}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v8

    move v5, v8

    .line 359
    move-object v8, v3

    invoke-virtual {v8}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v8

    move v6, v8

    .line 361
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 362
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x59000000

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 363
    move-object v8, v1

    move v9, v5

    move v10, v6

    move v11, v4

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v11, v12

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 364
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 365
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move v9, v4

    const v10, 0x3d8f5c29    # 0.07f

    mul-float/2addr v9, v10

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 366
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->ringColor:I

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 367
    move-object v8, v1

    move v9, v5

    move v10, v6

    move v11, v4

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v11, v12

    move v12, v4

    const v13, 0x3cf5c28f    # 0.03f

    mul-float/2addr v12, v13

    sub-float/2addr v11, v12

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 369
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->save()I

    move-result v8

    .line 370
    move-object v8, v1

    move v9, v5

    move v10, v4

    const/high16 v11, 0x40000000    # 2.0f

    div-float/2addr v10, v11

    sub-float/2addr v9, v10

    move v10, v6

    move v11, v4

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v11, v12

    sub-float/2addr v10, v11

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->translate(FF)V

    .line 371
    move-object v8, v1

    move v9, v4

    const/high16 v10, 0x41c00000    # 24.0f

    div-float/2addr v9, v10

    move v10, v4

    const/high16 v11, 0x41c00000    # 24.0f

    div-float/2addr v10, v11

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->scale(FF)V

    .line 373
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 374
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 375
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 376
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 377
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x4019999a    # 2.4f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 378
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->reset()V

    .line 380
    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/NeonUi$Icon;->type:I

    packed-switch v8, :pswitch_data_0

    .line 552
    :goto_1
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->restore()V

    goto/16 :goto_0

    .line 382
    :pswitch_0
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x40400000    # 3.0f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 383
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x40d9999a    # 6.8f

    const v10, 0x4149999a    # 12.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 384
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x4129999a    # 10.6f

    const v10, 0x41833333    # 16.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 385
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x418b3333    # 17.4f

    const v10, 0x41033333    # 8.2f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 386
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 387
    goto :goto_1

    .line 390
    :pswitch_1
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x40400000    # 3.0f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 391
    move-object v8, v1

    const v9, 0x40f9999a    # 7.8f

    const v10, 0x40f9999a    # 7.8f

    const v11, 0x4181999a    # 16.2f

    const v12, 0x4181999a    # 16.2f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 392
    move-object v8, v1

    const v9, 0x4181999a    # 16.2f

    const v10, 0x40f9999a    # 7.8f

    const v11, 0x40f9999a    # 7.8f

    const v12, 0x4181999a    # 16.2f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 393
    goto :goto_1

    .line 396
    :pswitch_2
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 397
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x40c00000    # 6.0f

    const/high16 v10, 0x41200000    # 10.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 398
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x41133333    # 9.2f

    const/high16 v10, 0x41200000    # 10.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 399
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41500000    # 13.0f

    const v10, 0x40d33333    # 6.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 400
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41500000    # 13.0f

    const v10, 0x418b3333    # 17.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 401
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x41133333    # 9.2f

    const/high16 v10, 0x41600000    # 14.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 402
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x40c00000    # 6.0f

    const/high16 v10, 0x41600000    # 14.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 403
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 404
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 405
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 406
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x3fe66666    # 1.8f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 407
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x41180000    # 9.5f

    const v10, 0x41033333    # 8.2f

    const/high16 v11, 0x41800000    # 16.0f

    const v12, 0x417ccccd    # 15.8f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 408
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, -0x3da40000    # -55.0f

    const/high16 v11, 0x42dc0000    # 110.0f

    const/4 v12, 0x0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 409
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x41000000    # 8.0f

    const/high16 v10, 0x40b00000    # 5.5f

    const/high16 v11, 0x41a00000    # 20.0f

    const/high16 v12, 0x41940000    # 18.5f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 410
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, -0x3db80000    # -50.0f

    const/high16 v11, 0x42c80000    # 100.0f

    const/4 v12, 0x0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 411
    goto/16 :goto_1

    .line 414
    :pswitch_3
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 415
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40b00000    # 5.5f

    const/high16 v10, 0x40c00000    # 6.0f

    const/high16 v11, 0x41940000    # 18.5f

    const/high16 v12, 0x41780000    # 15.5f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 416
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x40400000    # 3.0f

    const/high16 v11, 0x40400000    # 3.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 417
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41100000    # 9.0f

    const/high16 v10, 0x41700000    # 15.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 418
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41100000    # 9.0f

    const/high16 v10, 0x41980000    # 19.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 419
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41500000    # 13.0f

    const/high16 v10, 0x41700000    # 15.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 420
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 421
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 422
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, -0x56000000

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 423
    move-object v8, v1

    const/high16 v9, 0x41180000    # 9.5f

    const v10, 0x412ccccd    # 10.8f

    const v11, 0x3f8ccccd    # 1.1f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 424
    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const v10, 0x412ccccd    # 10.8f

    const v11, 0x3f8ccccd    # 1.1f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 425
    move-object v8, v1

    const/high16 v9, 0x41680000    # 14.5f

    const v10, 0x412ccccd    # 10.8f

    const v11, 0x3f8ccccd    # 1.1f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 426
    goto/16 :goto_1

    .line 429
    :pswitch_4
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->save()I

    move-result v8

    .line 430
    move-object v8, v1

    const/high16 v9, -0x3dcc0000    # -45.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41400000    # 12.0f

    invoke-virtual {v8, v9, v10, v11}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 431
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x40266666    # 2.6f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 432
    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41200000    # 10.0f

    const/high16 v11, 0x41400000    # 12.0f

    const/high16 v12, 0x41980000    # 19.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 433
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 434
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40d00000    # 6.5f

    const/high16 v10, 0x40b00000    # 5.5f

    const/high16 v11, 0x418c0000    # 17.5f

    const/high16 v12, 0x41280000    # 10.5f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 435
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v10, 0x3f99999a    # 1.2f

    const v11, 0x3f99999a    # 1.2f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 436
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->restore()V

    .line 437
    goto/16 :goto_1

    .line 440
    :pswitch_5
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41400000    # 12.0f

    const v10, 0x40a66666    # 5.2f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 441
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41900000    # 18.0f

    const v10, 0x40f33333    # 7.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 442
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41900000    # 18.0f

    const v10, 0x41466666    # 12.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 443
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41900000    # 18.0f

    const v10, 0x4179999a    # 15.6f

    const v11, 0x41733333    # 15.2f

    const v12, 0x418e6666    # 17.8f

    const/high16 v13, 0x41400000    # 12.0f

    const v14, 0x41966666    # 18.8f

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 444
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x410ccccd    # 8.8f

    const v10, 0x418e6666    # 17.8f

    const/high16 v11, 0x40c00000    # 6.0f

    const v12, 0x4179999a    # 15.6f

    const/high16 v13, 0x40c00000    # 6.0f

    const v14, 0x41466666    # 12.4f

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 445
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x40c00000    # 6.0f

    const v10, 0x40f33333    # 7.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 446
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 447
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 448
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    const/16 v10, 0x55

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 449
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 450
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 451
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 452
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x3ff33333    # 1.9f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 453
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 454
    goto/16 :goto_1

    .line 457
    :pswitch_6
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 458
    move-object v8, v1

    const v9, 0x41166666    # 9.4f

    const v10, 0x4119999a    # 9.6f

    const v11, 0x402ccccd    # 2.7f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 459
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v9, 0x40933333    # 4.6f

    const v10, 0x4159999a    # 13.6f

    const v11, 0x41633333    # 14.2f

    const v12, 0x41accccd    # 21.6f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 460
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x43340000    # 180.0f

    const/high16 v11, 0x43340000    # 180.0f

    const/4 v12, 0x1

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 461
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    const/16 v10, 0xcc

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 462
    move-object v8, v1

    const v9, 0x41766666    # 15.4f

    const v10, 0x41266666    # 10.4f

    const v11, 0x40133333    # 2.3f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 463
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v9, 0x41366666    # 11.4f

    const v10, 0x41633333    # 14.2f

    const v11, 0x419ccccd    # 19.6f

    const v12, 0x41a9999a    # 21.2f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 464
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x43340000    # 180.0f

    const/high16 v11, 0x43340000    # 180.0f

    const/4 v12, 0x1

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 465
    goto/16 :goto_1

    .line 468
    :pswitch_7
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 469
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v9, 0x4099999a    # 4.8f

    const/high16 v10, 0x41380000    # 11.5f

    const v11, 0x4199999a    # 19.2f

    const v12, 0x4184cccd    # 16.6f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 470
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v10, 0x400ccccd    # 2.2f

    const v11, 0x400ccccd    # 2.2f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 471
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x40f9999a    # 7.8f

    const v10, 0x413ccccd    # 11.8f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 472
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x411ccccd    # 9.8f

    const v10, 0x40f9999a    # 7.8f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 473
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x41633333    # 14.2f

    const v10, 0x40f9999a    # 7.8f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 474
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x4181999a    # 16.2f

    const v10, 0x413ccccd    # 11.8f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 475
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 476
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 477
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, -0xe5ddc8

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 478
    move-object v8, v1

    const v9, 0x41066666    # 8.4f

    const v10, 0x41866666    # 16.8f

    const v11, 0x40133333    # 2.3f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 479
    move-object v8, v1

    const v9, 0x4179999a    # 15.6f

    const v10, 0x41866666    # 16.8f

    const v11, 0x40133333    # 2.3f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 480
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Icon;->glyphColor:I

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 481
    move-object v8, v1

    const v9, 0x41066666    # 8.4f

    const v10, 0x41866666    # 16.8f

    const/high16 v11, 0x3f800000    # 1.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 482
    move-object v8, v1

    const v9, 0x4179999a    # 15.6f

    const v10, 0x41866666    # 16.8f

    const/high16 v11, 0x3f800000    # 1.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 483
    goto/16 :goto_1

    .line 486
    :pswitch_8
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 487
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x40000000    # 2.0f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 488
    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const v10, 0x41166666    # 9.4f

    const v11, 0x40533333    # 3.3f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 489
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v9, 0x40b33333    # 5.6f

    const v10, 0x41633333    # 14.2f

    const v11, 0x41933333    # 18.4f

    const v12, 0x41c33333    # 24.4f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 490
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x43480000    # 200.0f

    const/high16 v11, 0x430c0000    # 140.0f

    const/4 v12, 0x0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 491
    goto/16 :goto_1

    .line 494
    :pswitch_9
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 495
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x40600000    # 3.5f

    const v10, 0x41466666    # 12.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 496
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x41a1999a    # 20.2f

    const v10, 0x40866666    # 4.2f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 497
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x4169999a    # 14.6f

    const/high16 v10, 0x41a40000    # 20.5f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 498
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41300000    # 11.0f

    const v10, 0x4154cccd    # 13.3f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 499
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 500
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 501
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 502
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x3fcccccd    # 1.6f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 503
    move-object v8, v1

    const/high16 v9, 0x41300000    # 11.0f

    const v10, 0x4154cccd    # 13.3f

    const v11, 0x41a1999a    # 20.2f

    const v12, 0x40866666    # 4.2f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 504
    goto/16 :goto_1

    .line 507
    :pswitch_a
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 508
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x3fe66666    # 1.8f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 509
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40d00000    # 6.5f

    const/high16 v10, 0x41000000    # 8.0f

    const/high16 v11, 0x418c0000    # 17.5f

    const/high16 v12, 0x41a00000    # 20.0f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 510
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x3fc00000    # 1.5f

    const/high16 v11, 0x3fc00000    # 1.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 511
    move-object v8, v1

    const/high16 v9, 0x40900000    # 4.5f

    const/high16 v10, 0x41000000    # 8.0f

    const/high16 v11, 0x419c0000    # 19.5f

    const/high16 v12, 0x41000000    # 8.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 512
    move-object v8, v1

    const/high16 v9, 0x41180000    # 9.5f

    const/high16 v10, 0x40a00000    # 5.0f

    const/high16 v11, 0x41680000    # 14.5f

    const/high16 v12, 0x40a00000    # 5.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 513
    move-object v8, v1

    const v9, 0x411ccccd    # 9.8f

    const/high16 v10, 0x41300000    # 11.0f

    const v11, 0x411ccccd    # 9.8f

    const/high16 v12, 0x41880000    # 17.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 514
    move-object v8, v1

    const v9, 0x41633333    # 14.2f

    const/high16 v10, 0x41300000    # 11.0f

    const v11, 0x41633333    # 14.2f

    const/high16 v12, 0x41880000    # 17.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 515
    goto/16 :goto_1

    .line 518
    :pswitch_b
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 519
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x3fe66666    # 1.8f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 520
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40900000    # 4.5f

    const/high16 v10, 0x40900000    # 4.5f

    const/high16 v11, 0x419c0000    # 19.5f

    const/high16 v12, 0x419c0000    # 19.5f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 521
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/4 v10, 0x0

    const/high16 v11, 0x43b40000    # 360.0f

    const/4 v12, 0x0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 522
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const/high16 v9, 0x40000000    # 2.0f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 523
    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41400000    # 12.0f

    const v12, 0x40e66666    # 7.2f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 524
    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    const v11, 0x4179999a    # 15.6f

    const v12, 0x4159999a    # 13.6f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 525
    goto/16 :goto_1

    .line 528
    :pswitch_c
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 529
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x40accccd    # 5.4f

    const v10, 0x4184cccd    # 16.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 530
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x408ccccd    # 4.4f

    const v10, 0x41066666    # 8.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 531
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x41133333    # 9.2f

    const/high16 v10, 0x41400000    # 12.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 532
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const/high16 v9, 0x41400000    # 12.0f

    const v10, 0x40cccccd    # 6.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 533
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x416ccccd    # 14.8f

    const/high16 v10, 0x41400000    # 12.0f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 534
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x419ccccd    # 19.6f

    const v10, 0x41066666    # 8.4f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 535
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    const v9, 0x4194cccd    # 18.6f

    const v10, 0x4184cccd    # 16.6f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 536
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    invoke-virtual {v8}, Landroid/graphics/Path;->close()V

    .line 537
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->path:Landroid/graphics/Path;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 538
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const v9, 0x40accccd    # 5.4f

    const v10, 0x418ccccd    # 17.6f

    const v11, 0x4194cccd    # 18.6f

    const v12, 0x419e6666    # 19.8f

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/RectF;->set(FFFF)V

    .line 539
    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Icon;->rf:Landroid/graphics/RectF;

    const/high16 v10, 0x3f800000    # 1.0f

    const/high16 v11, 0x3f800000    # 1.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 540
    goto/16 :goto_1

    .line 543
    :pswitch_d
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    const v9, 0x40266666    # 2.6f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 544
    move-object v8, v1

    const/high16 v9, 0x418c0000    # 17.5f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x40e00000    # 7.0f

    const/high16 v12, 0x41400000    # 12.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 545
    move-object v8, v1

    const/high16 v9, 0x41380000    # 11.5f

    const v10, 0x40eccccd    # 7.4f

    const/high16 v11, 0x40e00000    # 7.0f

    const/high16 v12, 0x41400000    # 12.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 546
    move-object v8, v1

    const/high16 v9, 0x41380000    # 11.5f

    const v10, 0x4184cccd    # 16.6f

    const/high16 v11, 0x40e00000    # 7.0f

    const/high16 v12, 0x41400000    # 12.0f

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/NeonUi$Icon;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 547
    goto/16 :goto_1

    .line 380
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_8
        :pswitch_9
        :pswitch_a
    .end packed-switch
.end method

.method public getIntrinsicHeight()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 351
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/NeonUi$Icon;->sizePx:I

    move v0, v2

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 350
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/NeonUi$Icon;->sizePx:I

    move v0, v2

    return v0
.end method

.method public getOpacity()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 557
    move-object v0, p0

    const/4 v2, -0x3

    move v0, v2

    return v0
.end method

.method public setAlpha(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/ColorFilter;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method
