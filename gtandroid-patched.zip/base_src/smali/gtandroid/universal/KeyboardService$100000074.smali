.class Lgtandroid/universal/KeyboardService$100000074;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000074"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$attempt:I


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;I)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000074;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/KeyboardService$100000074;->val$attempt:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000074;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000074;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3158
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000074;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/KeyboardService$100000074;->val$attempt:I

    const/4 v4, 0x1

    add-int/lit8 v3, v3, 0x1

    invoke-static {v2, v3}, Lgtandroid/universal/KeyboardService;->access$1000260(Lgtandroid/universal/KeyboardService;I)V

    return-void
.end method
