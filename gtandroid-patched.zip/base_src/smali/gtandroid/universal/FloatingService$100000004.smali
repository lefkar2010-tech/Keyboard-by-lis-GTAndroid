.class Lgtandroid/universal/FloatingService$100000004;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000004"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/FloatingService$100000004;->this$0:Lgtandroid/universal/FloatingService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000004;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000004;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 281
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService$100000004;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v2}, Lgtandroid/universal/FloatingService;->access$1000039(Lgtandroid/universal/FloatingService;)V

    .line 282
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService$100000004;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v2}, Lgtandroid/universal/FloatingService;->access$L1000035(Lgtandroid/universal/FloatingService;)Landroid/os/Handler;

    move-result-object v2

    move-object v3, v0

    const/16 v4, 0x3e8

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method
