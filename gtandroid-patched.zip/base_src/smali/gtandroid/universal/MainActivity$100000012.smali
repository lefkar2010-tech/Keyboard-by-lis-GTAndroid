.class Lgtandroid/universal/MainActivity$100000012;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000012"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/MainActivity$100000012$100000011;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MainActivity$100000012;->this$0:Lgtandroid/universal/MainActivity;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000012;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000012;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 660
    move-object v0, p0

    move-object v5, v0

    :try_start_0
    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000012;->this$0:Lgtandroid/universal/MainActivity;

    const-string v6, "https://www.dropbox.com/scl/fi/09ruiljtbntgf9rgvhvq9/ads.json?rlkey=0w8aip1kjoyv37nt8cb02q1pc&st=yp4oxh66&dl=1"

    invoke-static {v5, v6}, Lgtandroid/universal/MainActivity;->access$1000056(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v2, v5

    .line 661
    move-object v5, v2

    if-eqz v5, :cond_0

    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_0

    .line 662
    new-instance v5, Lorg/json/JSONArray;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v2

    invoke-direct {v6, v7}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 663
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000012;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v6, Lgtandroid/universal/MainActivity$100000012$100000011;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    move-object v9, v3

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/MainActivity$100000012$100000011;-><init>(Lgtandroid/universal/MainActivity$100000012;Lorg/json/JSONArray;)V

    invoke-virtual {v5, v6}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 671
    :cond_0
    :goto_0
    return-void

    .line 663
    :catch_0
    move-exception v5

    move-object v2, v5

    .line 671
    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_0
.end method
