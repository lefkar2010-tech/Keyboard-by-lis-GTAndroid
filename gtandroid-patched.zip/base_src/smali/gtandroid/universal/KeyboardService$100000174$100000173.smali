.class Lgtandroid/universal/KeyboardService$100000174$100000173;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000174;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000173"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000174;

.field private final val$armed:[Z

.field private final val$btnClear:Landroid/widget/Button;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000174;[ZLandroid/widget/Button;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174$100000173;->this$0:Lgtandroid/universal/KeyboardService$100000174;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174$100000173;->val$armed:[Z

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000174$100000173;->val$btnClear:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000174$100000173;)Lgtandroid/universal/KeyboardService$100000174;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000174$100000173;->this$0:Lgtandroid/universal/KeyboardService$100000174;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6052
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000174$100000173;->val$armed:[Z

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-boolean v4, v2, v3

    .line 6053
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000174$100000173;->val$btnClear:Landroid/widget/Button;

    const-string v3, "\ud83d\uddd1"

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 6054
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000174$100000173;->val$btnClear:Landroid/widget/Button;

    const v3, -0x473b2a

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method
