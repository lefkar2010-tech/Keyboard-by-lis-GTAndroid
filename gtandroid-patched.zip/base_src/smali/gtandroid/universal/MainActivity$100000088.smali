.class Lgtandroid/universal/MainActivity$100000088;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000088"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MainActivity$100000088;->this$0:Lgtandroid/universal/MainActivity;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000088;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000088;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3471
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000088;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v4}, Lgtandroid/universal/AppLogger;->clear(Landroid/content/Context;)V

    .line 3472
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000088;->this$0:Lgtandroid/universal/MainActivity;

    const-string v5, "\u041b\u043e\u0433 \u043e\u0447\u0438\u0449\u0435\u043d"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    return-void
.end method
