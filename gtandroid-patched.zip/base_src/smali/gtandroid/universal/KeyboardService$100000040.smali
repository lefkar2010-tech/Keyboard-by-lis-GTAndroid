.class Lgtandroid/universal/KeyboardService$100000040;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000040"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$idInput:Landroid/widget/EditText;

.field private final val$line:Ljava/lang/String;

.field private final val$nick:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000040;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000040;->val$idInput:Landroid/widget/EditText;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000040;->val$line:Ljava/lang/String;

    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000040;->val$nick:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000040;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000040;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2101
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000040;->val$idInput:Landroid/widget/EditText;

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-interface {v6}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    move-object v3, v6

    .line 2102
    move-object v6, v3

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_0

    .line 2105
    :goto_0
    return-void

    .line 2103
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000040;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000040;->val$line:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000040;->val$nick:Ljava/lang/String;

    move-object v9, v3

    invoke-static {v6, v7, v8, v9}, Lgtandroid/universal/KeyboardService;->access$1000171(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object v4, v6

    .line 2104
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000040;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v4

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 2105
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000040;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000040;->val$line:Ljava/lang/String;

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000186(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    goto :goto_0
.end method
