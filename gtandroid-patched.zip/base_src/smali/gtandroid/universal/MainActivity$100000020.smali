.class Lgtandroid/universal/MainActivity$100000020;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000020"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$index:I

.field private final val$toggle:Lgtandroid/universal/MainActivity$EventToggle;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Lgtandroid/universal/MainActivity$EventToggle;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000020;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000020;->val$toggle:Lgtandroid/universal/MainActivity$EventToggle;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/MainActivity$100000020;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000020;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000020;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1081
    move-object v0, p0

    move-object v1, p1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000020;->val$toggle:Lgtandroid/universal/MainActivity$EventToggle;

    invoke-virtual {v8}, Lgtandroid/universal/MainActivity$EventToggle;->isChecked()Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x0

    :goto_0
    move v3, v8

    .line 1082
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000020;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v8}, Lgtandroid/universal/MainActivity;->access$1000064(Lgtandroid/universal/MainActivity;)Lorg/json/JSONArray;

    move-result-object v8

    move-object v4, v8

    .line 1085
    const/4 v8, 0x0

    move v5, v8

    :goto_1
    move v8, v5

    move-object v9, v4

    :try_start_0
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v9

    if-lt v8, v9, :cond_1

    .line 1092
    :goto_2
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000020;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v4

    invoke-static {v8, v9}, Lgtandroid/universal/MainActivity;->access$1000065(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V

    .line 1093
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000020;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v8}, Lgtandroid/universal/MainActivity;->access$1000077(Lgtandroid/universal/MainActivity;)V

    return-void

    .line 1081
    :cond_0
    const/4 v8, 0x1

    goto :goto_0

    .line 1086
    :cond_1
    move-object v8, v4

    move v9, v5

    :try_start_1
    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v8

    move-object v6, v8

    .line 1087
    move-object v8, v6

    const-string v9, "enabled"

    move v10, v3

    if-eqz v10, :cond_2

    move v10, v5

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/MainActivity$100000020;->val$index:I

    if-eq v10, v11, :cond_3

    :cond_2
    const/4 v10, 0x0

    :goto_3
    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v8

    .line 1085
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 1087
    :cond_3
    const/4 v10, 0x1

    goto :goto_3

    .line 1085
    :catch_0
    move-exception v8

    move-object v5, v8

    .line 1090
    move-object v8, v5

    invoke-virtual {v8}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_2
.end method
