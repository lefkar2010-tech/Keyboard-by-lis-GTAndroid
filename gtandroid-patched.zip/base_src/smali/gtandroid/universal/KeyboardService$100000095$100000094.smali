.class Lgtandroid/universal/KeyboardService$100000095$100000094;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$ValueCb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000095;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000094"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000095;

.field private final val$back:Ljava/lang/Runnable;

.field private final val$done:Ljava/lang/Runnable;

.field private final val$pre:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000095;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000095$100000094;->this$0:Lgtandroid/universal/KeyboardService$100000095;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$pre:Ljava/lang/String;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$back:Ljava/lang/Runnable;

    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$done:Ljava/lang/Runnable;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000095$100000094;)Lgtandroid/universal/KeyboardService$100000095;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095$100000094;->this$0:Lgtandroid/universal/KeyboardService$100000095;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onValue(Ljava/lang/String;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3775
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095$100000094;->this$0:Lgtandroid/universal/KeyboardService$100000095;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService$100000095;->access$0(Lgtandroid/universal/KeyboardService$100000095;)Lgtandroid/universal/KeyboardService;

    move-result-object v3

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$pre:Ljava/lang/String;

    move-object v5, v1

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$back:Ljava/lang/Runnable;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000095$100000094;->val$done:Ljava/lang/Runnable;

    invoke-static {v3, v4, v5, v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000319(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    return-void
.end method
