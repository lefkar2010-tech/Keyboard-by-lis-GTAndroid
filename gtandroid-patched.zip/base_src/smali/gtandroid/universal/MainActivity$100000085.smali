.class Lgtandroid/universal/MainActivity$100000085;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000085"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$etWord:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000085;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000085;->val$etWord:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000085;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000085;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3283
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000085;->val$etWord:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-interface {v7}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 3284
    move-object v7, v4

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 3285
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000085;->this$0:Lgtandroid/universal/MainActivity;

    move-object v8, v4

    invoke-static {v7, v8}, Lgtandroid/universal/MainActivity;->access$1000206(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Z

    move-result v7

    move v5, v7

    .line 3286
    move v7, v5

    if-eqz v7, :cond_1

    .line 3287
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000085;->this$0:Lgtandroid/universal/MainActivity;

    const-string v8, "\u2705 \u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043e!"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    .line 3289
    :cond_0
    :goto_0
    return-void

    :cond_1
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000085;->this$0:Lgtandroid/universal/MainActivity;

    const-string v8, "\u0422\u0430\u043a\u043e\u0435 \u0441\u043b\u043e\u0432\u043e \u0443\u0436\u0435 \u0435\u0441\u0442\u044c \u0432 \u0441\u043f\u0438\u0441\u043a\u0435"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
