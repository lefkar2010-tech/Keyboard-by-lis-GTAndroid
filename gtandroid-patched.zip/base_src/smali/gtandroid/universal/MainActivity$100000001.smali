.class Lgtandroid/universal/MainActivity$100000001;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$btnAutoReporter:Landroid/widget/Button;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000001;->val$btnAutoReporter:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000001;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 171
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v9, "floating_menu_enabled"

    const/4 v10, 0x0

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    move v3, v8

    .line 172
    move v8, v3

    if-eqz v8, :cond_0

    const/4 v8, 0x0

    :goto_0
    move v4, v8

    .line 173
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const-string v9, "floating_menu_enabled"

    move v10, v4

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 174
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000001;->val$btnAutoReporter:Landroid/widget/Button;

    new-instance v9, Ljava/lang/StringBuffer;

    move-object/from16 v18, v9

    move-object/from16 v9, v18

    move-object/from16 v10, v18

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\ud83d\udccb \u0410\u0432\u0442\u043e\u0440\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v4

    if-eqz v10, :cond_1

    const-string v10, "\u0412\u043a\u043b"

    :goto_1
    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 175
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v9, Ljava/lang/StringBuffer;

    move-object/from16 v18, v9

    move-object/from16 v9, v18

    move-object/from16 v10, v18

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u0410\u0432\u0442\u043e\u0440\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v4

    if-eqz v10, :cond_2

    const-string v10, "\u0412\u043a\u043b"

    :goto_2
    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 177
    new-instance v8, Landroid/content/Intent;

    move-object/from16 v18, v8

    move-object/from16 v8, v18

    move-object/from16 v9, v18

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    :try_start_0
    const-string v11, "gtandroid.universal.JailAlertService"

    invoke-static {v11}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v11

    invoke-direct {v9, v10, v11}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v5, v8

    .line 178
    move-object v8, v5

    const-string v9, "floatingmenu"

    move v10, v4

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v8

    .line 179
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000001;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v5

    invoke-virtual {v8, v9}, Landroid/content/ContextWrapper;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v8

    return-void

    .line 172
    :cond_0
    const/4 v8, 0x1

    goto/16 :goto_0

    .line 174
    :cond_1
    const-string v10, "\u0412\u044b\u043a\u043b"

    goto :goto_1

    .line 175
    :cond_2
    const-string v10, "\u0412\u044b\u043a\u043b"

    goto :goto_2

    .line 177
    :catch_0
    move-exception v8

    move-object v6, v8

    new-instance v8, Ljava/lang/NoClassDefFoundError;

    move-object/from16 v18, v8

    move-object/from16 v8, v18

    move-object/from16 v9, v18

    move-object v10, v6

    invoke-virtual {v10}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v8
.end method
