.class Lgtandroid/universal/KeyboardService$100000038;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000038"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$line:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000038;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000038;->val$line:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000038;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000038;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2061
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000038;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000038;->val$line:Ljava/lang/String;

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000170(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    move-object v3, v6

    .line 2062
    move-object v6, v3

    const/4 v7, 0x1

    aget-object v6, v6, v7

    move-object v4, v6

    .line 2063
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000038;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "/id "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v4

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 2064
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000038;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000038;->val$line:Ljava/lang/String;

    move-object v8, v4

    invoke-static {v6, v7, v8}, Lgtandroid/universal/KeyboardService;->access$1000185(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
