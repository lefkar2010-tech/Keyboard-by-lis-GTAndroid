.class Lgtandroid/universal/JailAlertService$100000005;
.super Ljava/lang/Object;
.source "JailAlertService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000005;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 494
    move-object v0, p0

    sget-boolean v8, Lgtandroid/universal/JailAlertService;->isRunning:Z

    if-nez v8, :cond_0

    .line 500
    :goto_0
    return-void

    .line 496
    :cond_0
    move-object v8, v0

    :try_start_0
    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v8}, Lgtandroid/universal/JailAlertService;->access$1000083(Lgtandroid/universal/JailAlertService;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 500
    :goto_1
    sget-boolean v8, Lgtandroid/universal/JailAlertService;->isRunning:Z

    if-eqz v8, :cond_1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v8}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v8

    if-eqz v8, :cond_1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v8}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v8

    move-object v9, v0

    const/16 v10, 0x7d0

    int-to-long v10, v10

    invoke-virtual {v8, v9, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v8

    :cond_1
    goto :goto_0

    .line 496
    :catch_0
    move-exception v8

    move-object v6, v8

    .line 498
    move-object v8, v0

    :try_start_1
    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    const-string v9, "AutoReport_sync"

    move-object v10, v6

    invoke-static {v8, v9, v10}, Lgtandroid/universal/AppLogger;->logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v8

    move-object v2, v8

    .line 500
    sget-boolean v8, Lgtandroid/universal/JailAlertService;->isRunning:Z

    if-eqz v8, :cond_2

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v8}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v8

    if-eqz v8, :cond_2

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000005;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v8}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v8

    move-object v9, v0

    const/16 v10, 0x7d0

    int-to-long v10, v10

    invoke-virtual {v8, v9, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v8

    :cond_2
    move-object v8, v2

    throw v8
.end method
