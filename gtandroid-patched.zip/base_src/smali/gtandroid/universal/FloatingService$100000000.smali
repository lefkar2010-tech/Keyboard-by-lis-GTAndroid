.class Lgtandroid/universal/FloatingService$100000000;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$content:Landroid/widget/LinearLayout;

.field private final val$scroll:Landroid/widget/ScrollView;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;Landroid/widget/ScrollView;Landroid/widget/LinearLayout;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000000;->val$scroll:Landroid/widget/ScrollView;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000000;->val$content:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000000;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "IIIIIIII)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 113
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move/from16 v4, p2

    move/from16 v5, p3

    move/from16 v6, p4

    move/from16 v7, p5

    move/from16 v8, p6

    move/from16 v9, p7

    move/from16 v10, p8

    move/from16 v11, p9

    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v21, v0

    invoke-static/range {v21 .. v21}, Lgtandroid/universal/FloatingService;->access$L1000022(Lgtandroid/universal/FloatingService;)Z

    move-result v21

    if-eqz v21, :cond_0

    .line 136
    :goto_0
    return-void

    .line 115
    :cond_0
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->val$scroll:Landroid/widget/ScrollView;

    move-object/from16 v21, v0

    invoke-virtual/range {v21 .. v21}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v21

    move-object/from16 v13, v21

    .line 116
    move-object/from16 v21, v13

    if-nez v21, :cond_1

    goto :goto_0

    .line 118
    :cond_1
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->val$scroll:Landroid/widget/ScrollView;

    move-object/from16 v21, v0

    invoke-virtual/range {v21 .. v21}, Landroid/view/View;->getWidth()I

    move-result v21

    move/from16 v14, v21

    .line 119
    move/from16 v21, v14

    const/16 v22, 0x0

    move/from16 v0, v21

    move/from16 v1, v22

    if-gt v0, v1, :cond_2

    goto :goto_0

    .line 121
    :cond_2
    move/from16 v21, v14

    const/high16 v22, 0x40000000    # 2.0f

    invoke-static/range {v21 .. v22}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v21

    move/from16 v15, v21

    .line 122
    const/16 v21, 0x0

    const/16 v22, 0x0

    invoke-static/range {v21 .. v22}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v21

    move/from16 v16, v21

    .line 123
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->val$content:Landroid/widget/LinearLayout;

    move-object/from16 v21, v0

    move/from16 v22, v15

    move/from16 v23, v16

    invoke-virtual/range {v21 .. v23}, Landroid/view/View;->measure(II)V

    .line 124
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->val$content:Landroid/widget/LinearLayout;

    move-object/from16 v21, v0

    invoke-virtual/range {v21 .. v21}, Landroid/view/View;->getMeasuredHeight()I

    move-result v21

    move/from16 v17, v21

    .line 126
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v21, v0

    invoke-static/range {v21 .. v21}, Lgtandroid/universal/FloatingService;->access$1000021(Lgtandroid/universal/FloatingService;)I

    move-result v21

    move/from16 v18, v21

    .line 127
    move/from16 v21, v17

    move/from16 v22, v18

    move/from16 v0, v21

    move/from16 v1, v22

    if-le v0, v1, :cond_3

    move/from16 v21, v18

    :goto_1
    move/from16 v19, v21

    .line 131
    move-object/from16 v21, v13

    move-object/from16 v0, v21

    iget v0, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    move/from16 v21, v0

    move/from16 v22, v19

    move/from16 v0, v21

    move/from16 v1, v22

    if-ne v0, v1, :cond_4

    goto/16 :goto_0

    .line 127
    :cond_3
    const/16 v21, -0x2

    goto :goto_1

    .line 133
    :cond_4
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v21, v0

    const/16 v22, 0x1

    invoke-static/range {v21 .. v22}, Lgtandroid/universal/FloatingService;->access$S1000022(Lgtandroid/universal/FloatingService;Z)V

    .line 134
    move-object/from16 v21, v13

    move/from16 v22, v19

    move/from16 v0, v22

    move-object/from16 v1, v21

    iput v0, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 135
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->val$scroll:Landroid/widget/ScrollView;

    move-object/from16 v21, v0

    move-object/from16 v22, v13

    invoke-virtual/range {v21 .. v22}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 136
    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000000;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v21, v0

    const/16 v22, 0x0

    invoke-static/range {v21 .. v22}, Lgtandroid/universal/FloatingService;->access$S1000022(Lgtandroid/universal/FloatingService;Z)V

    goto/16 :goto_0
.end method
