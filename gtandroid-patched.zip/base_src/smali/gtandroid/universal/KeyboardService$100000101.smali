.class Lgtandroid/universal/KeyboardService$100000101;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000101"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$btnFollow:Landroid/widget/Button;

.field private final val$follow:[Z


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;[ZLandroid/widget/Button;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000101;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000101;->val$follow:[Z

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000101;->val$btnFollow:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000101;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4038
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->val$follow:[Z

    const/4 v4, 0x0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000101;->val$follow:[Z

    const/4 v6, 0x0

    aget-boolean v5, v5, v6

    if-eqz v5, :cond_0

    const/4 v5, 0x0

    :goto_0
    aput-boolean v5, v3, v4

    .line 4039
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->val$btnFollow:Landroid/widget/Button;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000101;->val$follow:[Z

    const/4 v5, 0x0

    aget-boolean v4, v4, v5

    if-eqz v4, :cond_1

    const-string v4, "\u2611 \u0417\u0430\u0445\u043e\u0434\u0438\u0442\u044c \u0432 \u0441\u043b\u0435\u0436\u043a\u0443"

    :goto_1
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 4040
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->val$follow:[Z

    const/4 v4, 0x0

    aget-boolean v3, v3, v4

    if-eqz v3, :cond_2

    .line 4041
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000101;->val$btnFollow:Landroid/widget/Button;

    const v5, -0xc12e96

    invoke-static {v3, v4, v5}, Lgtandroid/universal/NeonUi;->tintTile(Landroid/content/Context;Landroid/widget/Button;I)V

    .line 4043
    :goto_2
    return-void

    .line 4038
    :cond_0
    const/4 v5, 0x1

    goto :goto_0

    .line 4039
    :cond_1
    const-string v4, "\u2610 \u0417\u0430\u0445\u043e\u0434\u0438\u0442\u044c \u0432 \u0441\u043b\u0435\u0436\u043a\u0443"

    goto :goto_1

    .line 4043
    :cond_2
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000101;->val$btnFollow:Landroid/widget/Button;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000101;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/NeonUi;->tileDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-static {v3, v4}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    goto :goto_2
.end method
