.class Lgtandroid/universal/KeyboardService$100000180;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000180"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$report:Lgtandroid/universal/ReportData;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000180;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6228
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v6, v6, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    if-eqz v6, :cond_0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v6, v6, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v6, v6, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    :goto_0
    move-object v3, v6

    .line 6229
    new-instance v6, Ljava/lang/StringBuffer;

    move-object v15, v6

    move-object v6, v15

    move-object v7, v15

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v15, v12

    move-object v12, v15

    move-object v13, v15

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "/a "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v13, v13, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, " | "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v11, v11, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "["

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v9, v9, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "] "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    move-object v4, v6

    .line 6230
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v4

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 6232
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "a_followup_queue"

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    iget-object v8, v8, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-static {v6, v7, v8}, Lgtandroid/universal/TriggerData;->pushQueue(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/String;)V

    .line 6234
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000180;->val$report:Lgtandroid/universal/ReportData;

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000474(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V

    .line 6235
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000180;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000457(Lgtandroid/universal/KeyboardService;)V

    return-void

    .line 6228
    :cond_0
    const-string v6, "\u041d\u0443\u0436\u043d\u0430 \u043f\u043e\u043c\u043e\u0449\u044c"

    goto/16 :goto_0
.end method
