.class Lgtandroid/universal/KeyboardService$100000178;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000178"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$report:Lgtandroid/universal/ReportData;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000178;->val$report:Lgtandroid/universal/ReportData;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000178;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6190
    move-object v0, p0

    move-object v1, p1

    new-instance v5, Ljava/lang/StringBuffer;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "/ans "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000178;->val$report:Lgtandroid/universal/ReportData;

    iget-object v7, v7, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    const-string v6, " \u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044e, \u0441\u0435\u0439\u0447\u0430\u0441 \u043f\u043e\u0441\u0442\u0430\u0440\u0430\u044e\u0441\u044c \u0432\u0430\u043c \u043f\u043e\u043c\u043e\u0447\u044c."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 6191
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 6193
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000178;->val$report:Lgtandroid/universal/ReportData;

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000474(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V

    .line 6194
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000178;->val$report:Lgtandroid/universal/ReportData;

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000335(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V

    .line 6195
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    const/4 v6, 0x0

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$S1000018(Lgtandroid/universal/KeyboardService;Z)V

    .line 6196
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000178;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000178;->val$report:Lgtandroid/universal/ReportData;

    iget-object v6, v6, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000285(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    return-void
.end method
