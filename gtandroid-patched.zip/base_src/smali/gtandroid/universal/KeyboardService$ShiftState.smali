.class Lgtandroid/universal/KeyboardService$ShiftState;
.super LjavalangEnum;
.source "KeyboardService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "ShiftState"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "LjavalangEnum",
        "<",
        "Lgtandroid/universal/KeyboardService$ShiftState;",
        ">;"
    }
.end annotation


# static fields
.field private static $VALUES:[Lgtandroid/universal/KeyboardService$ShiftState;

.field public static final CAPS_LOCK:Lgtandroid/universal/KeyboardService$ShiftState;

.field public static final OFF:Lgtandroid/universal/KeyboardService$ShiftState;

.field public static final ONCE:Lgtandroid/universal/KeyboardService$ShiftState;


# direct methods
.method static final constructor <clinit>()V
    .locals 7

    new-instance v2, Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const-string v4, "OFF"

    const/4 v5, 0x0

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/KeyboardService$ShiftState;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lgtandroid/universal/KeyboardService$ShiftState;->OFF:Lgtandroid/universal/KeyboardService$ShiftState;

    new-instance v2, Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const-string v4, "ONCE"

    const/4 v5, 0x1

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/KeyboardService$ShiftState;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lgtandroid/universal/KeyboardService$ShiftState;->ONCE:Lgtandroid/universal/KeyboardService$ShiftState;

    new-instance v2, Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const-string v4, "CAPS_LOCK"

    const/4 v5, 0x2

    invoke-direct {v3, v4, v5}, Lgtandroid/universal/KeyboardService$ShiftState;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lgtandroid/universal/KeyboardService$ShiftState;->CAPS_LOCK:Lgtandroid/universal/KeyboardService$ShiftState;

    const/4 v2, 0x3

    new-array v2, v2, [Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x0

    sget-object v5, Lgtandroid/universal/KeyboardService$ShiftState;->OFF:Lgtandroid/universal/KeyboardService$ShiftState;

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x1

    sget-object v5, Lgtandroid/universal/KeyboardService$ShiftState;->ONCE:Lgtandroid/universal/KeyboardService$ShiftState;

    aput-object v5, v3, v4

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const/4 v4, 0x2

    sget-object v5, Lgtandroid/universal/KeyboardService$ShiftState;->CAPS_LOCK:Lgtandroid/universal/KeyboardService$ShiftState;

    aput-object v5, v3, v4

    sput-object v2, Lgtandroid/universal/KeyboardService$ShiftState;->$VALUES:[Lgtandroid/universal/KeyboardService$ShiftState;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 7

    .prologue
    .line 50
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    move-object v5, v1

    move v6, v2

    invoke-direct {v4, v5, v6}, LjavalangEnum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lgtandroid/universal/KeyboardService$ShiftState;
    .locals 9

    .prologue
    .line 50
    move-object v0, p0

    sget-object v6, Lgtandroid/universal/KeyboardService$ShiftState;->$VALUES:[Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v2, v6

    const/4 v6, 0x0

    move v3, v6

    :goto_0
    move v6, v3

    move-object v7, v2

    array-length v7, v7

    if-lt v6, v7, :cond_0

    new-instance v6, Ljava/lang/IllegalArgumentException;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v6

    :cond_0
    move-object v6, v2

    move v7, v3

    aget-object v6, v6, v7

    move-object v4, v6

    move-object v6, v4

    invoke-virtual {v6}, LjavalangEnum;->name()Ljava/lang/String;

    move-result-object v6

    move-object v7, v0

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    move-object v6, v4

    move-object v0, v6

    return-object v0

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0
.end method

.method public static final values()[Lgtandroid/universal/KeyboardService$ShiftState;
    .locals 3

    .prologue
    .line 50
    sget-object v2, Lgtandroid/universal/KeyboardService$ShiftState;->$VALUES:[Lgtandroid/universal/KeyboardService$ShiftState;

    invoke-virtual {v2}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Lgtandroid/universal/KeyboardService$ShiftState;

    move-object v0, v2

    return-object v0
.end method
