.class Lgtandroid/universal/MainActivity$100000069;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000069"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$index:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000069;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/MainActivity$100000069;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000069;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000069;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2607
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000069;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/MainActivity$100000069;->val$index:I

    invoke-static {v3, v4}, Lgtandroid/universal/MainActivity;->access$1000170(Lgtandroid/universal/MainActivity;I)V

    .line 2608
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000069;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v3}, Lgtandroid/universal/MainActivity;->access$1000166(Lgtandroid/universal/MainActivity;)V

    return-void
.end method
