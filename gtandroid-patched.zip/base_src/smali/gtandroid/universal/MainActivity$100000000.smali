.class Lgtandroid/universal/MainActivity$100000000;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$b:Landroid/widget/Button;

.field private final val$key:Ljava/lang/String;

.field private final val$label:Ljava/lang/String;

.field private final val$onColor:I

.field private final val$state:[Z


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;[ZLjava/lang/String;Landroid/widget/Button;Ljava/lang/String;I)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000000;->this$0:Lgtandroid/universal/MainActivity;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    move-object v8, v0

    move-object v9, v3

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000000;->val$key:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000000;->val$b:Landroid/widget/Button;

    move-object v8, v0

    move-object v9, v5

    iput-object v9, v8, Lgtandroid/universal/MainActivity$100000000;->val$label:Ljava/lang/String;

    move-object v8, v0

    move v9, v6

    iput v9, v8, Lgtandroid/universal/MainActivity$100000000;->val$onColor:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000000;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000000;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 139
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    const/4 v4, 0x0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    const/4 v6, 0x0

    aget-boolean v5, v5, v6

    if-eqz v5, :cond_0

    const/4 v5, 0x0

    :goto_0
    aput-boolean v5, v3, v4

    .line 140
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000000;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v3, v3, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000000;->val$key:Ljava/lang/String;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    const/4 v6, 0x0

    aget-boolean v5, v5, v6

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 141
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000000;->val$b:Landroid/widget/Button;

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v5, Ljava/lang/StringBuffer;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/lang/StringBuffer;-><init>()V

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000000;->val$label:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    const-string v6, ": "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    const/4 v6, 0x0

    aget-boolean v5, v5, v6

    if-eqz v5, :cond_1

    const-string v5, "\u0412\u043a\u043b"

    :goto_1
    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 142
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000000;->val$b:Landroid/widget/Button;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000000;->val$state:[Z

    const/4 v5, 0x0

    aget-boolean v4, v4, v5

    if-eqz v4, :cond_2

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/MainActivity$100000000;->val$onColor:I

    :goto_2
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundColor(I)V

    return-void

    .line 139
    :cond_0
    const/4 v5, 0x1

    goto :goto_0

    .line 141
    :cond_1
    const-string v5, "\u0412\u044b\u043a\u043b"

    goto :goto_1

    .line 142
    :cond_2
    const v4, -0x99999a

    goto :goto_2
.end method
