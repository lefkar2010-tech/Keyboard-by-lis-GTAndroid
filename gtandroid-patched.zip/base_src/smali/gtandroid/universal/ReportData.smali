.class public Lgtandroid/universal/ReportData;
.super Ljava/lang/Object;
.source "ReportData.java"


# instance fields
.field public count:I

.field public firstSeenMs:J

.field public fullLine:Ljava/lang/String;

.field public hiddenUntil:J

.field public id:Ljava/lang/String;

.field public isAnswered:Z

.field public isEvent:Z

.field public nick:Ljava/lang/String;

.field public shownUntil:J

.field public sourceTime:Ljava/lang/String;

.field public text:Ljava/lang/String;

.field public time:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 12

    .prologue
    .line 17
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p5

    move-object/from16 v7, p6

    move-object v9, v1

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    move-object v9, v1

    const/4 v10, 0x0

    iput-boolean v10, v9, Lgtandroid/universal/ReportData;->isAnswered:Z

    move-object v9, v1

    const-string v10, ""

    iput-object v10, v9, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    move-object v9, v1

    const/4 v10, 0x0

    iput-boolean v10, v9, Lgtandroid/universal/ReportData;->isEvent:Z

    move-object v9, v1

    const/4 v10, 0x0

    int-to-long v10, v10

    iput-wide v10, v9, Lgtandroid/universal/ReportData;->firstSeenMs:J

    .line 18
    move-object v9, v1

    move-object v10, v2

    iput-object v10, v9, Lgtandroid/universal/ReportData;->time:Ljava/lang/String;

    .line 19
    move-object v9, v1

    move-object v10, v3

    iput-object v10, v9, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    .line 20
    move-object v9, v1

    move-object v10, v4

    iput-object v10, v9, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    .line 21
    move-object v9, v1

    move-object v10, v5

    iput-object v10, v9, Lgtandroid/universal/ReportData;->text:Ljava/lang/String;

    .line 22
    move-object v9, v1

    move v10, v6

    iput v10, v9, Lgtandroid/universal/ReportData;->count:I

    .line 23
    move-object v9, v1

    move-object v10, v7

    iput-object v10, v9, Lgtandroid/universal/ReportData;->fullLine:Ljava/lang/String;

    .line 24
    move-object v9, v1

    const/4 v10, 0x0

    int-to-long v10, v10

    iput-wide v10, v9, Lgtandroid/universal/ReportData;->hiddenUntil:J

    .line 25
    move-object v9, v1

    const/4 v10, 0x0

    int-to-long v10, v10

    iput-wide v10, v9, Lgtandroid/universal/ReportData;->shownUntil:J

    .line 26
    move-object v9, v1

    const/4 v10, 0x0

    iput-boolean v10, v9, Lgtandroid/universal/ReportData;->isAnswered:Z

    .line 27
    move-object v9, v1

    const-string v10, ""

    iput-object v10, v9, Lgtandroid/universal/ReportData;->sourceTime:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 7
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 32
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    move-object v6, v1

    if-ne v5, v6, :cond_0

    const/4 v5, 0x1

    move v0, v5

    .line 35
    :goto_0
    return v0

    .line 33
    :cond_0
    move-object v5, v1

    if-eqz v5, :cond_1

    move-object v5, v0

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    move-object v6, v1

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    if-eq v5, v6, :cond_2

    :cond_1
    const/4 v5, 0x0

    move v0, v5

    goto :goto_0

    .line 34
    :cond_2
    move-object v5, v1

    check-cast v5, Lgtandroid/universal/ReportData;

    move-object v3, v5

    .line 35
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    move-object v6, v3

    iget-object v6, v6, Lgtandroid/universal/ReportData;->nick:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    move-object v6, v3

    iget-object v6, v6, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_4

    :cond_3
    const/4 v5, 0x0

    :goto_1
    move v0, v5

    goto :goto_0

    :cond_4
    const/4 v5, 0x1

    goto :goto_1
.end method
