.class public final Lgtandroid/universal/R$xml;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "xml"
.end annotation


# static fields
.field public static final accessibility_service_config:I = 0x7f050000

.field public static final method:I = 0x7f050001


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 170
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
