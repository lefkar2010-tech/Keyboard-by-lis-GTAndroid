.class public Lgtandroid/universal/TriggerData$Trigger;
.super Ljava/lang/Object;
.source "TriggerData.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/TriggerData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Trigger"
.end annotation


# instance fields
.field public answerName:Ljava/lang/String;

.field public answerText:Ljava/lang/String;

.field public enabled:Z

.field public follow:Z

.field public word:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V
    .locals 8

    .prologue
    .line 28
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    const/4 v7, 0x1

    iput-boolean v7, v6, Lgtandroid/universal/TriggerData$Trigger;->enabled:Z

    .line 29
    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    .line 30
    move-object v6, v0

    move v7, v2

    iput-boolean v7, v6, Lgtandroid/universal/TriggerData$Trigger;->follow:Z

    .line 31
    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    .line 32
    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;

    return-void
.end method
