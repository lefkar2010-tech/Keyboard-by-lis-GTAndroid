.class Lgtandroid/universal/AreaSelectorService$100000001;
.super Ljava/lang/Object;
.source "AreaSelectorService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/AreaSelectorService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/AreaSelectorService;

.field private final val$handleType:I


# direct methods
.method constructor <init>(Lgtandroid/universal/AreaSelectorService;I)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/AreaSelectorService$100000001;->val$handleType:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/AreaSelectorService$100000001;)Lgtandroid/universal/AreaSelectorService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 12
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 249
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v9, v2

    invoke-virtual {v9}, Landroid/view/MotionEvent;->getRawX()F

    move-result v9

    move v4, v9

    .line 250
    move-object v9, v2

    invoke-virtual {v9}, Landroid/view/MotionEvent;->getRawY()F

    move-result v9

    move v5, v9

    .line 252
    move-object v9, v2

    invoke-virtual {v9}, Landroid/view/MotionEvent;->getAction()I

    move-result v9

    packed-switch v9, :pswitch_data_0

    .line 275
    const/4 v9, 0x0

    move v0, v9

    :goto_0
    return v0

    .line 254
    :pswitch_0
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move v10, v4

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000019(Lgtandroid/universal/AreaSelectorService;F)V

    .line 255
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move v10, v5

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000020(Lgtandroid/universal/AreaSelectorService;F)V

    .line 256
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v9}, Lgtandroid/universal/AreaSelectorService;->access$L1000021(Lgtandroid/universal/AreaSelectorService;)Landroid/graphics/Rect;

    move-result-object v9

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v10}, Lgtandroid/universal/AreaSelectorService;->access$L1000016(Lgtandroid/universal/AreaSelectorService;)Landroid/graphics/Rect;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 257
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/AreaSelectorService$100000001;->val$handleType:I

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000018(Lgtandroid/universal/AreaSelectorService;I)V

    .line 258
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    const/4 v10, 0x1

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000017(Lgtandroid/universal/AreaSelectorService;Z)V

    .line 259
    const/4 v9, 0x1

    move v0, v9

    goto :goto_0

    .line 262
    :pswitch_1
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v9}, Lgtandroid/universal/AreaSelectorService;->access$L1000017(Lgtandroid/universal/AreaSelectorService;)Z

    move-result v9

    if-eqz v9, :cond_0

    .line 263
    move v9, v4

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v10}, Lgtandroid/universal/AreaSelectorService;->access$L1000019(Lgtandroid/universal/AreaSelectorService;)F

    move-result v10

    sub-float/2addr v9, v10

    move v6, v9

    .line 264
    move v9, v5

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v10}, Lgtandroid/universal/AreaSelectorService;->access$L1000020(Lgtandroid/universal/AreaSelectorService;)F

    move-result v10

    sub-float/2addr v9, v10

    move v7, v9

    .line 265
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    move v10, v6

    move v11, v7

    invoke-static {v9, v10, v11}, Lgtandroid/universal/AreaSelectorService;->access$1000045(Lgtandroid/universal/AreaSelectorService;FF)V

    .line 267
    :cond_0
    const/4 v9, 0x1

    move v0, v9

    goto :goto_0

    .line 270
    :pswitch_2
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000017(Lgtandroid/universal/AreaSelectorService;Z)V

    .line 271
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    const/4 v10, -0x1

    invoke-static {v9, v10}, Lgtandroid/universal/AreaSelectorService;->access$S1000018(Lgtandroid/universal/AreaSelectorService;I)V

    .line 272
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/AreaSelectorService$100000001;->this$0:Lgtandroid/universal/AreaSelectorService;

    invoke-static {v9}, Lgtandroid/universal/AreaSelectorService;->access$1000048(Lgtandroid/universal/AreaSelectorService;)V

    .line 273
    const/4 v9, 0x1

    move v0, v9

    goto :goto_0

    .line 252
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
