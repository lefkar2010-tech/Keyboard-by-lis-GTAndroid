.class Lgtandroid/universal/FloatingService$100000005;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/FloatingService$100000005;->this$0:Lgtandroid/universal/FloatingService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000005;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000005;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 511
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000005;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v3}, Lgtandroid/universal/FloatingService;->access$1000042(Lgtandroid/universal/FloatingService;)V

    return-void
.end method
