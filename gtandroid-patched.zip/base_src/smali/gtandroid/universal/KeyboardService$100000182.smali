.class Lgtandroid/universal/KeyboardService$100000182;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000182"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$report:Lgtandroid/universal/ReportData;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/ReportData;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000182;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000182;->val$report:Lgtandroid/universal/ReportData;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000182;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000182;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6272
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000182;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000182;->val$report:Lgtandroid/universal/ReportData;

    iget-object v4, v4, Lgtandroid/universal/ReportData;->id:Ljava/lang/String;

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$S1000017(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 6273
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000182;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000416(Lgtandroid/universal/KeyboardService;)V

    return-void
.end method
