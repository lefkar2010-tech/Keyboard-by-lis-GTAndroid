.class Lgtandroid/universal/MainActivity$100000046;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000046"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$index:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/MainActivity$100000046;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000046;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1667
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v6

    move-object v4, v6

    .line 1668
    move-object v6, v0

    iget v6, v6, Lgtandroid/universal/MainActivity$100000046;->val$index:I

    move-object v7, v4

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_0

    move-object v6, v4

    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/MainActivity$100000046;->val$index:I

    invoke-interface {v6, v7}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v6

    .line 1669
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v7, v4

    invoke-static {v6, v7}, Lgtandroid/universal/TriggerData;->save(Landroid/content/SharedPreferences;Ljava/util/List;)V

    .line 1670
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    const-string v7, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0443\u0434\u0430\u043b\u0451\u043d"

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 1671
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000046;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v6}, Lgtandroid/universal/MainActivity;->access$1000115(Lgtandroid/universal/MainActivity;)V

    return-void
.end method
