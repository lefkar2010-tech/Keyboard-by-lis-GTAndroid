.class final Lgtandroid/universal/NeonUi$NumKeyBg;
.super Landroid/graphics/drawable/Drawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x3a
    name = "NumKeyBg"
.end annotation


# instance fields
.field private final bottom:I

.field private final edge:Landroid/graphics/Paint;

.field private final fill:Landroid/graphics/Paint;

.field private final gloss:Landroid/graphics/Paint;

.field private final r:Landroid/graphics/RectF;

.field private final radiusPx:F

.field private final stroke:I

.field private final top:I


# direct methods
.method constructor <init>(FIII)V
    .locals 11

    .prologue
    .line 1460
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v6, v0

    invoke-direct {v6}, Landroid/graphics/drawable/Drawable;-><init>()V

    move-object v6, v0

    new-instance v7, Landroid/graphics/Paint;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->fill:Landroid/graphics/Paint;

    move-object v6, v0

    new-instance v7, Landroid/graphics/Paint;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->edge:Landroid/graphics/Paint;

    move-object v6, v0

    new-instance v7, Landroid/graphics/Paint;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    move-object v6, v0

    new-instance v7, Landroid/graphics/RectF;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Landroid/graphics/RectF;-><init>()V

    iput-object v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->r:Landroid/graphics/RectF;

    .line 1461
    move-object v6, v0

    move v7, v1

    iput v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    .line 1462
    move-object v6, v0

    move v7, v2

    iput v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->top:I

    .line 1463
    move-object v6, v0

    move v7, v3

    iput v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->bottom:I

    .line 1464
    move-object v6, v0

    move v7, v4

    iput v7, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->stroke:I

    .line 1465
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->edge:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1466
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1467
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1468
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    const v7, 0x1effffff

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1478
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v10, v0

    invoke-virtual {v10}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v10

    move-object v3, v10

    .line 1479
    const/high16 v10, 0x3f800000    # 1.0f

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    const v12, 0x3db851ec    # 0.09f

    mul-float/2addr v11, v12

    invoke-static {v10, v11}, Ljava/lang/Math;->max(FF)F

    move-result v10

    move v4, v10

    .line 1480
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$NumKeyBg;->edge:Landroid/graphics/Paint;

    move v11, v4

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1481
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$NumKeyBg;->edge:Landroid/graphics/Paint;

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/NeonUi$NumKeyBg;->stroke:I

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 1482
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$NumKeyBg;->r:Landroid/graphics/RectF;

    move-object v11, v3

    iget v11, v11, Landroid/graphics/Rect;->left:I

    int-to-float v11, v11

    move v12, v4

    const/high16 v13, 0x40000000    # 2.0f

    div-float/2addr v12, v13

    add-float/2addr v11, v12

    move-object v12, v3

    iget v12, v12, Landroid/graphics/Rect;->top:I

    int-to-float v12, v12

    move v13, v4

    const/high16 v14, 0x40000000    # 2.0f

    div-float/2addr v13, v14

    add-float/2addr v12, v13

    move-object v13, v3

    iget v13, v13, Landroid/graphics/Rect;->right:I

    int-to-float v13, v13

    move v14, v4

    const/high16 v15, 0x40000000    # 2.0f

    div-float/2addr v14, v15

    sub-float/2addr v13, v14

    move-object v14, v3

    iget v14, v14, Landroid/graphics/Rect;->bottom:I

    int-to-float v14, v14

    move v15, v4

    const/high16 v16, 0x40000000    # 2.0f

    div-float v15, v15, v16

    sub-float/2addr v14, v15

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1483
    move-object v10, v1

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$NumKeyBg;->r:Landroid/graphics/RectF;

    move-object v12, v0

    iget v12, v12, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/NeonUi$NumKeyBg;->fill:Landroid/graphics/Paint;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1484
    move-object v10, v1

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$NumKeyBg;->r:Landroid/graphics/RectF;

    move-object v12, v0

    iget v12, v12, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/NeonUi$NumKeyBg;->radiusPx:F

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/NeonUi$NumKeyBg;->edge:Landroid/graphics/Paint;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1486
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    const/high16 v11, 0x3f800000    # 1.0f

    move-object v12, v3

    invoke-virtual {v12}, Landroid/graphics/Rect;->height()I

    move-result v12

    int-to-float v12, v12

    const v13, 0x3d4ccccd    # 0.05f

    mul-float/2addr v12, v13

    invoke-static {v11, v12}, Ljava/lang/Math;->max(FF)F

    move-result v11

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1487
    move-object v10, v3

    invoke-virtual {v10}, Landroid/graphics/Rect;->width()I

    move-result v10

    int-to-float v10, v10

    move v5, v10

    move-object v10, v3

    invoke-virtual {v10}, Landroid/graphics/Rect;->height()I

    move-result v10

    int-to-float v10, v10

    move v6, v10

    .line 1488
    const/4 v10, -0x1

    move v7, v10

    :goto_0
    move v10, v7

    const/4 v11, 0x1

    if-le v10, v11, :cond_0

    return-void

    .line 1489
    :cond_0
    move-object v10, v3

    iget v10, v10, Landroid/graphics/Rect;->left:I

    int-to-float v10, v10

    move v11, v5

    const v12, 0x3e99999a    # 0.3f

    move v13, v7

    int-to-float v13, v13

    const v14, 0x3e8f5c29    # 0.28f

    mul-float/2addr v13, v14

    add-float/2addr v12, v13

    mul-float/2addr v11, v12

    add-float/2addr v10, v11

    move v8, v10

    .line 1490
    move-object v10, v1

    move v11, v8

    move-object v12, v3

    iget v12, v12, Landroid/graphics/Rect;->bottom:I

    int-to-float v12, v12

    move v13, v6

    const v14, 0x3df5c28f    # 0.12f

    mul-float/2addr v13, v14

    sub-float/2addr v12, v13

    move v13, v8

    move v14, v5

    const v15, 0x3e6147ae    # 0.22f

    mul-float/2addr v14, v15

    add-float/2addr v13, v14

    move-object v14, v3

    iget v14, v14, Landroid/graphics/Rect;->top:I

    int-to-float v14, v14

    move v15, v6

    const v16, 0x3df5c28f    # 0.12f

    mul-float v15, v15, v16

    add-float/2addr v14, v15

    move-object v15, v0

    iget-object v15, v15, Lgtandroid/universal/NeonUi$NumKeyBg;->gloss:Landroid/graphics/Paint;

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1488
    add-int/lit8 v7, v7, 0x1

    goto :goto_0
.end method

.method public getOpacity()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1496
    move-object v0, p0

    const/4 v2, -0x3

    move v0, v2

    return v0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Rect;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1473
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/NeonUi$NumKeyBg;->fill:Landroid/graphics/Paint;

    new-instance v4, Landroid/graphics/LinearGradient;

    move-object v13, v4

    move-object v4, v13

    move-object v5, v13

    move-object v6, v1

    iget v6, v6, Landroid/graphics/Rect;->left:I

    int-to-float v6, v6

    move-object v7, v1

    iget v7, v7, Landroid/graphics/Rect;->top:I

    int-to-float v7, v7

    move-object v8, v1

    iget v8, v8, Landroid/graphics/Rect;->left:I

    int-to-float v8, v8

    move-object v9, v1

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/NeonUi$NumKeyBg;->top:I

    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/NeonUi$NumKeyBg;->bottom:I

    sget-object v12, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v5 .. v12}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    move-result-object v3

    return-void
.end method

.method public setAlpha(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/ColorFilter;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method
