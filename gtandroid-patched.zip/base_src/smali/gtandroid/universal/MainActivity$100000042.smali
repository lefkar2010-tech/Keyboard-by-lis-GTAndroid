.class Lgtandroid/universal/MainActivity$100000042;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000042"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$holder:[Landroid/app/AlertDialog;

.field private final val$which:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000042;->val$holder:[Landroid/app/AlertDialog;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/MainActivity$100000042;->val$which:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000042;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1542
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->val$holder:[Landroid/app/AlertDialog;

    const/4 v6, 0x0

    aget-object v5, v5, v6

    if-eqz v5, :cond_0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->val$holder:[Landroid/app/AlertDialog;

    const/4 v6, 0x0

    aget-object v5, v5, v6

    invoke-virtual {v5}, Landroid/app/Dialog;->dismiss()V

    .line 1543
    :cond_0
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/MainActivity$100000042;->val$which:I

    const/4 v6, 0x0

    if-ne v5, v6, :cond_1

    .line 1544
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    const/4 v6, -0x1

    invoke-static {v5, v6}, Lgtandroid/universal/MainActivity;->access$1000120(Lgtandroid/universal/MainActivity;I)V

    .line 1557
    :goto_0
    return-void

    .line 1545
    :cond_1
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/MainActivity$100000042;->val$which:I

    const/4 v6, 0x1

    if-ne v5, v6, :cond_2

    .line 1546
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v5}, Lgtandroid/universal/MainActivity;->access$1000115(Lgtandroid/universal/MainActivity;)V

    goto :goto_0

    .line 1547
    :cond_2
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/MainActivity$100000042;->val$which:I

    const/4 v6, 0x2

    if-ne v5, v6, :cond_3

    .line 1548
    new-instance v5, Landroid/content/Intent;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const-string v7, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 1549
    move-object v5, v3

    const-string v6, "android.intent.category.OPENABLE"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 1550
    move-object v5, v3

    const-string v6, "*/*"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 1551
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v3

    const/16 v7, 0x297

    invoke-virtual {v5, v6, v7}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_0

    .line 1553
    :cond_3
    new-instance v5, Landroid/content/Intent;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const-string v7, "android.intent.action.CREATE_DOCUMENT"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 1554
    move-object v5, v3

    const-string v6, "android.intent.category.OPENABLE"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 1555
    move-object v5, v3

    const-string v6, "*/*"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 1556
    move-object v5, v3

    const-string v6, "android.intent.extra.TITLE"

    const-string v7, "triggers.cfg"

    invoke-virtual {v5, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 1557
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000042;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v3

    const/16 v7, 0x298

    invoke-virtual {v5, v6, v7}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_0
.end method
