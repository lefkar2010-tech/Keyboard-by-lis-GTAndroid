.class Lgtandroid/universal/JailAlertService$100000002;
.super Landroid/content/BroadcastReceiver;
.source "JailAlertService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v3, v0

    invoke-direct {v3}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000002;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 407
    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object v9, v2

    invoke-virtual {v9}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 408
    move-object v9, v2

    const-string v10, "command"

    invoke-virtual {v9, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v5, v9

    .line 409
    move-object v9, v2

    const-string v10, "adminId"

    invoke-virtual {v9, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v6, v9

    .line 410
    move-object v9, v2

    const-string v10, "initials"

    invoke-virtual {v9, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v7, v9

    .line 412
    const-string v9, "AUTO_FORM_ACCEPTED"

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 413
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v13, v11

    move-object v11, v13

    move-object v12, v13

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    move-object v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "|"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v6

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/JailAlertService;->access$S1000047(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V

    .line 414
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-static {v9, v10, v11}, Lgtandroid/universal/JailAlertService;->access$S1000046(Lgtandroid/universal/JailAlertService;J)V

    .line 415
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v9}, Lgtandroid/universal/JailAlertService;->access$1000124(Lgtandroid/universal/JailAlertService;)V

    .line 419
    :cond_0
    :goto_0
    return-void

    .line 416
    :cond_1
    const-string v9, "AUTO_FORM_DECLINED"

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_0

    .line 417
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v13, v11

    move-object v11, v13

    move-object v12, v13

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    move-object v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "|"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v6

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lgtandroid/universal/JailAlertService;->access$S1000047(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V

    .line 418
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-static {v9, v10, v11}, Lgtandroid/universal/JailAlertService;->access$S1000046(Lgtandroid/universal/JailAlertService;J)V

    .line 419
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/JailAlertService$100000002;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v9}, Lgtandroid/universal/JailAlertService;->access$1000124(Lgtandroid/universal/JailAlertService;)V

    goto :goto_0
.end method
