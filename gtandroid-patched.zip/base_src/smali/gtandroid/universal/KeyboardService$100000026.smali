.class Lgtandroid/universal/KeyboardService$100000026;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000026"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$command:Ljava/lang/String;

.field private final val$name:Ljava/lang/String;

.field private final val$reason:Ljava/lang/String;

.field private final val$requiredLevel:I

.field private final val$time:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    move-object/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000026;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000026;->val$command:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v3

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000026;->val$time:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000026;->val$reason:Ljava/lang/String;

    move-object v8, v0

    move v9, v5

    iput v9, v8, Lgtandroid/universal/KeyboardService$100000026;->val$requiredLevel:I

    move-object v8, v0

    move-object v9, v6

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000026;->val$name:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000026;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000026;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1495
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000026;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000026;->val$command:Ljava/lang/String;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000026;->val$time:Ljava/lang/String;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000026;->val$reason:Ljava/lang/String;

    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/KeyboardService$100000026;->val$requiredLevel:I

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000026;->val$name:Ljava/lang/String;

    invoke-static/range {v3 .. v8}, Lgtandroid/universal/KeyboardService;->access$1000157(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method
