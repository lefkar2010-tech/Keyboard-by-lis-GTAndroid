.class Lgtandroid/universal/KeyboardService$100000136$100000135;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000136;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000135"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000136;

.field private final val$mainContainer:Landroid/widget/LinearLayout;

.field private final val$playerId:Ljava/lang/String;

.field private final val$s:Lgtandroid/universal/KeyboardService$TileSpec;

.field private final val$violatorId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000136;Lgtandroid/universal/KeyboardService$TileSpec;Ljava/lang/String;Ljava/lang/String;Landroid/widget/LinearLayout;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136$100000135;->this$0:Lgtandroid/universal/KeyboardService$100000136;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$playerId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$violatorId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$mainContainer:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000136$100000135;)Lgtandroid/universal/KeyboardService$100000136;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000136$100000135;->this$0:Lgtandroid/universal/KeyboardService$100000136;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4757
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000136$100000135;->this$0:Lgtandroid/universal/KeyboardService$100000136;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService$100000136;->access$0(Lgtandroid/universal/KeyboardService$100000136;)Lgtandroid/universal/KeyboardService;

    move-result-object v2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    iget v3, v3, Lgtandroid/universal/KeyboardService$TileSpec;->action:I

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$playerId:Ljava/lang/String;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$violatorId:Ljava/lang/String;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000136$100000135;->val$mainContainer:Landroid/widget/LinearLayout;

    invoke-static {v2, v3, v4, v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000407(Lgtandroid/universal/KeyboardService;ILjava/lang/String;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method
