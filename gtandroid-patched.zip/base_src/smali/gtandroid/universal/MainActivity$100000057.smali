.class Lgtandroid/universal/MainActivity$100000057;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000057"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$typeName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000057;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000057;->val$typeName:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000057;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000057;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2013
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000057;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000057;->val$typeName:Ljava/lang/String;

    invoke-static {v3, v4}, Lgtandroid/universal/MainActivity;->access$1000145(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    return-void
.end method
