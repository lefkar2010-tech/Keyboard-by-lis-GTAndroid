.class Lgtandroid/universal/MainActivity$100000070;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000070"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$etName:Landroid/widget/EditText;

.field private final val$etText:Landroid/widget/EditText;

.field private final val$index:I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;I)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000070;->val$etName:Landroid/widget/EditText;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000070;->val$etText:Landroid/widget/EditText;

    move-object v6, v0

    move v7, v4

    iput v7, v6, Lgtandroid/universal/MainActivity$100000070;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000070;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2659
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->val$etName:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-interface {v7}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 2660
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->val$etText:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-interface {v7}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 2661
    move-object v7, v4

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    move-object v7, v5

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 2662
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/MainActivity$100000070;->val$index:I

    move-object v9, v4

    move-object v10, v5

    invoke-static {v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->access$1000169(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;)V

    .line 2663
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    const-string v8, "\u2705 \u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u043e!"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    .line 2664
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v7}, Lgtandroid/universal/MainActivity;->access$1000166(Lgtandroid/universal/MainActivity;)V

    .line 2666
    :goto_0
    return-void

    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000070;->this$0:Lgtandroid/universal/MainActivity;

    const-string v8, "\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0432\u0441\u0435 \u043f\u043e\u043b\u044f!"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
