.class Lgtandroid/universal/KeyboardService$100000034;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000034"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000034;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1823
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0427\u0438\u0442\u044b"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 1824
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000198(Lgtandroid/universal/KeyboardService;)V

    .line 1840
    :cond_0
    :goto_0
    return-void

    .line 1825
    :cond_1
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u041d\u0430\u043a\u0430\u0437\u0430\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 1826
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000191(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1827
    :cond_2
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u041e\u0442\u0432\u0435\u0442\u0438\u0442\u044c \u043d\u0430 \u0440\u0435\u043f\u043e\u0440\u0442"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 1828
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000272(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1829
    :cond_3
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0422\u043e\u0447\u043a\u0430 \u0441\u043f\u0430\u0432\u043d\u0430"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 1830
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000430(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1831
    :cond_4
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0421\u043b\u0435\u0434\u0438\u0442\u044c sp(off)"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    .line 1832
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000424(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1833
    :cond_5
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0411\u044b\u0441\u0442\u0440\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    .line 1834
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000438(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1835
    :cond_6
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0422\u043f \u043a \u0441\u0435\u0431\u0435"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    .line 1836
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000219(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1837
    :cond_7
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0430"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    .line 1838
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000207(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0

    .line 1839
    :cond_8
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u041d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u044f \u0438\u0437 \u0430\u0434\u043c\u0438\u043d \u0447\u0430\u0442\u0430"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_x1

    .line 1840
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000172(Lgtandroid/universal/KeyboardService;)V

    goto/16 :goto_0

    :cond_x1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0421\u043e\u0431\u044b\u0442\u0438\u044f"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_x2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000160(Lgtandroid/universal/KeyboardService;)V

    goto/16 :goto_0

    :cond_x2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_x3

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000367(Lgtandroid/universal/KeyboardService;)V

    goto/16 :goto_0

    :cond_x3

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->val$name:Ljava/lang/String;

    const-string v4, "FamWar"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_x4

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000034;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000154(Lgtandroid/universal/KeyboardService;)V

    goto/16 :goto_0

    :cond_x4

    goto/16 :goto_0

.end method
